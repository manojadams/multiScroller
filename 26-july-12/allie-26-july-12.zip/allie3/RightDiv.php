		<!-- Start Main Diary Content -->
<div id="DiaryContent" style="width:1122px;">
    <!-- Start Diary Column -->
    <div class="DiaryColumnContainer ContextOn 0 EmptySlots" style="cursor:pointer;" data-apptid="" data-time="07:30" data-staffid="26" data-staffname="Bec Webberley" data-status="" data-key="0" data-clientid="" data-clientname="" data-newclient="" data-extended="" data-primaryid="" data-invoiced="" data-caseid="" data-type="">
    
    <div class="DiaryColumn" >

<!-- Start Lunch Time -->
<!-- End Lunch Time -->
	
<!-- Start Populate Slot -->
<!-- End Populate Slot -->
    
    
    </div>
    </div>
    <!-- End Diary Column -->
    <!-- Start Diary Column -->
    <div class="DiaryColumnContainer ContextOn 0 EmptySlots" style="cursor:pointer;" data-apptid="" data-time="07:30" data-staffid="7" data-staffname="Tamara Shaw" data-status="" data-key="0" data-clientid="" data-clientname="" data-newclient="" data-extended="" data-primaryid="" data-invoiced="" data-caseid="" data-type="">
    
    <div class="DiaryColumn" >

<!-- Start Lunch Time -->
<!-- End Lunch Time -->
	
<!-- Start Populate Slot -->
<!-- End Populate Slot -->
    
    
    </div>
    </div>
    <!-- End Diary Column -->
    <!-- Start Diary Column -->
    <div class="DiaryColumnContainer ContextOn 0 EmptySlots" style="cursor:pointer;" data-apptid="" data-time="07:30" data-staffid="16" data-staffname="Olivia  Moy" data-status="" data-key="0" data-clientid="" data-clientname="" data-newclient="" data-extended="" data-primaryid="" data-invoiced="" data-caseid="" data-type="">
    
    <div class="DiaryColumn" >

<!-- Start Lunch Time -->
<!-- End Lunch Time -->
	
<!-- Start Populate Slot -->
<!-- End Populate Slot -->
    
    
    </div>
    </div>
    <!-- End Diary Column -->
    <!-- Start Diary Column -->
    <div class="DiaryColumnContainer ContextOn 0 EmptySlots" style="cursor:pointer;" data-apptid="" data-time="07:30" data-staffid="18" data-staffname="Andrew  Rashleigh" data-status="" data-key="0" data-clientid="" data-clientname="" data-newclient="" data-extended="" data-primaryid="" data-invoiced="" data-caseid="" data-type="">
    
    <div class="DiaryColumn" >

<!-- Start Lunch Time -->
<!-- End Lunch Time -->
	
<!-- Start Populate Slot -->
<!-- End Populate Slot -->
    
    
    </div>
    </div>
    <!-- End Diary Column -->
    <!-- Start Diary Column -->
    <div class="DiaryColumnContainer ContextOn 0 EmptySlots" style="cursor:pointer;" data-apptid="" data-time="07:30" data-staffid="14" data-staffname="Emile  Cloete" data-status="" data-key="0" data-clientid="" data-clientname="" data-newclient="" data-extended="" data-primaryid="" data-invoiced="" data-caseid="" data-type="">
    
    <div class="DiaryColumn" >

<!-- Start Lunch Time -->
<!-- End Lunch Time -->
	
<!-- Start Populate Slot -->
<!-- End Populate Slot -->
    
    
    </div>
    </div>
    <!-- End Diary Column -->
    <!-- Start Diary Column -->
    <div class="DiaryColumnContainer ContextOn 0 EmptySlots" style="cursor:pointer;" data-apptid="" data-time="07:30" data-staffid="1" data-staffname="Darren  Rieck" data-status="" data-key="0" data-clientid="" data-clientname="" data-newclient="" data-extended="" data-primaryid="" data-invoiced="" data-caseid="" data-type="">
    
    <div class="DiaryColumn" >

<!-- Start Lunch Time -->
<!-- End Lunch Time -->
	
<!-- Start Populate Slot -->
<!-- End Populate Slot -->
    
    
    </div>
    </div>
    <!-- End Diary Column -->
    <!-- Start Diary Column -->
    <div class="DiaryColumnContainer ContextOn 0 EmptySlots" style="cursor:pointer;" data-apptid="" data-time="07:30" data-staffid="6" data-staffname="Karen  Kitchener" data-status="" data-key="0" data-clientid="" data-clientname="" data-newclient="" data-extended="" data-primaryid="" data-invoiced="" data-caseid="" data-type="">
    
    <div class="DiaryColumn" >

<!-- Start Lunch Time -->
<!-- End Lunch Time -->
	
<!-- Start Populate Slot -->
<!-- End Populate Slot -->
    
    
    </div>
    </div>
    <!-- End Diary Column -->
    <!-- Start Diary Column -->
    <div class="DiaryColumnContainer ContextOn 1 EmptySlots" style="cursor:pointer;" data-apptid="" data-time="07:40" data-staffid="26" data-staffname="Bec Webberley" data-status="" data-key="1" data-clientid="" data-clientname="" data-newclient="" data-extended="" data-primaryid="" data-invoiced="" data-caseid="" data-type="">
    
    <div class="DiaryColumn" >

<!-- Start Lunch Time -->
<!-- End Lunch Time -->
	
<!-- Start Populate Slot -->
<!-- End Populate Slot -->
    
    
    </div>
    </div>
    <!-- End Diary Column -->
    <!-- Start Diary Column -->
    <div class="DiaryColumnContainer ContextOn 1 EmptySlots" style="cursor:pointer;" data-apptid="" data-time="07:40" data-staffid="7" data-staffname="Tamara Shaw" data-status="" data-key="1" data-clientid="" data-clientname="" data-newclient="" data-extended="" data-primaryid="" data-invoiced="" data-caseid="" data-type="">
    
    <div class="DiaryColumn" >

<!-- Start Lunch Time -->
<!-- End Lunch Time -->
	
<!-- Start Populate Slot -->
<!-- End Populate Slot -->
    
    
    </div>
    </div>
    <!-- End Diary Column -->
    <!-- Start Diary Column -->
    <div class="DiaryColumnContainer ContextOn 1 EmptySlots" style="cursor:pointer;" data-apptid="" data-time="07:40" data-staffid="16" data-staffname="Olivia  Moy" data-status="" data-key="1" data-clientid="" data-clientname="" data-newclient="" data-extended="" data-primaryid="" data-invoiced="" data-caseid="" data-type="">
    
    <div class="DiaryColumn" >

<!-- Start Lunch Time -->
<!-- End Lunch Time -->
	
<!-- Start Populate Slot -->
<!-- End Populate Slot -->
    
    
    </div>
    </div>
    <!-- End Diary Column -->
    <!-- Start Diary Column -->
    <div class="DiaryColumnContainer ContextOn 1 EmptySlots" style="cursor:pointer;" data-apptid="" data-time="07:40" data-staffid="18" data-staffname="Andrew  Rashleigh" data-status="" data-key="1" data-clientid="" data-clientname="" data-newclient="" data-extended="" data-primaryid="" data-invoiced="" data-caseid="" data-type="">
    
    <div class="DiaryColumn" >

<!-- Start Lunch Time -->
<!-- End Lunch Time -->
	
<!-- Start Populate Slot -->
<!-- End Populate Slot -->
    
    
    </div>
    </div>
    <!-- End Diary Column -->
    <!-- Start Diary Column -->
    <div class="DiaryColumnContainer ContextOn 1 EmptySlots" style="cursor:pointer;" data-apptid="" data-time="07:40" data-staffid="14" data-staffname="Emile  Cloete" data-status="" data-key="1" data-clientid="" data-clientname="" data-newclient="" data-extended="" data-primaryid="" data-invoiced="" data-caseid="" data-type="">
    
    <div class="DiaryColumn" >

<!-- Start Lunch Time -->
<!-- End Lunch Time -->
	
<!-- Start Populate Slot -->
<!-- End Populate Slot -->
    
    
    </div>
    </div>
    <!-- End Diary Column -->
    <!-- Start Diary Column -->
    <div class="DiaryColumnContainer ContextOn 1 EmptySlots" style="cursor:pointer;" data-apptid="" data-time="07:40" data-staffid="1" data-staffname="Darren  Rieck" data-status="" data-key="1" data-clientid="" data-clientname="" data-newclient="" data-extended="" data-primaryid="" data-invoiced="" data-caseid="" data-type="">
    
    <div class="DiaryColumn" >

<!-- Start Lunch Time -->
<!-- End Lunch Time -->
	
<!-- Start Populate Slot -->
<!-- End Populate Slot -->
    
    
    </div>
    </div>
    <!-- End Diary Column -->
    <!-- Start Diary Column -->
    <div class="DiaryColumnContainer ContextOn 1 EmptySlots" style="cursor:pointer;" data-apptid="" data-time="07:40" data-staffid="6" data-staffname="Karen  Kitchener" data-status="" data-key="1" data-clientid="" data-clientname="" data-newclient="" data-extended="" data-primaryid="" data-invoiced="" data-caseid="" data-type="">
    
    <div class="DiaryColumn" >

<!-- Start Lunch Time -->
<!-- End Lunch Time -->
	
<!-- Start Populate Slot -->
<!-- End Populate Slot -->
    
    
    </div>
    </div>
    <!-- End Diary Column -->
    <!-- Start Diary Column -->
    <div class="DiaryColumnContainer ContextOn 2 EmptySlots" style="cursor:pointer;" data-apptid="" data-time="07:50" data-staffid="26" data-staffname="Bec Webberley" data-status="" data-key="2" data-clientid="" data-clientname="" data-newclient="" data-extended="" data-primaryid="" data-invoiced="" data-caseid="" data-type="">
    
    <div class="DiaryColumn" >

<!-- Start Lunch Time -->
<!-- End Lunch Time -->
	
<!-- Start Populate Slot -->
<!-- End Populate Slot -->
    
    
    </div>
    </div>
    <!-- End Diary Column -->
    <!-- Start Diary Column -->
    <div class="DiaryColumnContainer ContextOn 2 EmptySlots" style="cursor:pointer;" data-apptid="" data-time="07:50" data-staffid="7" data-staffname="Tamara Shaw" data-status="" data-key="2" data-clientid="" data-clientname="" data-newclient="" data-extended="" data-primaryid="" data-invoiced="" data-caseid="" data-type="">
    
    <div class="DiaryColumn" >

<!-- Start Lunch Time -->
<!-- End Lunch Time -->
	
<!-- Start Populate Slot -->
<!-- End Populate Slot -->
    
    
    </div>
    </div>
    <!-- End Diary Column -->
    <!-- Start Diary Column -->
    <div class="DiaryColumnContainer ContextOn 2 EmptySlots" style="cursor:pointer;" data-apptid="" data-time="07:50" data-staffid="16" data-staffname="Olivia  Moy" data-status="" data-key="2" data-clientid="" data-clientname="" data-newclient="" data-extended="" data-primaryid="" data-invoiced="" data-caseid="" data-type="">
    
    <div class="DiaryColumn" >

<!-- Start Lunch Time -->
<!-- End Lunch Time -->
	
<!-- Start Populate Slot -->
<!-- End Populate Slot -->
    
    
    </div>
    </div>
    <!-- End Diary Column -->
    <!-- Start Diary Column -->
    <div class="DiaryColumnContainer ContextOn 2 EmptySlots" style="cursor:pointer;" data-apptid="" data-time="07:50" data-staffid="18" data-staffname="Andrew  Rashleigh" data-status="" data-key="2" data-clientid="" data-clientname="" data-newclient="" data-extended="" data-primaryid="" data-invoiced="" data-caseid="" data-type="">
    
    <div class="DiaryColumn" >

<!-- Start Lunch Time -->
<!-- End Lunch Time -->
	
<!-- Start Populate Slot -->
<!-- End Populate Slot -->
    
    
    </div>
    </div>
    <!-- End Diary Column -->
    <!-- Start Diary Column -->
    <div class="DiaryColumnContainer ContextOn 2 EmptySlots" style="cursor:pointer;" data-apptid="" data-time="07:50" data-staffid="14" data-staffname="Emile  Cloete" data-status="" data-key="2" data-clientid="" data-clientname="" data-newclient="" data-extended="" data-primaryid="" data-invoiced="" data-caseid="" data-type="">
    
    <div class="DiaryColumn" >

<!-- Start Lunch Time -->
<!-- End Lunch Time -->
	
<!-- Start Populate Slot -->
<!-- End Populate Slot -->
    
    
    </div>
    </div>
    <!-- End Diary Column -->
    <!-- Start Diary Column -->
    <div class="DiaryColumnContainer ContextOn 2 EmptySlots" style="cursor:pointer;" data-apptid="" data-time="07:50" data-staffid="1" data-staffname="Darren  Rieck" data-status="" data-key="2" data-clientid="" data-clientname="" data-newclient="" data-extended="" data-primaryid="" data-invoiced="" data-caseid="" data-type="">
    
    <div class="DiaryColumn" >

<!-- Start Lunch Time -->
<!-- End Lunch Time -->
	
<!-- Start Populate Slot -->
<!-- End Populate Slot -->
    
    
    </div>
    </div>
    <!-- End Diary Column -->
    <!-- Start Diary Column -->
    <div class="DiaryColumnContainer ContextOn 2 EmptySlots" style="cursor:pointer;" data-apptid="" data-time="07:50" data-staffid="6" data-staffname="Karen  Kitchener" data-status="" data-key="2" data-clientid="" data-clientname="" data-newclient="" data-extended="" data-primaryid="" data-invoiced="" data-caseid="" data-type="">
    
    <div class="DiaryColumn" >

<!-- Start Lunch Time -->
<!-- End Lunch Time -->
	
<!-- Start Populate Slot -->
<!-- End Populate Slot -->
    
    
    </div>
    </div>
    <!-- End Diary Column -->
    <!-- Start Diary Column -->
    <div class="DiaryColumnContainer ContextOn 3 EmptySlots" style="cursor:pointer;" data-apptid="" data-time="08:00" data-staffid="26" data-staffname="Bec Webberley" data-status="" data-key="3" data-clientid="" data-clientname="" data-newclient="" data-extended="" data-primaryid="" data-invoiced="" data-caseid="" data-type="">
    
    <div class="DiaryColumn" >

<!-- Start Lunch Time -->
<!-- End Lunch Time -->
	
<!-- Start Populate Slot -->
<!-- End Populate Slot -->
    
    
    </div>
    </div>
    <!-- End Diary Column -->
    <!-- Start Diary Column -->
    <div class="DiaryColumnContainer ContextOn 3 EmptySlots" style="cursor:pointer;" data-apptid="" data-time="08:00" data-staffid="7" data-staffname="Tamara Shaw" data-status="" data-key="3" data-clientid="" data-clientname="" data-newclient="" data-extended="" data-primaryid="" data-invoiced="" data-caseid="" data-type="">
    
    <div class="DiaryColumn" >

<!-- Start Lunch Time -->
<!-- End Lunch Time -->
	
<!-- Start Populate Slot -->
<!-- End Populate Slot -->
    
    
    </div>
    </div>
    <!-- End Diary Column -->
    <!-- Start Diary Column -->
    <div class="DiaryColumnContainer ContextOn 3 EmptySlots" style="cursor:pointer;" data-apptid="" data-time="08:00" data-staffid="16" data-staffname="Olivia  Moy" data-status="" data-key="3" data-clientid="" data-clientname="" data-newclient="" data-extended="" data-primaryid="" data-invoiced="" data-caseid="" data-type="">
    
    <div class="DiaryColumn" >

<!-- Start Lunch Time -->
<!-- End Lunch Time -->
	
<!-- Start Populate Slot -->
<!-- End Populate Slot -->
    
    
    </div>
    </div>
    <!-- End Diary Column -->
    <!-- Start Diary Column -->
    <div class="DiaryColumnContainer ContextOn 3 EmptySlots" style="cursor:pointer;" data-apptid="" data-time="08:00" data-staffid="18" data-staffname="Andrew  Rashleigh" data-status="" data-key="3" data-clientid="" data-clientname="" data-newclient="" data-extended="" data-primaryid="" data-invoiced="" data-caseid="" data-type="">
    
    <div class="DiaryColumn" >

<!-- Start Lunch Time -->
<!-- End Lunch Time -->
	
<!-- Start Populate Slot -->
<!-- End Populate Slot -->
    
    
    </div>
    </div>
    <!-- End Diary Column -->
    <!-- Start Diary Column -->
    <div class="DiaryColumnContainer ContextOn 3 EmptySlots" style="cursor:pointer;" data-apptid="" data-time="08:00" data-staffid="14" data-staffname="Emile  Cloete" data-status="" data-key="3" data-clientid="" data-clientname="" data-newclient="" data-extended="" data-primaryid="" data-invoiced="" data-caseid="" data-type="">
    
    <div class="DiaryColumn" >

<!-- Start Lunch Time -->
<!-- End Lunch Time -->
	
<!-- Start Populate Slot -->
<!-- End Populate Slot -->
    
    
    </div>
    </div>
    <!-- End Diary Column -->
    <!-- Start Diary Column -->
    <div class="DiaryColumnContainer ContextOn 3 EmptySlots" style="cursor:pointer;" data-apptid="" data-time="08:00" data-staffid="1" data-staffname="Darren  Rieck" data-status="" data-key="3" data-clientid="" data-clientname="" data-newclient="" data-extended="" data-primaryid="" data-invoiced="" data-caseid="" data-type="">
    
    <div class="DiaryColumn" >

<!-- Start Lunch Time -->
<!-- End Lunch Time -->
	
<!-- Start Populate Slot -->
<!-- End Populate Slot -->
    
    
    </div>
    </div>
    <!-- End Diary Column -->
    <!-- Start Diary Column -->
    <div class="DiaryColumnContainer ContextOn 3 EmptySlots" style="cursor:pointer;" data-apptid="" data-time="08:00" data-staffid="6" data-staffname="Karen  Kitchener" data-status="" data-key="3" data-clientid="" data-clientname="" data-newclient="" data-extended="" data-primaryid="" data-invoiced="" data-caseid="" data-type="">
    
    <div class="DiaryColumn" >

<!-- Start Lunch Time -->
<!-- End Lunch Time -->
	
<!-- Start Populate Slot -->
<!-- End Populate Slot -->
    
    
    </div>
    </div>
    <!-- End Diary Column -->
    <!-- Start Diary Column -->
    <div class="DiaryColumnContainer ContextOn 4 EmptySlots" style="cursor:pointer;" data-apptid="" data-time="08:10" data-staffid="26" data-staffname="Bec Webberley" data-status="" data-key="4" data-clientid="" data-clientname="" data-newclient="" data-extended="" data-primaryid="" data-invoiced="" data-caseid="" data-type="">
    
    <div class="DiaryColumn" >

<!-- Start Lunch Time -->
<!-- End Lunch Time -->
	
<!-- Start Populate Slot -->
<!-- End Populate Slot -->
    
    
    </div>
    </div>
    <!-- End Diary Column -->
    <!-- Start Diary Column -->
    <div class="DiaryColumnContainer ContextOn 4 EmptySlots" style="cursor:pointer;" data-apptid="" data-time="08:10" data-staffid="7" data-staffname="Tamara Shaw" data-status="" data-key="4" data-clientid="" data-clientname="" data-newclient="" data-extended="" data-primaryid="" data-invoiced="" data-caseid="" data-type="">
    
    <div class="DiaryColumn" >

<!-- Start Lunch Time -->
<!-- End Lunch Time -->
	
<!-- Start Populate Slot -->
<!-- End Populate Slot -->
    
    
    </div>
    </div>
    <!-- End Diary Column -->
    <!-- Start Diary Column -->
    <div class="DiaryColumnContainer ContextOn 4 EmptySlots" style="cursor:pointer;" data-apptid="" data-time="08:10" data-staffid="16" data-staffname="Olivia  Moy" data-status="" data-key="4" data-clientid="" data-clientname="" data-newclient="" data-extended="" data-primaryid="" data-invoiced="" data-caseid="" data-type="">
    
    <div class="DiaryColumn" >

<!-- Start Lunch Time -->
<!-- End Lunch Time -->
	
<!-- Start Populate Slot -->
<!-- End Populate Slot -->
    
    
    </div>
    </div>
    <!-- End Diary Column -->
    <!-- Start Diary Column -->
    <div class="DiaryColumnContainer ContextOn 4 EmptySlots" style="cursor:pointer;" data-apptid="" data-time="08:10" data-staffid="18" data-staffname="Andrew  Rashleigh" data-status="" data-key="4" data-clientid="" data-clientname="" data-newclient="" data-extended="" data-primaryid="" data-invoiced="" data-caseid="" data-type="">
    
    <div class="DiaryColumn" >

<!-- Start Lunch Time -->
<!-- End Lunch Time -->
	
<!-- Start Populate Slot -->
<!-- End Populate Slot -->
    
    
    </div>
    </div>
    <!-- End Diary Column -->
    <!-- Start Diary Column -->
    <div class="DiaryColumnContainer ContextOn 4 EmptySlots" style="cursor:pointer;" data-apptid="" data-time="08:10" data-staffid="14" data-staffname="Emile  Cloete" data-status="" data-key="4" data-clientid="" data-clientname="" data-newclient="" data-extended="" data-primaryid="" data-invoiced="" data-caseid="" data-type="">
    
    <div class="DiaryColumn" >

<!-- Start Lunch Time -->
<!-- End Lunch Time -->
	
<!-- Start Populate Slot -->
<!-- End Populate Slot -->
    
    
    </div>
    </div>
    <!-- End Diary Column -->
    <!-- Start Diary Column -->
    <div class="DiaryColumnContainer ContextOn 4 EmptySlots" style="cursor:pointer;" data-apptid="" data-time="08:10" data-staffid="1" data-staffname="Darren  Rieck" data-status="" data-key="4" data-clientid="" data-clientname="" data-newclient="" data-extended="" data-primaryid="" data-invoiced="" data-caseid="" data-type="">
    
    <div class="DiaryColumn" >

<!-- Start Lunch Time -->
<!-- End Lunch Time -->
	
<!-- Start Populate Slot -->
<!-- End Populate Slot -->
    
    
    </div>
    </div>
    <!-- End Diary Column -->
    <!-- Start Diary Column -->
    <div class="DiaryColumnContainer ContextOn 4 EmptySlots" style="cursor:pointer;" data-apptid="" data-time="08:10" data-staffid="6" data-staffname="Karen  Kitchener" data-status="" data-key="4" data-clientid="" data-clientname="" data-newclient="" data-extended="" data-primaryid="" data-invoiced="" data-caseid="" data-type="">
    
    <div class="DiaryColumn" >

<!-- Start Lunch Time -->
<!-- End Lunch Time -->
	
<!-- Start Populate Slot -->
<!-- End Populate Slot -->
    
    
    </div>
    </div>
    <!-- End Diary Column -->
    <!-- Start Diary Column -->
    <div class="DiaryColumnContainer ContextOn 5 EmptySlots" style="cursor:pointer;" data-apptid="" data-time="08:20" data-staffid="26" data-staffname="Bec Webberley" data-status="" data-key="5" data-clientid="" data-clientname="" data-newclient="" data-extended="" data-primaryid="" data-invoiced="" data-caseid="" data-type="">
    
    <div class="DiaryColumn" >

<!-- Start Lunch Time -->
<!-- End Lunch Time -->
	
<!-- Start Populate Slot -->
<!-- End Populate Slot -->
    
    
    </div>
    </div>
    <!-- End Diary Column -->
    <!-- Start Diary Column -->
    <div class="DiaryColumnContainer ContextOn 5 EmptySlots" style="cursor:pointer;" data-apptid="" data-time="08:20" data-staffid="7" data-staffname="Tamara Shaw" data-status="" data-key="5" data-clientid="" data-clientname="" data-newclient="" data-extended="" data-primaryid="" data-invoiced="" data-caseid="" data-type="">
    
    <div class="DiaryColumn" >

<!-- Start Lunch Time -->
<!-- End Lunch Time -->
	
<!-- Start Populate Slot -->
<!-- End Populate Slot -->
    
    
    </div>
    </div>
    <!-- End Diary Column -->
    <!-- Start Diary Column -->
    <div class="DiaryColumnContainer ContextOn 5 EmptySlots" style="cursor:pointer;" data-apptid="" data-time="08:20" data-staffid="16" data-staffname="Olivia  Moy" data-status="" data-key="5" data-clientid="" data-clientname="" data-newclient="" data-extended="" data-primaryid="" data-invoiced="" data-caseid="" data-type="">
    
    <div class="DiaryColumn" >

<!-- Start Lunch Time -->
<!-- End Lunch Time -->
	
<!-- Start Populate Slot -->
<!-- End Populate Slot -->
    
    
    </div>
    </div>
    <!-- End Diary Column -->
    <!-- Start Diary Column -->
    <div class="DiaryColumnContainer ContextOn 5 EmptySlots" style="cursor:pointer;" data-apptid="" data-time="08:20" data-staffid="18" data-staffname="Andrew  Rashleigh" data-status="" data-key="5" data-clientid="" data-clientname="" data-newclient="" data-extended="" data-primaryid="" data-invoiced="" data-caseid="" data-type="">
    
    <div class="DiaryColumn" >

<!-- Start Lunch Time -->
<!-- End Lunch Time -->
	
<!-- Start Populate Slot -->
<!-- End Populate Slot -->
    
    
    </div>
    </div>
    <!-- End Diary Column -->
    <!-- Start Diary Column -->
    <div class="DiaryColumnContainer ContextOn 5 EmptySlots" style="cursor:pointer;" data-apptid="" data-time="08:20" data-staffid="14" data-staffname="Emile  Cloete" data-status="" data-key="5" data-clientid="" data-clientname="" data-newclient="" data-extended="" data-primaryid="" data-invoiced="" data-caseid="" data-type="">
    
    <div class="DiaryColumn" >

<!-- Start Lunch Time -->
<!-- End Lunch Time -->
	
<!-- Start Populate Slot -->
<!-- End Populate Slot -->
    
    
    </div>
    </div>
    <!-- End Diary Column -->
    <!-- Start Diary Column -->
    <div class="DiaryColumnContainer ContextOn 5 EmptySlots" style="cursor:pointer;" data-apptid="" data-time="08:20" data-staffid="1" data-staffname="Darren  Rieck" data-status="" data-key="5" data-clientid="" data-clientname="" data-newclient="" data-extended="" data-primaryid="" data-invoiced="" data-caseid="" data-type="">
    
    <div class="DiaryColumn" >

<!-- Start Lunch Time -->
<!-- End Lunch Time -->
	
<!-- Start Populate Slot -->
<!-- End Populate Slot -->
    
    
    </div>
    </div>
    <!-- End Diary Column -->
    <!-- Start Diary Column -->
    <div class="DiaryColumnContainer ContextOn 5 EmptySlots" style="cursor:pointer;" data-apptid="" data-time="08:20" data-staffid="6" data-staffname="Karen  Kitchener" data-status="" data-key="5" data-clientid="" data-clientname="" data-newclient="" data-extended="" data-primaryid="" data-invoiced="" data-caseid="" data-type="">
    
    <div class="DiaryColumn" >

<!-- Start Lunch Time -->
<!-- End Lunch Time -->
	
<!-- Start Populate Slot -->
<!-- End Populate Slot -->
    
    
    </div>
    </div>
    <!-- End Diary Column -->
    <!-- Start Diary Column -->
    <div class="DiaryColumnContainer ContextOn 6 EmptySlots" style="cursor:pointer;" data-apptid="" data-time="08:30" data-staffid="26" data-staffname="Bec Webberley" data-status="" data-key="6" data-clientid="" data-clientname="" data-newclient="" data-extended="" data-primaryid="" data-invoiced="" data-caseid="" data-type="">
    
    <div class="DiaryColumn" >

<!-- Start Lunch Time -->
<!-- End Lunch Time -->
	
<!-- Start Populate Slot -->
<!-- End Populate Slot -->
    
    
    </div>
    </div>
    <!-- End Diary Column -->
    <!-- Start Diary Column -->
    <div class="DiaryColumnContainer ContextOn 6 EmptySlots" style="cursor:pointer;" data-apptid="" data-time="08:30" data-staffid="7" data-staffname="Tamara Shaw" data-status="" data-key="6" data-clientid="" data-clientname="" data-newclient="" data-extended="" data-primaryid="" data-invoiced="" data-caseid="" data-type="">
    
    <div class="DiaryColumn" >

<!-- Start Lunch Time -->
<!-- End Lunch Time -->
	
<!-- Start Populate Slot -->
<!-- End Populate Slot -->
    
    
    </div>
    </div>
    <!-- End Diary Column -->
    <!-- Start Diary Column -->
    <div class="DiaryColumnContainer ContextOn 6 EmptySlots" style="cursor:pointer;" data-apptid="" data-time="08:30" data-staffid="16" data-staffname="Olivia  Moy" data-status="" data-key="6" data-clientid="" data-clientname="" data-newclient="" data-extended="" data-primaryid="" data-invoiced="" data-caseid="" data-type="">
    
    <div class="DiaryColumn" >

<!-- Start Lunch Time -->
<!-- End Lunch Time -->
	
<!-- Start Populate Slot -->
<!-- End Populate Slot -->
    
    
    </div>
    </div>
    <!-- End Diary Column -->
    <!-- Start Diary Column -->
    <div class="DiaryColumnContainer ContextOn 6 EmptySlots" style="cursor:pointer;" data-apptid="" data-time="08:30" data-staffid="18" data-staffname="Andrew  Rashleigh" data-status="" data-key="6" data-clientid="" data-clientname="" data-newclient="" data-extended="" data-primaryid="" data-invoiced="" data-caseid="" data-type="">
    
    <div class="DiaryColumn" >

<!-- Start Lunch Time -->
<!-- End Lunch Time -->
	
<!-- Start Populate Slot -->
<!-- End Populate Slot -->
    
    
    </div>
    </div>
    <!-- End Diary Column -->
    <!-- Start Diary Column -->
    <div class="DiaryColumnContainer ContextOn 6 EmptySlots" style="cursor:pointer;" data-apptid="" data-time="08:30" data-staffid="14" data-staffname="Emile  Cloete" data-status="" data-key="6" data-clientid="" data-clientname="" data-newclient="" data-extended="" data-primaryid="" data-invoiced="" data-caseid="" data-type="">
    
    <div class="DiaryColumn" >

<!-- Start Lunch Time -->
<!-- End Lunch Time -->
	
<!-- Start Populate Slot -->
<!-- End Populate Slot -->
    
    
    </div>
    </div>
    <!-- End Diary Column -->
    <!-- Start Diary Column -->
    <div class="DiaryColumnContainer ContextOn 6 EmptySlots" style="cursor:pointer;" data-apptid="" data-time="08:30" data-staffid="1" data-staffname="Darren  Rieck" data-status="" data-key="6" data-clientid="" data-clientname="" data-newclient="" data-extended="" data-primaryid="" data-invoiced="" data-caseid="" data-type="">
    
    <div class="DiaryColumn" >

<!-- Start Lunch Time -->
<!-- End Lunch Time -->
	
<!-- Start Populate Slot -->
<!-- End Populate Slot -->
    
    
    </div>
    </div>
    <!-- End Diary Column -->
    <!-- Start Diary Column -->
    <div class="DiaryColumnContainer ContextOn 6 EmptySlots" style="cursor:pointer;" data-apptid="" data-time="08:30" data-staffid="6" data-staffname="Karen  Kitchener" data-status="" data-key="6" data-clientid="" data-clientname="" data-newclient="" data-extended="" data-primaryid="" data-invoiced="" data-caseid="" data-type="">
    
    <div class="DiaryColumn" >

<!-- Start Lunch Time -->
<!-- End Lunch Time -->
	
<!-- Start Populate Slot -->
<!-- End Populate Slot -->
    
    
    </div>
    </div>
    <!-- End Diary Column -->
    <!-- Start Diary Column -->
    <div class="DiaryColumnContainer ContextOn 7 EmptySlots" style="cursor:pointer;" data-apptid="" data-time="08:40" data-staffid="26" data-staffname="Bec Webberley" data-status="" data-key="7" data-clientid="" data-clientname="" data-newclient="" data-extended="" data-primaryid="" data-invoiced="" data-caseid="" data-type="">
    
    <div class="DiaryColumn" >

<!-- Start Lunch Time -->
<!-- End Lunch Time -->
	
<!-- Start Populate Slot -->
<!-- End Populate Slot -->
    
    
    </div>
    </div>
    <!-- End Diary Column -->
    <!-- Start Diary Column -->
    <div class="DiaryColumnContainer ContextOn 7 EmptySlots" style="cursor:pointer;" data-apptid="" data-time="08:40" data-staffid="7" data-staffname="Tamara Shaw" data-status="" data-key="7" data-clientid="" data-clientname="" data-newclient="" data-extended="" data-primaryid="" data-invoiced="" data-caseid="" data-type="">
    
    <div class="DiaryColumn" >

<!-- Start Lunch Time -->
<!-- End Lunch Time -->
	
<!-- Start Populate Slot -->
<!-- End Populate Slot -->
    
    
    </div>
    </div>
    <!-- End Diary Column -->
    <!-- Start Diary Column -->
    <div class="DiaryColumnContainer ContextOn 7 EmptySlots" style="cursor:pointer;" data-apptid="" data-time="08:40" data-staffid="16" data-staffname="Olivia  Moy" data-status="" data-key="7" data-clientid="" data-clientname="" data-newclient="" data-extended="" data-primaryid="" data-invoiced="" data-caseid="" data-type="">
    
    <div class="DiaryColumn" >

<!-- Start Lunch Time -->
<!-- End Lunch Time -->
	
<!-- Start Populate Slot -->
<!-- End Populate Slot -->
    
    
    </div>
    </div>
    <!-- End Diary Column -->
    <!-- Start Diary Column -->
    <div class="DiaryColumnContainer ContextOn 7 EmptySlots" style="cursor:pointer;" data-apptid="" data-time="08:40" data-staffid="18" data-staffname="Andrew  Rashleigh" data-status="" data-key="7" data-clientid="" data-clientname="" data-newclient="" data-extended="" data-primaryid="" data-invoiced="" data-caseid="" data-type="">
    
    <div class="DiaryColumn" >

<!-- Start Lunch Time -->
<!-- End Lunch Time -->
	
<!-- Start Populate Slot -->
<!-- End Populate Slot -->
    
    
    </div>
    </div>
    <!-- End Diary Column -->
    <!-- Start Diary Column -->
    <div class="DiaryColumnContainer ContextOn 7 EmptySlots" style="cursor:pointer;" data-apptid="" data-time="08:40" data-staffid="14" data-staffname="Emile  Cloete" data-status="" data-key="7" data-clientid="" data-clientname="" data-newclient="" data-extended="" data-primaryid="" data-invoiced="" data-caseid="" data-type="">
    
    <div class="DiaryColumn" >

<!-- Start Lunch Time -->
<!-- End Lunch Time -->
	
<!-- Start Populate Slot -->
<!-- End Populate Slot -->
    
    
    </div>
    </div>
    <!-- End Diary Column -->
    <!-- Start Diary Column -->
    <div class="DiaryColumnContainer ContextOn 7 EmptySlots" style="cursor:pointer;" data-apptid="" data-time="08:40" data-staffid="1" data-staffname="Darren  Rieck" data-status="" data-key="7" data-clientid="" data-clientname="" data-newclient="" data-extended="" data-primaryid="" data-invoiced="" data-caseid="" data-type="">
    
    <div class="DiaryColumn" >

<!-- Start Lunch Time -->
<!-- End Lunch Time -->
	
<!-- Start Populate Slot -->
<!-- End Populate Slot -->
    
    
    </div>
    </div>
    <!-- End Diary Column -->
    <!-- Start Diary Column -->
    <div class="DiaryColumnContainer ContextOn 7 EmptySlots" style="cursor:pointer;" data-apptid="" data-time="08:40" data-staffid="6" data-staffname="Karen  Kitchener" data-status="" data-key="7" data-clientid="" data-clientname="" data-newclient="" data-extended="" data-primaryid="" data-invoiced="" data-caseid="" data-type="">
    
    <div class="DiaryColumn" >

<!-- Start Lunch Time -->
<!-- End Lunch Time -->
	
<!-- Start Populate Slot -->
<!-- End Populate Slot -->
    
    
    </div>
    </div>
    <!-- End Diary Column -->
    <!-- Start Diary Column -->
    <div class="DiaryColumnContainer ContextOn 8 EmptySlots" style="cursor:pointer;" data-apptid="" data-time="08:50" data-staffid="26" data-staffname="Bec Webberley" data-status="" data-key="8" data-clientid="" data-clientname="" data-newclient="" data-extended="" data-primaryid="" data-invoiced="" data-caseid="" data-type="">
    
    <div class="DiaryColumn" >

<!-- Start Lunch Time -->
<!-- End Lunch Time -->
	
<!-- Start Populate Slot -->
<!-- End Populate Slot -->
    
    
    </div>
    </div>
    <!-- End Diary Column -->
    <!-- Start Diary Column -->
    <div class="DiaryColumnContainer ContextOn 8 EmptySlots" style="cursor:pointer;" data-apptid="" data-time="08:50" data-staffid="7" data-staffname="Tamara Shaw" data-status="" data-key="8" data-clientid="" data-clientname="" data-newclient="" data-extended="" data-primaryid="" data-invoiced="" data-caseid="" data-type="">
    
    <div class="DiaryColumn" >

<!-- Start Lunch Time -->
<!-- End Lunch Time -->
	
<!-- Start Populate Slot -->
<!-- End Populate Slot -->
    
    
    </div>
    </div>
    <!-- End Diary Column -->
    <!-- Start Diary Column -->
    <div class="DiaryColumnContainer ContextOn 8 EmptySlots" style="cursor:pointer;" data-apptid="" data-time="08:50" data-staffid="16" data-staffname="Olivia  Moy" data-status="" data-key="8" data-clientid="" data-clientname="" data-newclient="" data-extended="" data-primaryid="" data-invoiced="" data-caseid="" data-type="">
    
    <div class="DiaryColumn" >

<!-- Start Lunch Time -->
<!-- End Lunch Time -->
	
<!-- Start Populate Slot -->
<!-- End Populate Slot -->
    
    
    </div>
    </div>
    <!-- End Diary Column -->
    <!-- Start Diary Column -->
    <div class="DiaryColumnContainer ContextOn 8 EmptySlots" style="cursor:pointer;" data-apptid="" data-time="08:50" data-staffid="18" data-staffname="Andrew  Rashleigh" data-status="" data-key="8" data-clientid="" data-clientname="" data-newclient="" data-extended="" data-primaryid="" data-invoiced="" data-caseid="" data-type="">
    
    <div class="DiaryColumn" >

<!-- Start Lunch Time -->
<!-- End Lunch Time -->
	
<!-- Start Populate Slot -->
<!-- End Populate Slot -->
    
    
    </div>
    </div>
    <!-- End Diary Column -->
    <!-- Start Diary Column -->
    <div class="DiaryColumnContainer ContextOn 8 EmptySlots" style="cursor:pointer;" data-apptid="" data-time="08:50" data-staffid="14" data-staffname="Emile  Cloete" data-status="" data-key="8" data-clientid="" data-clientname="" data-newclient="" data-extended="" data-primaryid="" data-invoiced="" data-caseid="" data-type="">
    
    <div class="DiaryColumn" >

<!-- Start Lunch Time -->
<!-- End Lunch Time -->
	
<!-- Start Populate Slot -->
<!-- End Populate Slot -->
    
    
    </div>
    </div>
    <!-- End Diary Column -->
    <!-- Start Diary Column -->
    <div class="DiaryColumnContainer ContextOn 8 EmptySlots" style="cursor:pointer;" data-apptid="" data-time="08:50" data-staffid="1" data-staffname="Darren  Rieck" data-status="" data-key="8" data-clientid="" data-clientname="" data-newclient="" data-extended="" data-primaryid="" data-invoiced="" data-caseid="" data-type="">
    
    <div class="DiaryColumn" >

<!-- Start Lunch Time -->
<!-- End Lunch Time -->
	
<!-- Start Populate Slot -->
<!-- End Populate Slot -->
    
    
    </div>
    </div>
    <!-- End Diary Column -->
    <!-- Start Diary Column -->
    <div class="DiaryColumnContainer ContextOn 8 EmptySlots" style="cursor:pointer;" data-apptid="" data-time="08:50" data-staffid="6" data-staffname="Karen  Kitchener" data-status="" data-key="8" data-clientid="" data-clientname="" data-newclient="" data-extended="" data-primaryid="" data-invoiced="" data-caseid="" data-type="">
    
    <div class="DiaryColumn" >

<!-- Start Lunch Time -->
<!-- End Lunch Time -->
	
<!-- Start Populate Slot -->
<!-- End Populate Slot -->
    
    
    </div>
    </div>
    <!-- End Diary Column -->
    <!-- Start Diary Column -->
    <div class="DiaryColumnContainer ContextOn 9 EmptySlots" style="cursor:pointer;" data-apptid="" data-time="09:00" data-staffid="26" data-staffname="Bec Webberley" data-status="" data-key="9" data-clientid="" data-clientname="" data-newclient="" data-extended="" data-primaryid="" data-invoiced="" data-caseid="" data-type="">
    
    <div class="DiaryColumn" >

<!-- Start Lunch Time -->
<!-- End Lunch Time -->
	
<!-- Start Populate Slot -->
<!-- End Populate Slot -->
    
    
    </div>
    </div>
    <!-- End Diary Column -->
    <!-- Start Diary Column -->
    <div class="DiaryColumnContainer ContextOn 9 EmptySlots" style="cursor:pointer;" data-apptid="" data-time="09:00" data-staffid="7" data-staffname="Tamara Shaw" data-status="" data-key="9" data-clientid="" data-clientname="" data-newclient="" data-extended="" data-primaryid="" data-invoiced="" data-caseid="" data-type="">
    
    <div class="DiaryColumn" >

<!-- Start Lunch Time -->
<!-- End Lunch Time -->
	
<!-- Start Populate Slot -->
<!-- End Populate Slot -->
    
    
    </div>
    </div>
    <!-- End Diary Column -->
    <!-- Start Diary Column -->
    <div class="DiaryColumnContainer ContextOn 9 EmptySlots" style="cursor:pointer;" data-apptid="" data-time="09:00" data-staffid="16" data-staffname="Olivia  Moy" data-status="" data-key="9" data-clientid="" data-clientname="" data-newclient="" data-extended="" data-primaryid="" data-invoiced="" data-caseid="" data-type="">
    
    <div class="DiaryColumnSchedule" >

<!-- Start Lunch Time -->
<!-- End Lunch Time -->
	
<!-- Start Populate Slot -->
<!-- End Populate Slot -->
    
    
    </div>
    </div>
    <!-- End Diary Column -->
    <!-- Start Diary Column -->
    <div class="DiaryColumnContainer ContextOn 9 EmptySlots" style="cursor:pointer;" data-apptid="" data-time="09:00" data-staffid="18" data-staffname="Andrew  Rashleigh" data-status="" data-key="9" data-clientid="" data-clientname="" data-newclient="" data-extended="" data-primaryid="" data-invoiced="" data-caseid="" data-type="">
    
    <div class="DiaryColumn" >

<!-- Start Lunch Time -->
<!-- End Lunch Time -->
	
<!-- Start Populate Slot -->
<!-- End Populate Slot -->
    
    
    </div>
    </div>
    <!-- End Diary Column -->
    <!-- Start Diary Column -->
    <div class="DiaryColumnContainer ContextOn 9 EmptySlots" style="cursor:pointer;" data-apptid="" data-time="09:00" data-staffid="14" data-staffname="Emile  Cloete" data-status="" data-key="9" data-clientid="" data-clientname="" data-newclient="" data-extended="" data-primaryid="" data-invoiced="" data-caseid="" data-type="">
    
    <div class="DiaryColumn" >

<!-- Start Lunch Time -->
<!-- End Lunch Time -->
	
<!-- Start Populate Slot -->
<!-- End Populate Slot -->
    
    
    </div>
    </div>
    <!-- End Diary Column -->
    <!-- Start Diary Column -->
    <div class="DiaryColumnContainer ContextOn 9 EmptySlots" style="cursor:pointer;" data-apptid="" data-time="09:00" data-staffid="1" data-staffname="Darren  Rieck" data-status="" data-key="9" data-clientid="" data-clientname="" data-newclient="" data-extended="" data-primaryid="" data-invoiced="" data-caseid="" data-type="">
    
    <div class="DiaryColumn" >

<!-- Start Lunch Time -->
<!-- End Lunch Time -->
	
<!-- Start Populate Slot -->
<!-- End Populate Slot -->
    
    
    </div>
    </div>
    <!-- End Diary Column -->
    <!-- Start Diary Column -->
    <div class="DiaryColumnContainer ContextOn 9 EmptySlots" style="cursor:pointer;" data-apptid="" data-time="09:00" data-staffid="6" data-staffname="Karen  Kitchener" data-status="" data-key="9" data-clientid="" data-clientname="" data-newclient="" data-extended="" data-primaryid="" data-invoiced="" data-caseid="" data-type="">
    
    <div class="DiaryColumn" >

<!-- Start Lunch Time -->
<!-- End Lunch Time -->
	
<!-- Start Populate Slot -->
<!-- End Populate Slot -->
    
    
    </div>
    </div>
    <!-- End Diary Column -->
    <!-- Start Diary Column -->
    <div class="DiaryColumnContainer ContextOn 10 EmptySlots" style="cursor:pointer;" data-apptid="" data-time="09:10" data-staffid="26" data-staffname="Bec Webberley" data-status="" data-key="10" data-clientid="" data-clientname="" data-newclient="" data-extended="" data-primaryid="" data-invoiced="" data-caseid="" data-type="">
    
    <div class="DiaryColumn" >

<!-- Start Lunch Time -->
<!-- End Lunch Time -->
	
<!-- Start Populate Slot -->
<!-- End Populate Slot -->
    
    
    </div>
    </div>
    <!-- End Diary Column -->
    <!-- Start Diary Column -->
    <div class="DiaryColumnContainer ContextOn 10 EmptySlots" style="cursor:pointer;" data-apptid="" data-time="09:10" data-staffid="7" data-staffname="Tamara Shaw" data-status="" data-key="10" data-clientid="" data-clientname="" data-newclient="" data-extended="" data-primaryid="" data-invoiced="" data-caseid="" data-type="">
    
    <div class="DiaryColumn" >

<!-- Start Lunch Time -->
<!-- End Lunch Time -->
	
<!-- Start Populate Slot -->
<!-- End Populate Slot -->
    
    
    </div>
    </div>
    <!-- End Diary Column -->
    <!-- Start Diary Column -->
    <div class="DiaryColumnContainer ContextOn 10 EmptySlots" style="cursor:pointer;" data-apptid="" data-time="09:10" data-staffid="16" data-staffname="Olivia  Moy" data-status="" data-key="10" data-clientid="" data-clientname="" data-newclient="" data-extended="" data-primaryid="" data-invoiced="" data-caseid="" data-type="">
    
    <div class="DiaryColumnSchedule" >

<!-- Start Lunch Time -->
<!-- End Lunch Time -->
	
<!-- Start Populate Slot -->
<!-- End Populate Slot -->
    
    
    </div>
    </div>
    <!-- End Diary Column -->
    <!-- Start Diary Column -->
    <div class="DiaryColumnContainer ContextOn 10 EmptySlots" style="cursor:pointer;" data-apptid="" data-time="09:10" data-staffid="18" data-staffname="Andrew  Rashleigh" data-status="" data-key="10" data-clientid="" data-clientname="" data-newclient="" data-extended="" data-primaryid="" data-invoiced="" data-caseid="" data-type="">
    
    <div class="DiaryColumn" >

<!-- Start Lunch Time -->
<!-- End Lunch Time -->
	
<!-- Start Populate Slot -->
<!-- End Populate Slot -->
    
    
    </div>
    </div>
    <!-- End Diary Column -->
    <!-- Start Diary Column -->
    <div class="DiaryColumnContainer ContextOn 10 EmptySlots" style="cursor:pointer;" data-apptid="" data-time="09:10" data-staffid="14" data-staffname="Emile  Cloete" data-status="" data-key="10" data-clientid="" data-clientname="" data-newclient="" data-extended="" data-primaryid="" data-invoiced="" data-caseid="" data-type="">
    
    <div class="DiaryColumn" >

<!-- Start Lunch Time -->
<!-- End Lunch Time -->
	
<!-- Start Populate Slot -->
<!-- End Populate Slot -->
    
    
    </div>
    </div>
    <!-- End Diary Column -->
    <!-- Start Diary Column -->
    <div class="DiaryColumnContainer ContextOn 10 EmptySlots" style="cursor:pointer;" data-apptid="" data-time="09:10" data-staffid="1" data-staffname="Darren  Rieck" data-status="" data-key="10" data-clientid="" data-clientname="" data-newclient="" data-extended="" data-primaryid="" data-invoiced="" data-caseid="" data-type="">
    
    <div class="DiaryColumn" >

<!-- Start Lunch Time -->
<!-- End Lunch Time -->
	
<!-- Start Populate Slot -->
<!-- End Populate Slot -->
    
    
    </div>
    </div>
    <!-- End Diary Column -->
    <!-- Start Diary Column -->
    <div class="DiaryColumnContainer ContextOn 10 EmptySlots" style="cursor:pointer;" data-apptid="" data-time="09:10" data-staffid="6" data-staffname="Karen  Kitchener" data-status="" data-key="10" data-clientid="" data-clientname="" data-newclient="" data-extended="" data-primaryid="" data-invoiced="" data-caseid="" data-type="">
    
    <div class="DiaryColumn" >

<!-- Start Lunch Time -->
<!-- End Lunch Time -->
	
<!-- Start Populate Slot -->
<!-- End Populate Slot -->
    
    
    </div>
    </div>
    <!-- End Diary Column -->
    <!-- Start Diary Column -->
    <div class="DiaryColumnContainer ContextOn 11 EmptySlots" style="cursor:pointer;" data-apptid="" data-time="09:20" data-staffid="26" data-staffname="Bec Webberley" data-status="" data-key="11" data-clientid="" data-clientname="" data-newclient="" data-extended="" data-primaryid="" data-invoiced="" data-caseid="" data-type="">
    
    <div class="DiaryColumn" >

<!-- Start Lunch Time -->
<!-- End Lunch Time -->
	
<!-- Start Populate Slot -->
<!-- End Populate Slot -->
    
    
    </div>
    </div>
    <!-- End Diary Column -->
    <!-- Start Diary Column -->
    <div class="DiaryColumnContainer ContextOn 11 EmptySlots" style="cursor:pointer;" data-apptid="" data-time="09:20" data-staffid="7" data-staffname="Tamara Shaw" data-status="" data-key="11" data-clientid="" data-clientname="" data-newclient="" data-extended="" data-primaryid="" data-invoiced="" data-caseid="" data-type="">
    
    <div class="DiaryColumn" >

<!-- Start Lunch Time -->
<!-- End Lunch Time -->
	
<!-- Start Populate Slot -->
<!-- End Populate Slot -->
    
    
    </div>
    </div>
    <!-- End Diary Column -->
    <!-- Start Diary Column -->
    <div class="DiaryColumnContainer ContextOn 11 EmptySlots" style="cursor:pointer;" data-apptid="" data-time="09:20" data-staffid="16" data-staffname="Olivia  Moy" data-status="" data-key="11" data-clientid="" data-clientname="" data-newclient="" data-extended="" data-primaryid="" data-invoiced="" data-caseid="" data-type="">
    
    <div class="DiaryColumnSchedule" >

<!-- Start Lunch Time -->
<!-- End Lunch Time -->
	
<!-- Start Populate Slot -->
<!-- End Populate Slot -->
    
    
    </div>
    </div>
    <!-- End Diary Column -->
    <!-- Start Diary Column -->
    <div class="DiaryColumnContainer ContextOn 11 EmptySlots" style="cursor:pointer;" data-apptid="" data-time="09:20" data-staffid="18" data-staffname="Andrew  Rashleigh" data-status="" data-key="11" data-clientid="" data-clientname="" data-newclient="" data-extended="" data-primaryid="" data-invoiced="" data-caseid="" data-type="">
    
    <div class="DiaryColumn" >

<!-- Start Lunch Time -->
<!-- End Lunch Time -->
	
<!-- Start Populate Slot -->
<!-- End Populate Slot -->
    
    
    </div>
    </div>
    <!-- End Diary Column -->
    <!-- Start Diary Column -->
    <div class="DiaryColumnContainer ContextOn 11 EmptySlots" style="cursor:pointer;" data-apptid="" data-time="09:20" data-staffid="14" data-staffname="Emile  Cloete" data-status="" data-key="11" data-clientid="" data-clientname="" data-newclient="" data-extended="" data-primaryid="" data-invoiced="" data-caseid="" data-type="">
    
    <div class="DiaryColumn" >

<!-- Start Lunch Time -->
<!-- End Lunch Time -->
	
<!-- Start Populate Slot -->
<!-- End Populate Slot -->
    
    
    </div>
    </div>
    <!-- End Diary Column -->
    <!-- Start Diary Column -->
    <div class="DiaryColumnContainer ContextOn 11 EmptySlots" style="cursor:pointer;" data-apptid="" data-time="09:20" data-staffid="1" data-staffname="Darren  Rieck" data-status="" data-key="11" data-clientid="" data-clientname="" data-newclient="" data-extended="" data-primaryid="" data-invoiced="" data-caseid="" data-type="">
    
    <div class="DiaryColumn" >

<!-- Start Lunch Time -->
<!-- End Lunch Time -->
	
<!-- Start Populate Slot -->
<!-- End Populate Slot -->
    
    
    </div>
    </div>
    <!-- End Diary Column -->
    <!-- Start Diary Column -->
    <div class="DiaryColumnContainer ContextOn 11 EmptySlots" style="cursor:pointer;" data-apptid="" data-time="09:20" data-staffid="6" data-staffname="Karen  Kitchener" data-status="" data-key="11" data-clientid="" data-clientname="" data-newclient="" data-extended="" data-primaryid="" data-invoiced="" data-caseid="" data-type="">
    
    <div class="DiaryColumn" >

<!-- Start Lunch Time -->
<!-- End Lunch Time -->
	
<!-- Start Populate Slot -->
<!-- End Populate Slot -->
    
    
    </div>
    </div>
    <!-- End Diary Column -->
    <!-- Start Diary Column -->
    <div class="DiaryColumnContainer ContextOn 12 EmptySlots" style="cursor:pointer;" data-apptid="" data-time="09:30" data-staffid="26" data-staffname="Bec Webberley" data-status="" data-key="12" data-clientid="" data-clientname="" data-newclient="" data-extended="" data-primaryid="" data-invoiced="" data-caseid="" data-type="">
    
    <div class="DiaryColumn" >

<!-- Start Lunch Time -->
<!-- End Lunch Time -->
	
<!-- Start Populate Slot -->
<!-- End Populate Slot -->
    
    
    </div>
    </div>
    <!-- End Diary Column -->
    <!-- Start Diary Column -->
    <div class="DiaryColumnContainer ContextOn 12 EmptySlots" style="cursor:pointer;" data-apptid="" data-time="09:30" data-staffid="7" data-staffname="Tamara Shaw" data-status="" data-key="12" data-clientid="" data-clientname="" data-newclient="" data-extended="" data-primaryid="" data-invoiced="" data-caseid="" data-type="">
    
    <div class="DiaryColumn" >

<!-- Start Lunch Time -->
<!-- End Lunch Time -->
	
<!-- Start Populate Slot -->
<!-- End Populate Slot -->
    
    
    </div>
    </div>
    <!-- End Diary Column -->
    <!-- Start Diary Column -->
    <div class="DiaryColumnContainer ContextOn 12 FilledSlots" style="cursor:pointer;" data-apptid="28898" data-time="09:30" data-staffid="16" data-staffname="Olivia  Moy" data-status="Completed" data-key="12" data-clientid="390" data-clientname="Marie Holmes" data-newclient="0" data-extended="1" data-primaryid="0" data-invoiced="" data-caseid="878" data-type="Services">
    
    <div class="DiaryColumnSchedule" style="color:#003399; background-color:#D0CEFF;">

<!-- Start Lunch Time -->
<!-- End Lunch Time -->
	
<!-- Start Populate Slot -->
    <div class="ClientType SlotContent" style="float:left; width:15px; background-color:#006; color:#FFF; margin-left:2px; margin-top:2px;">P</div>
    

    <div class="Patient SlotContent DiaryToolTip" 
    title="<span>Provider : Olivia  Moy<hr />Date : 19/07/2012 - Time : 09:30</span><hr />Marie Holmes<br /><br />Contact No : 0407659558<hr />Remedial Massage 1 Hr<hr />Case : Massage<hr />" 
    style="float:left; margin:2px 0px 0px 5px; font-weight:bold; font-size:11px; ">
	Marie Holmes    
    </div>

<!-- End Populate Slot -->
    
    
    </div>
    </div>
    <!-- End Diary Column -->
    <!-- Start Diary Column -->
    <div class="DiaryColumnContainer ContextOn 12 EmptySlots" style="cursor:pointer;" data-apptid="" data-time="09:30" data-staffid="18" data-staffname="Andrew  Rashleigh" data-status="" data-key="12" data-clientid="" data-clientname="" data-newclient="" data-extended="" data-primaryid="" data-invoiced="" data-caseid="" data-type="">
    
    <div class="DiaryColumn" >

<!-- Start Lunch Time -->
<!-- End Lunch Time -->
	
<!-- Start Populate Slot -->
<!-- End Populate Slot -->
    
    
    </div>
    </div>
    <!-- End Diary Column -->
    <!-- Start Diary Column -->
    <div class="DiaryColumnContainer ContextOn 12 EmptySlots" style="cursor:pointer;" data-apptid="" data-time="09:30" data-staffid="14" data-staffname="Emile  Cloete" data-status="" data-key="12" data-clientid="" data-clientname="" data-newclient="" data-extended="" data-primaryid="" data-invoiced="" data-caseid="" data-type="">
    
    <div class="DiaryColumn" >

<!-- Start Lunch Time -->
<!-- End Lunch Time -->
	
<!-- Start Populate Slot -->
<!-- End Populate Slot -->
    
    
    </div>
    </div>
    <!-- End Diary Column -->
    <!-- Start Diary Column -->
    <div class="DiaryColumnContainer ContextOn 12 EmptySlots" style="cursor:pointer;" data-apptid="" data-time="09:30" data-staffid="1" data-staffname="Darren  Rieck" data-status="" data-key="12" data-clientid="" data-clientname="" data-newclient="" data-extended="" data-primaryid="" data-invoiced="" data-caseid="" data-type="">
    
    <div class="DiaryColumn" >

<!-- Start Lunch Time -->
<!-- End Lunch Time -->
	
<!-- Start Populate Slot -->
<!-- End Populate Slot -->
    
    
    </div>
    </div>
    <!-- End Diary Column -->
    <!-- Start Diary Column -->
    <div class="DiaryColumnContainer ContextOn 12 EmptySlots" style="cursor:pointer;" data-apptid="" data-time="09:30" data-staffid="6" data-staffname="Karen  Kitchener" data-status="" data-key="12" data-clientid="" data-clientname="" data-newclient="" data-extended="" data-primaryid="" data-invoiced="" data-caseid="" data-type="">
    
    <div class="DiaryColumn" >

<!-- Start Lunch Time -->
<!-- End Lunch Time -->
	
<!-- Start Populate Slot -->
<!-- End Populate Slot -->
    
    
    </div>
    </div>
    <!-- End Diary Column -->
    <!-- Start Diary Column -->
    <div class="DiaryColumnContainer ContextOn 13 EmptySlots" style="cursor:pointer;" data-apptid="" data-time="09:40" data-staffid="26" data-staffname="Bec Webberley" data-status="" data-key="13" data-clientid="" data-clientname="" data-newclient="" data-extended="" data-primaryid="" data-invoiced="" data-caseid="" data-type="">
    
    <div class="DiaryColumn" >

<!-- Start Lunch Time -->
<!-- End Lunch Time -->
	
<!-- Start Populate Slot -->
<!-- End Populate Slot -->
    
    
    </div>
    </div>
    <!-- End Diary Column -->
    <!-- Start Diary Column -->
    <div class="DiaryColumnContainer ContextOn 13 EmptySlots" style="cursor:pointer;" data-apptid="" data-time="09:40" data-staffid="7" data-staffname="Tamara Shaw" data-status="" data-key="13" data-clientid="" data-clientname="" data-newclient="" data-extended="" data-primaryid="" data-invoiced="" data-caseid="" data-type="">
    
    <div class="DiaryColumn" >

<!-- Start Lunch Time -->
<!-- End Lunch Time -->
	
<!-- Start Populate Slot -->
<!-- End Populate Slot -->
    
    
    </div>
    </div>
    <!-- End Diary Column -->
    <!-- Start Diary Column -->
    <div class="DiaryColumnContainer ContextOff 13 " style="cursor:not-allowed;" data-apptid="28899" data-time="09:40" data-staffid="16" data-staffname="Olivia  Moy" data-status="Completed" data-key="13" data-clientid="390" data-clientname="Marie Holmes" data-newclient="0" data-extended="0" data-primaryid="28898" data-invoiced="" data-caseid="" data-type="Services">
    
    <div class="DiaryColumnSchedule" style="color:#003399; background-color:#D0CEFF;">

<!-- Start Lunch Time -->
<!-- End Lunch Time -->
	
<!-- Start Populate Slot -->
<!-- End Populate Slot -->
    
    
    </div>
    </div>
    <!-- End Diary Column -->
    <!-- Start Diary Column -->
    <div class="DiaryColumnContainer ContextOn 13 EmptySlots" style="cursor:pointer;" data-apptid="" data-time="09:40" data-staffid="18" data-staffname="Andrew  Rashleigh" data-status="" data-key="13" data-clientid="" data-clientname="" data-newclient="" data-extended="" data-primaryid="" data-invoiced="" data-caseid="" data-type="">
    
    <div class="DiaryColumn" >

<!-- Start Lunch Time -->
<!-- End Lunch Time -->
	
<!-- Start Populate Slot -->
<!-- End Populate Slot -->
    
    
    </div>
    </div>
    <!-- End Diary Column -->
    <!-- Start Diary Column -->
    <div class="DiaryColumnContainer ContextOn 13 EmptySlots" style="cursor:pointer;" data-apptid="" data-time="09:40" data-staffid="14" data-staffname="Emile  Cloete" data-status="" data-key="13" data-clientid="" data-clientname="" data-newclient="" data-extended="" data-primaryid="" data-invoiced="" data-caseid="" data-type="">
    
    <div class="DiaryColumn" >

<!-- Start Lunch Time -->
<!-- End Lunch Time -->
	
<!-- Start Populate Slot -->
<!-- End Populate Slot -->
    
    
    </div>
    </div>
    <!-- End Diary Column -->
    <!-- Start Diary Column -->
    <div class="DiaryColumnContainer ContextOn 13 EmptySlots" style="cursor:pointer;" data-apptid="" data-time="09:40" data-staffid="1" data-staffname="Darren  Rieck" data-status="" data-key="13" data-clientid="" data-clientname="" data-newclient="" data-extended="" data-primaryid="" data-invoiced="" data-caseid="" data-type="">
    
    <div class="DiaryColumn" >

<!-- Start Lunch Time -->
<!-- End Lunch Time -->
	
<!-- Start Populate Slot -->
<!-- End Populate Slot -->
    
    
    </div>
    </div>
    <!-- End Diary Column -->
    <!-- Start Diary Column -->
    <div class="DiaryColumnContainer ContextOn 13 EmptySlots" style="cursor:pointer;" data-apptid="" data-time="09:40" data-staffid="6" data-staffname="Karen  Kitchener" data-status="" data-key="13" data-clientid="" data-clientname="" data-newclient="" data-extended="" data-primaryid="" data-invoiced="" data-caseid="" data-type="">
    
    <div class="DiaryColumn" >

<!-- Start Lunch Time -->
<!-- End Lunch Time -->
	
<!-- Start Populate Slot -->
<!-- End Populate Slot -->
    
    
    </div>
    </div>
    <!-- End Diary Column -->
    <!-- Start Diary Column -->
    <div class="DiaryColumnContainer ContextOn 14 EmptySlots" style="cursor:pointer;" data-apptid="" data-time="09:50" data-staffid="26" data-staffname="Bec Webberley" data-status="" data-key="14" data-clientid="" data-clientname="" data-newclient="" data-extended="" data-primaryid="" data-invoiced="" data-caseid="" data-type="">
    
    <div class="DiaryColumn" >

<!-- Start Lunch Time -->
<!-- End Lunch Time -->
	
<!-- Start Populate Slot -->
<!-- End Populate Slot -->
    
    
    </div>
    </div>
    <!-- End Diary Column -->
    <!-- Start Diary Column -->
    <div class="DiaryColumnContainer ContextOn 14 EmptySlots" style="cursor:pointer;" data-apptid="" data-time="09:50" data-staffid="7" data-staffname="Tamara Shaw" data-status="" data-key="14" data-clientid="" data-clientname="" data-newclient="" data-extended="" data-primaryid="" data-invoiced="" data-caseid="" data-type="">
    
    <div class="DiaryColumn" >

<!-- Start Lunch Time -->
<!-- End Lunch Time -->
	
<!-- Start Populate Slot -->
<!-- End Populate Slot -->
    
    
    </div>
    </div>
    <!-- End Diary Column -->
    <!-- Start Diary Column -->
    <div class="DiaryColumnContainer ContextOff 14 " style="cursor:not-allowed;" data-apptid="28900" data-time="09:50" data-staffid="16" data-staffname="Olivia  Moy" data-status="Completed" data-key="14" data-clientid="390" data-clientname="Marie Holmes" data-newclient="0" data-extended="0" data-primaryid="28898" data-invoiced="" data-caseid="" data-type="Services">
    
    <div class="DiaryColumnSchedule" style="color:#003399; background-color:#D0CEFF;">

<!-- Start Lunch Time -->
<!-- End Lunch Time -->
	
<!-- Start Populate Slot -->
<!-- End Populate Slot -->
    
    
    </div>
    </div>
    <!-- End Diary Column -->
    <!-- Start Diary Column -->
    <div class="DiaryColumnContainer ContextOn 14 EmptySlots" style="cursor:pointer;" data-apptid="" data-time="09:50" data-staffid="18" data-staffname="Andrew  Rashleigh" data-status="" data-key="14" data-clientid="" data-clientname="" data-newclient="" data-extended="" data-primaryid="" data-invoiced="" data-caseid="" data-type="">
    
    <div class="DiaryColumn" >

<!-- Start Lunch Time -->
<!-- End Lunch Time -->
	
<!-- Start Populate Slot -->
<!-- End Populate Slot -->
    
    
    </div>
    </div>
    <!-- End Diary Column -->
    <!-- Start Diary Column -->
    <div class="DiaryColumnContainer ContextOn 14 EmptySlots" style="cursor:pointer;" data-apptid="" data-time="09:50" data-staffid="14" data-staffname="Emile  Cloete" data-status="" data-key="14" data-clientid="" data-clientname="" data-newclient="" data-extended="" data-primaryid="" data-invoiced="" data-caseid="" data-type="">
    
    <div class="DiaryColumn" >

<!-- Start Lunch Time -->
<!-- End Lunch Time -->
	
<!-- Start Populate Slot -->
<!-- End Populate Slot -->
    
    
    </div>
    </div>
    <!-- End Diary Column -->
    <!-- Start Diary Column -->
    <div class="DiaryColumnContainer ContextOn 14 EmptySlots" style="cursor:pointer;" data-apptid="" data-time="09:50" data-staffid="1" data-staffname="Darren  Rieck" data-status="" data-key="14" data-clientid="" data-clientname="" data-newclient="" data-extended="" data-primaryid="" data-invoiced="" data-caseid="" data-type="">
    
    <div class="DiaryColumn" >

<!-- Start Lunch Time -->
<!-- End Lunch Time -->
	
<!-- Start Populate Slot -->
<!-- End Populate Slot -->
    
    
    </div>
    </div>
    <!-- End Diary Column -->
    <!-- Start Diary Column -->
    <div class="DiaryColumnContainer ContextOn 14 EmptySlots" style="cursor:pointer;" data-apptid="" data-time="09:50" data-staffid="6" data-staffname="Karen  Kitchener" data-status="" data-key="14" data-clientid="" data-clientname="" data-newclient="" data-extended="" data-primaryid="" data-invoiced="" data-caseid="" data-type="">
    
    <div class="DiaryColumn" >

<!-- Start Lunch Time -->
<!-- End Lunch Time -->
	
<!-- Start Populate Slot -->
<!-- End Populate Slot -->
    
    
    </div>
    </div>
    <!-- End Diary Column -->
    <!-- Start Diary Column -->
    <div class="DiaryColumnContainer ContextOn 15 EmptySlots" style="cursor:pointer;" data-apptid="" data-time="10:00" data-staffid="26" data-staffname="Bec Webberley" data-status="" data-key="15" data-clientid="" data-clientname="" data-newclient="" data-extended="" data-primaryid="" data-invoiced="" data-caseid="" data-type="">
    
    <div class="DiaryColumn" >

<!-- Start Lunch Time -->
<!-- End Lunch Time -->
	
<!-- Start Populate Slot -->
<!-- End Populate Slot -->
    
    
    </div>
    </div>
    <!-- End Diary Column -->
    <!-- Start Diary Column -->
    <div class="DiaryColumnContainer ContextOn 15 FilledSlots" style="cursor:pointer;" data-apptid="18932" data-time="10:00" data-staffid="7" data-staffname="Tamara Shaw" data-status="Completed" data-key="15" data-clientid="252" data-clientname="Maria Kober" data-newclient="0" data-extended="1" data-primaryid="0" data-invoiced="" data-caseid="563" data-type="Services">
    
    <div class="DiaryColumnSchedule" style="color:#003399; background-color:#D0CEFF;">

<!-- Start Lunch Time -->
<!-- End Lunch Time -->
	
<!-- Start Populate Slot -->
    <div class="ClientType SlotContent" style="float:left; width:15px; background-color:#006; color:#FFF; margin-left:2px; margin-top:2px;">P</div>
    

    <div class="Patient SlotContent DiaryToolTip" 
    title="<span>Provider : Tamara Shaw<hr />Date : 19/07/2012 - Time : 10:00</span><hr />Maria Kober<br /><br />Contact No : 0412116800<hr /><span>10% Discount</span><hr />Private -  Physio Std<hr />Case : PVT: Neck/Back<hr />" 
    style="float:left; margin:2px 0px 0px 5px; font-weight:bold; font-size:11px; ">
	Maria Kober    
    </div>

<!-- End Populate Slot -->
    
    
    </div>
    </div>
    <!-- End Diary Column -->
    <!-- Start Diary Column -->
    <div class="DiaryColumnContainer ContextOff 15 " style="cursor:not-allowed;" data-apptid="28901" data-time="10:00" data-staffid="16" data-staffname="Olivia  Moy" data-status="Completed" data-key="15" data-clientid="390" data-clientname="Marie Holmes" data-newclient="0" data-extended="0" data-primaryid="28898" data-invoiced="" data-caseid="" data-type="Services">
    
    <div class="DiaryColumnSchedule" style="color:#003399; background-color:#D0CEFF;">

<!-- Start Lunch Time -->
<!-- End Lunch Time -->
	
<!-- Start Populate Slot -->
<!-- End Populate Slot -->
    
    
    </div>
    </div>
    <!-- End Diary Column -->
    <!-- Start Diary Column -->
    <div class="DiaryColumnContainer ContextOn 15 EmptySlots" style="cursor:pointer;" data-apptid="" data-time="10:00" data-staffid="18" data-staffname="Andrew  Rashleigh" data-status="" data-key="15" data-clientid="" data-clientname="" data-newclient="" data-extended="" data-primaryid="" data-invoiced="" data-caseid="" data-type="">
    
    <div class="DiaryColumn" >

<!-- Start Lunch Time -->
<!-- End Lunch Time -->
	
<!-- Start Populate Slot -->
<!-- End Populate Slot -->
    
    
    </div>
    </div>
    <!-- End Diary Column -->
    <!-- Start Diary Column -->
    <div class="DiaryColumnContainer ContextOn 15 EmptySlots" style="cursor:pointer;" data-apptid="" data-time="10:00" data-staffid="14" data-staffname="Emile  Cloete" data-status="" data-key="15" data-clientid="" data-clientname="" data-newclient="" data-extended="" data-primaryid="" data-invoiced="" data-caseid="" data-type="">
    
    <div class="DiaryColumn" >

<!-- Start Lunch Time -->
<!-- End Lunch Time -->
	
<!-- Start Populate Slot -->
<!-- End Populate Slot -->
    
    
    </div>
    </div>
    <!-- End Diary Column -->
    <!-- Start Diary Column -->
    <div class="DiaryColumnContainer ContextOn 15 EmptySlots" style="cursor:pointer;" data-apptid="" data-time="10:00" data-staffid="1" data-staffname="Darren  Rieck" data-status="" data-key="15" data-clientid="" data-clientname="" data-newclient="" data-extended="" data-primaryid="" data-invoiced="" data-caseid="" data-type="">
    
    <div class="DiaryColumn" >

<!-- Start Lunch Time -->
<!-- End Lunch Time -->
	
<!-- Start Populate Slot -->
<!-- End Populate Slot -->
    
    
    </div>
    </div>
    <!-- End Diary Column -->
    <!-- Start Diary Column -->
    <div class="DiaryColumnContainer ContextOn 15 EmptySlots" style="cursor:pointer;" data-apptid="" data-time="10:00" data-staffid="6" data-staffname="Karen  Kitchener" data-status="" data-key="15" data-clientid="" data-clientname="" data-newclient="" data-extended="" data-primaryid="" data-invoiced="" data-caseid="" data-type="">
    
    <div class="DiaryColumn" >

<!-- Start Lunch Time -->
<!-- End Lunch Time -->
	
<!-- Start Populate Slot -->
<!-- End Populate Slot -->
    
    
    </div>
    </div>
    <!-- End Diary Column -->
    <!-- Start Diary Column -->
    <div class="DiaryColumnContainer ContextOn 16 EmptySlots" style="cursor:pointer;" data-apptid="" data-time="10:10" data-staffid="26" data-staffname="Bec Webberley" data-status="" data-key="16" data-clientid="" data-clientname="" data-newclient="" data-extended="" data-primaryid="" data-invoiced="" data-caseid="" data-type="">
    
    <div class="DiaryColumn" >

<!-- Start Lunch Time -->
<!-- End Lunch Time -->
	
<!-- Start Populate Slot -->
<!-- End Populate Slot -->
    
    
    </div>
    </div>
    <!-- End Diary Column -->
    <!-- Start Diary Column -->
    <div class="DiaryColumnContainer ContextOff 16 " style="cursor:not-allowed;" data-apptid="18933" data-time="10:10" data-staffid="7" data-staffname="Tamara Shaw" data-status="Completed" data-key="16" data-clientid="252" data-clientname="Maria Kober" data-newclient="0" data-extended="0" data-primaryid="18932" data-invoiced="" data-caseid="" data-type="Services">
    
    <div class="DiaryColumnSchedule" style="color:#003399; background-color:#D0CEFF;">

<!-- Start Lunch Time -->
<!-- End Lunch Time -->
	
<!-- Start Populate Slot -->
<!-- End Populate Slot -->
    
    
    </div>
    </div>
    <!-- End Diary Column -->
    <!-- Start Diary Column -->
    <div class="DiaryColumnContainer ContextOff 16 " style="cursor:not-allowed;" data-apptid="28902" data-time="10:10" data-staffid="16" data-staffname="Olivia  Moy" data-status="Completed" data-key="16" data-clientid="390" data-clientname="Marie Holmes" data-newclient="0" data-extended="0" data-primaryid="28898" data-invoiced="" data-caseid="" data-type="Services">
    
    <div class="DiaryColumnSchedule" style="color:#003399; background-color:#D0CEFF;">

<!-- Start Lunch Time -->
<!-- End Lunch Time -->
	
<!-- Start Populate Slot -->
<!-- End Populate Slot -->
    
    
    </div>
    </div>
    <!-- End Diary Column -->
    <!-- Start Diary Column -->
    <div class="DiaryColumnContainer ContextOn 16 EmptySlots" style="cursor:pointer;" data-apptid="" data-time="10:10" data-staffid="18" data-staffname="Andrew  Rashleigh" data-status="" data-key="16" data-clientid="" data-clientname="" data-newclient="" data-extended="" data-primaryid="" data-invoiced="" data-caseid="" data-type="">
    
    <div class="DiaryColumn" >

<!-- Start Lunch Time -->
<!-- End Lunch Time -->
	
<!-- Start Populate Slot -->
<!-- End Populate Slot -->
    
    
    </div>
    </div>
    <!-- End Diary Column -->
    <!-- Start Diary Column -->
    <div class="DiaryColumnContainer ContextOn 16 EmptySlots" style="cursor:pointer;" data-apptid="" data-time="10:10" data-staffid="14" data-staffname="Emile  Cloete" data-status="" data-key="16" data-clientid="" data-clientname="" data-newclient="" data-extended="" data-primaryid="" data-invoiced="" data-caseid="" data-type="">
    
    <div class="DiaryColumn" >

<!-- Start Lunch Time -->
<!-- End Lunch Time -->
	
<!-- Start Populate Slot -->
<!-- End Populate Slot -->
    
    
    </div>
    </div>
    <!-- End Diary Column -->
    <!-- Start Diary Column -->
    <div class="DiaryColumnContainer ContextOn 16 EmptySlots" style="cursor:pointer;" data-apptid="" data-time="10:10" data-staffid="1" data-staffname="Darren  Rieck" data-status="" data-key="16" data-clientid="" data-clientname="" data-newclient="" data-extended="" data-primaryid="" data-invoiced="" data-caseid="" data-type="">
    
    <div class="DiaryColumn" >

<!-- Start Lunch Time -->
<!-- End Lunch Time -->
	
<!-- Start Populate Slot -->
<!-- End Populate Slot -->
    
    
    </div>
    </div>
    <!-- End Diary Column -->
    <!-- Start Diary Column -->
    <div class="DiaryColumnContainer ContextOn 16 EmptySlots" style="cursor:pointer;" data-apptid="" data-time="10:10" data-staffid="6" data-staffname="Karen  Kitchener" data-status="" data-key="16" data-clientid="" data-clientname="" data-newclient="" data-extended="" data-primaryid="" data-invoiced="" data-caseid="" data-type="">
    
    <div class="DiaryColumn" >

<!-- Start Lunch Time -->
<!-- End Lunch Time -->
	
<!-- Start Populate Slot -->
<!-- End Populate Slot -->
    
    
    </div>
    </div>
    <!-- End Diary Column -->
    <!-- Start Diary Column -->
    <div class="DiaryColumnContainer ContextOn 17 EmptySlots" style="cursor:pointer;" data-apptid="" data-time="10:20" data-staffid="26" data-staffname="Bec Webberley" data-status="" data-key="17" data-clientid="" data-clientname="" data-newclient="" data-extended="" data-primaryid="" data-invoiced="" data-caseid="" data-type="">
    
    <div class="DiaryColumn" >

<!-- Start Lunch Time -->
<!-- End Lunch Time -->
	
<!-- Start Populate Slot -->
<!-- End Populate Slot -->
    
    
    </div>
    </div>
    <!-- End Diary Column -->
    <!-- Start Diary Column -->
    <div class="DiaryColumnContainer ContextOff 17 " style="cursor:not-allowed;" data-apptid="18934" data-time="10:20" data-staffid="7" data-staffname="Tamara Shaw" data-status="Completed" data-key="17" data-clientid="252" data-clientname="Maria Kober" data-newclient="0" data-extended="0" data-primaryid="18932" data-invoiced="" data-caseid="" data-type="Services">
    
    <div class="DiaryColumnSchedule" style="color:#003399; background-color:#D0CEFF;">

<!-- Start Lunch Time -->
<!-- End Lunch Time -->
	
<!-- Start Populate Slot -->
<!-- End Populate Slot -->
    
    
    </div>
    </div>
    <!-- End Diary Column -->
    <!-- Start Diary Column -->
    <div class="DiaryColumnContainer ContextOff 17 " style="cursor:not-allowed;" data-apptid="28903" data-time="10:20" data-staffid="16" data-staffname="Olivia  Moy" data-status="Completed" data-key="17" data-clientid="390" data-clientname="Marie Holmes" data-newclient="0" data-extended="0" data-primaryid="28898" data-invoiced="" data-caseid="" data-type="Services">
    
    <div class="DiaryColumnSchedule" style="color:#003399; background-color:#D0CEFF;">

<!-- Start Lunch Time -->
<!-- End Lunch Time -->
	
<!-- Start Populate Slot -->
<!-- End Populate Slot -->
    
    
    </div>
    </div>
    <!-- End Diary Column -->
    <!-- Start Diary Column -->
    <div class="DiaryColumnContainer ContextOn 17 EmptySlots" style="cursor:pointer;" data-apptid="" data-time="10:20" data-staffid="18" data-staffname="Andrew  Rashleigh" data-status="" data-key="17" data-clientid="" data-clientname="" data-newclient="" data-extended="" data-primaryid="" data-invoiced="" data-caseid="" data-type="">
    
    <div class="DiaryColumn" >

<!-- Start Lunch Time -->
<!-- End Lunch Time -->
	
<!-- Start Populate Slot -->
<!-- End Populate Slot -->
    
    
    </div>
    </div>
    <!-- End Diary Column -->
    <!-- Start Diary Column -->
    <div class="DiaryColumnContainer ContextOn 17 EmptySlots" style="cursor:pointer;" data-apptid="" data-time="10:20" data-staffid="14" data-staffname="Emile  Cloete" data-status="" data-key="17" data-clientid="" data-clientname="" data-newclient="" data-extended="" data-primaryid="" data-invoiced="" data-caseid="" data-type="">
    
    <div class="DiaryColumn" >

<!-- Start Lunch Time -->
<!-- End Lunch Time -->
	
<!-- Start Populate Slot -->
<!-- End Populate Slot -->
    
    
    </div>
    </div>
    <!-- End Diary Column -->
    <!-- Start Diary Column -->
    <div class="DiaryColumnContainer ContextOn 17 EmptySlots" style="cursor:pointer;" data-apptid="" data-time="10:20" data-staffid="1" data-staffname="Darren  Rieck" data-status="" data-key="17" data-clientid="" data-clientname="" data-newclient="" data-extended="" data-primaryid="" data-invoiced="" data-caseid="" data-type="">
    
    <div class="DiaryColumn" >

<!-- Start Lunch Time -->
<!-- End Lunch Time -->
	
<!-- Start Populate Slot -->
<!-- End Populate Slot -->
    
    
    </div>
    </div>
    <!-- End Diary Column -->
    <!-- Start Diary Column -->
    <div class="DiaryColumnContainer ContextOn 17 EmptySlots" style="cursor:pointer;" data-apptid="" data-time="10:20" data-staffid="6" data-staffname="Karen  Kitchener" data-status="" data-key="17" data-clientid="" data-clientname="" data-newclient="" data-extended="" data-primaryid="" data-invoiced="" data-caseid="" data-type="">
    
    <div class="DiaryColumn" >

<!-- Start Lunch Time -->
<!-- End Lunch Time -->
	
<!-- Start Populate Slot -->
<!-- End Populate Slot -->
    
    
    </div>
    </div>
    <!-- End Diary Column -->
    <!-- Start Diary Column -->
    <div class="DiaryColumnContainer ContextOn 18 EmptySlots" style="cursor:pointer;" data-apptid="" data-time="10:30" data-staffid="26" data-staffname="Bec Webberley" data-status="" data-key="18" data-clientid="" data-clientname="" data-newclient="" data-extended="" data-primaryid="" data-invoiced="" data-caseid="" data-type="">
    
    <div class="DiaryColumn" >

<!-- Start Lunch Time -->
<!-- End Lunch Time -->
	
<!-- Start Populate Slot -->
<!-- End Populate Slot -->
    
    
    </div>
    </div>
    <!-- End Diary Column -->
    <!-- Start Diary Column -->
    <div class="DiaryColumnContainer ContextOn 18 FilledSlots" style="cursor:pointer;" data-apptid="28904" data-time="10:30" data-staffid="7" data-staffname="Tamara Shaw" data-status="Completed" data-key="18" data-clientid="390" data-clientname="Marie Holmes" data-newclient="0" data-extended="1" data-primaryid="0" data-invoiced="" data-caseid="879" data-type="Services">
    
    <div class="DiaryColumnSchedule" style="color:#003399; background-color:#D0CEFF;">

<!-- Start Lunch Time -->
<!-- End Lunch Time -->
	
<!-- Start Populate Slot -->
    <div class="ClientType SlotContent" style="float:left; width:15px; background-color:#006; color:#FFF; margin-left:2px; margin-top:2px;">P</div>
    

    <div class="Patient SlotContent DiaryToolTip" 
    title="<span>Provider : Tamara Shaw<hr />Date : 19/07/2012 - Time : 10:30</span><hr />Marie Holmes<br /><br />Contact No : 0407659558<hr />Private -  Physio Std<hr />Case : PVT<hr />" 
    style="float:left; margin:2px 0px 0px 5px; font-weight:bold; font-size:11px; ">
	Marie Holmes    
    </div>

<!-- End Populate Slot -->
    
    
    </div>
    </div>
    <!-- End Diary Column -->
    <!-- Start Diary Column -->
    <div class="DiaryColumnContainer ContextOn 18 FilledSlots" style="cursor:pointer;" data-apptid="30801" data-time="10:30" data-staffid="16" data-staffname="Olivia  Moy" data-status="Completed" data-key="18" data-clientid="1258" data-clientname="Roselyne Murcutt" data-newclient="0" data-extended="1" data-primaryid="0" data-invoiced="" data-caseid="2711" data-type="Services">
    
    <div class="DiaryColumnSchedule" style="color:#003399; background-color:#D0CEFF;">

<!-- Start Lunch Time -->
<!-- End Lunch Time -->
	
<!-- Start Populate Slot -->
    <div class="ClientType SlotContent" style="float:left; width:15px; background-color:#006; color:#FFF; margin-left:2px; margin-top:2px;">P</div>
    

    <div class="Patient SlotContent DiaryToolTip" 
    title="<span>Provider : Olivia  Moy<hr />Date : 19/07/2012 - Time : 10:30</span><hr />Roselyne Murcutt<br /><br />Contact No : 0424039560<hr /><span>med cert to 03.08</span><hr />Remedial Massage 1 Hr<hr />Case : Massage<hr />" 
    style="float:left; margin:2px 0px 0px 5px; font-weight:bold; font-size:11px; ">
	Roselyne Murcutt    
    </div>

<!-- End Populate Slot -->
    
    
    </div>
    </div>
    <!-- End Diary Column -->
    <!-- Start Diary Column -->
    <div class="DiaryColumnContainer ContextOn 18 EmptySlots" style="cursor:pointer;" data-apptid="" data-time="10:30" data-staffid="18" data-staffname="Andrew  Rashleigh" data-status="" data-key="18" data-clientid="" data-clientname="" data-newclient="" data-extended="" data-primaryid="" data-invoiced="" data-caseid="" data-type="">
    
    <div class="DiaryColumn" >

<!-- Start Lunch Time -->
<!-- End Lunch Time -->
	
<!-- Start Populate Slot -->
<!-- End Populate Slot -->
    
    
    </div>
    </div>
    <!-- End Diary Column -->
    <!-- Start Diary Column -->
    <div class="DiaryColumnContainer ContextOn 18 EmptySlots" style="cursor:pointer;" data-apptid="" data-time="10:30" data-staffid="14" data-staffname="Emile  Cloete" data-status="" data-key="18" data-clientid="" data-clientname="" data-newclient="" data-extended="" data-primaryid="" data-invoiced="" data-caseid="" data-type="">
    
    <div class="DiaryColumn" >

<!-- Start Lunch Time -->
<!-- End Lunch Time -->
	
<!-- Start Populate Slot -->
<!-- End Populate Slot -->
    
    
    </div>
    </div>
    <!-- End Diary Column -->
    <!-- Start Diary Column -->
    <div class="DiaryColumnContainer ContextOn 18 EmptySlots" style="cursor:pointer;" data-apptid="" data-time="10:30" data-staffid="1" data-staffname="Darren  Rieck" data-status="" data-key="18" data-clientid="" data-clientname="" data-newclient="" data-extended="" data-primaryid="" data-invoiced="" data-caseid="" data-type="">
    
    <div class="DiaryColumn" >

<!-- Start Lunch Time -->
<!-- End Lunch Time -->
	
<!-- Start Populate Slot -->
<!-- End Populate Slot -->
    
    
    </div>
    </div>
    <!-- End Diary Column -->
    <!-- Start Diary Column -->
    <div class="DiaryColumnContainer ContextOn 18 EmptySlots" style="cursor:pointer;" data-apptid="" data-time="10:30" data-staffid="6" data-staffname="Karen  Kitchener" data-status="" data-key="18" data-clientid="" data-clientname="" data-newclient="" data-extended="" data-primaryid="" data-invoiced="" data-caseid="" data-type="">
    
    <div class="DiaryColumn" >

<!-- Start Lunch Time -->
<!-- End Lunch Time -->
	
<!-- Start Populate Slot -->
<!-- End Populate Slot -->
    
    
    </div>
    </div>
    <!-- End Diary Column -->
    <!-- Start Diary Column -->
    <div class="DiaryColumnContainer ContextOn 19 EmptySlots" style="cursor:pointer;" data-apptid="" data-time="10:40" data-staffid="26" data-staffname="Bec Webberley" data-status="" data-key="19" data-clientid="" data-clientname="" data-newclient="" data-extended="" data-primaryid="" data-invoiced="" data-caseid="" data-type="">
    
    <div class="DiaryColumn" >

<!-- Start Lunch Time -->
<!-- End Lunch Time -->
	
<!-- Start Populate Slot -->
<!-- End Populate Slot -->
    
    
    </div>
    </div>
    <!-- End Diary Column -->
    <!-- Start Diary Column -->
    <div class="DiaryColumnContainer ContextOff 19 " style="cursor:not-allowed;" data-apptid="28905" data-time="10:40" data-staffid="7" data-staffname="Tamara Shaw" data-status="Completed" data-key="19" data-clientid="390" data-clientname="Marie Holmes" data-newclient="0" data-extended="0" data-primaryid="28904" data-invoiced="" data-caseid="" data-type="Services">
    
    <div class="DiaryColumnSchedule" style="color:#003399; background-color:#D0CEFF;">

<!-- Start Lunch Time -->
<!-- End Lunch Time -->
	
<!-- Start Populate Slot -->
<!-- End Populate Slot -->
    
    
    </div>
    </div>
    <!-- End Diary Column -->
    <!-- Start Diary Column -->
    <div class="DiaryColumnContainer ContextOff 19 " style="cursor:not-allowed;" data-apptid="30802" data-time="10:40" data-staffid="16" data-staffname="Olivia  Moy" data-status="Completed" data-key="19" data-clientid="1258" data-clientname="Roselyne Murcutt" data-newclient="0" data-extended="0" data-primaryid="30801" data-invoiced="" data-caseid="" data-type="Services">
    
    <div class="DiaryColumnSchedule" style="color:#003399; background-color:#D0CEFF;">

<!-- Start Lunch Time -->
<!-- End Lunch Time -->
	
<!-- Start Populate Slot -->
<!-- End Populate Slot -->
    
    
    </div>
    </div>
    <!-- End Diary Column -->
    <!-- Start Diary Column -->
    <div class="DiaryColumnContainer ContextOn 19 EmptySlots" style="cursor:pointer;" data-apptid="" data-time="10:40" data-staffid="18" data-staffname="Andrew  Rashleigh" data-status="" data-key="19" data-clientid="" data-clientname="" data-newclient="" data-extended="" data-primaryid="" data-invoiced="" data-caseid="" data-type="">
    
    <div class="DiaryColumn" >

<!-- Start Lunch Time -->
<!-- End Lunch Time -->
	
<!-- Start Populate Slot -->
<!-- End Populate Slot -->
    
    
    </div>
    </div>
    <!-- End Diary Column -->
    <!-- Start Diary Column -->
    <div class="DiaryColumnContainer ContextOn 19 EmptySlots" style="cursor:pointer;" data-apptid="" data-time="10:40" data-staffid="14" data-staffname="Emile  Cloete" data-status="" data-key="19" data-clientid="" data-clientname="" data-newclient="" data-extended="" data-primaryid="" data-invoiced="" data-caseid="" data-type="">
    
    <div class="DiaryColumn" >

<!-- Start Lunch Time -->
<!-- End Lunch Time -->
	
<!-- Start Populate Slot -->
<!-- End Populate Slot -->
    
    
    </div>
    </div>
    <!-- End Diary Column -->
    <!-- Start Diary Column -->
    <div class="DiaryColumnContainer ContextOn 19 EmptySlots" style="cursor:pointer;" data-apptid="" data-time="10:40" data-staffid="1" data-staffname="Darren  Rieck" data-status="" data-key="19" data-clientid="" data-clientname="" data-newclient="" data-extended="" data-primaryid="" data-invoiced="" data-caseid="" data-type="">
    
    <div class="DiaryColumn" >

<!-- Start Lunch Time -->
<!-- End Lunch Time -->
	
<!-- Start Populate Slot -->
<!-- End Populate Slot -->
    
    
    </div>
    </div>
    <!-- End Diary Column -->
    <!-- Start Diary Column -->
    <div class="DiaryColumnContainer ContextOn 19 EmptySlots" style="cursor:pointer;" data-apptid="" data-time="10:40" data-staffid="6" data-staffname="Karen  Kitchener" data-status="" data-key="19" data-clientid="" data-clientname="" data-newclient="" data-extended="" data-primaryid="" data-invoiced="" data-caseid="" data-type="">
    
    <div class="DiaryColumn" >

<!-- Start Lunch Time -->
<!-- End Lunch Time -->
	
<!-- Start Populate Slot -->
<!-- End Populate Slot -->
    
    
    </div>
    </div>
    <!-- End Diary Column -->
    <!-- Start Diary Column -->
    <div class="DiaryColumnContainer ContextOn 20 EmptySlots" style="cursor:pointer;" data-apptid="" data-time="10:50" data-staffid="26" data-staffname="Bec Webberley" data-status="" data-key="20" data-clientid="" data-clientname="" data-newclient="" data-extended="" data-primaryid="" data-invoiced="" data-caseid="" data-type="">
    
    <div class="DiaryColumn" >

<!-- Start Lunch Time -->
<!-- End Lunch Time -->
	
<!-- Start Populate Slot -->
<!-- End Populate Slot -->
    
    
    </div>
    </div>
    <!-- End Diary Column -->
    <!-- Start Diary Column -->
    <div class="DiaryColumnContainer ContextOff 20 " style="cursor:not-allowed;" data-apptid="28906" data-time="10:50" data-staffid="7" data-staffname="Tamara Shaw" data-status="Completed" data-key="20" data-clientid="390" data-clientname="Marie Holmes" data-newclient="0" data-extended="0" data-primaryid="28904" data-invoiced="" data-caseid="" data-type="Services">
    
    <div class="DiaryColumnSchedule" style="color:#003399; background-color:#D0CEFF;">

<!-- Start Lunch Time -->
<!-- End Lunch Time -->
	
<!-- Start Populate Slot -->
<!-- End Populate Slot -->
    
    
    </div>
    </div>
    <!-- End Diary Column -->
    <!-- Start Diary Column -->
    <div class="DiaryColumnContainer ContextOff 20 " style="cursor:not-allowed;" data-apptid="30803" data-time="10:50" data-staffid="16" data-staffname="Olivia  Moy" data-status="Completed" data-key="20" data-clientid="1258" data-clientname="Roselyne Murcutt" data-newclient="0" data-extended="0" data-primaryid="30801" data-invoiced="" data-caseid="" data-type="Services">
    
    <div class="DiaryColumnSchedule" style="color:#003399; background-color:#D0CEFF;">

<!-- Start Lunch Time -->
<!-- End Lunch Time -->
	
<!-- Start Populate Slot -->
<!-- End Populate Slot -->
    
    
    </div>
    </div>
    <!-- End Diary Column -->
    <!-- Start Diary Column -->
    <div class="DiaryColumnContainer ContextOn 20 EmptySlots" style="cursor:pointer;" data-apptid="" data-time="10:50" data-staffid="18" data-staffname="Andrew  Rashleigh" data-status="" data-key="20" data-clientid="" data-clientname="" data-newclient="" data-extended="" data-primaryid="" data-invoiced="" data-caseid="" data-type="">
    
    <div class="DiaryColumn" >

<!-- Start Lunch Time -->
<!-- End Lunch Time -->
	
<!-- Start Populate Slot -->
<!-- End Populate Slot -->
    
    
    </div>
    </div>
    <!-- End Diary Column -->
    <!-- Start Diary Column -->
    <div class="DiaryColumnContainer ContextOn 20 EmptySlots" style="cursor:pointer;" data-apptid="" data-time="10:50" data-staffid="14" data-staffname="Emile  Cloete" data-status="" data-key="20" data-clientid="" data-clientname="" data-newclient="" data-extended="" data-primaryid="" data-invoiced="" data-caseid="" data-type="">
    
    <div class="DiaryColumn" >

<!-- Start Lunch Time -->
<!-- End Lunch Time -->
	
<!-- Start Populate Slot -->
<!-- End Populate Slot -->
    
    
    </div>
    </div>
    <!-- End Diary Column -->
    <!-- Start Diary Column -->
    <div class="DiaryColumnContainer ContextOn 20 EmptySlots" style="cursor:pointer;" data-apptid="" data-time="10:50" data-staffid="1" data-staffname="Darren  Rieck" data-status="" data-key="20" data-clientid="" data-clientname="" data-newclient="" data-extended="" data-primaryid="" data-invoiced="" data-caseid="" data-type="">
    
    <div class="DiaryColumn" >

<!-- Start Lunch Time -->
<!-- End Lunch Time -->
	
<!-- Start Populate Slot -->
<!-- End Populate Slot -->
    
    
    </div>
    </div>
    <!-- End Diary Column -->
    <!-- Start Diary Column -->
    <div class="DiaryColumnContainer ContextOn 20 EmptySlots" style="cursor:pointer;" data-apptid="" data-time="10:50" data-staffid="6" data-staffname="Karen  Kitchener" data-status="" data-key="20" data-clientid="" data-clientname="" data-newclient="" data-extended="" data-primaryid="" data-invoiced="" data-caseid="" data-type="">
    
    <div class="DiaryColumn" >

<!-- Start Lunch Time -->
<!-- End Lunch Time -->
	
<!-- Start Populate Slot -->
<!-- End Populate Slot -->
    
    
    </div>
    </div>
    <!-- End Diary Column -->
    <!-- Start Diary Column -->
    <div class="DiaryColumnContainer ContextOn 21 EmptySlots" style="cursor:pointer;" data-apptid="" data-time="11:00" data-staffid="26" data-staffname="Bec Webberley" data-status="" data-key="21" data-clientid="" data-clientname="" data-newclient="" data-extended="" data-primaryid="" data-invoiced="" data-caseid="" data-type="">
    
    <div class="DiaryColumn" >

<!-- Start Lunch Time -->
<!-- End Lunch Time -->
	
<!-- Start Populate Slot -->
<!-- End Populate Slot -->
    
    
    </div>
    </div>
    <!-- End Diary Column -->
    <!-- Start Diary Column -->
    <div class="DiaryColumnContainer ContextOn 21 FilledSlots" style="cursor:pointer;" data-apptid="32323" data-time="11:00" data-staffid="7" data-staffname="Tamara Shaw" data-status="Completed" data-key="21" data-clientid="1447" data-clientname="Diane Clarke" data-newclient="1" data-extended="1" data-primaryid="0" data-invoiced="" data-caseid="2790" data-type="Services">
    
    <div class="DiaryColumnSchedule" style="color:#003399; background-color:#D0CEFF;">

<!-- Start Lunch Time -->
<!-- End Lunch Time -->
	
<!-- Start Populate Slot -->
    <div class="ClientType SlotContent" style="float:left; width:15px; background-color:#360; color:#FFF; margin-left:2px; margin-top:2px;">T</div>
    

    <div class="Patient SlotContent DiaryToolTip" 
    title="<span>Provider : Tamara Shaw<hr />Date : 19/07/2012 - Time : 11:00</span><hr />Diane Clarke<br /><br />Contact No : 0402722789<hr /><span>$10 gap payable</span><hr />New Patient<hr />Third Party : Medicare Australia<hr />EPC - Physio Std Consult<hr />Case : EPC - Diabetes<hr />" 
    style="float:left; margin:2px 0px 0px 5px; font-weight:bold; font-size:11px; color:#900; font-style:italic;">
	Diane Clarke    
    </div>

<!-- End Populate Slot -->
    
    
    </div>
    </div>
    <!-- End Diary Column -->
    <!-- Start Diary Column -->
    <div class="DiaryColumnContainer ContextOff 21 " style="cursor:not-allowed;" data-apptid="30804" data-time="11:00" data-staffid="16" data-staffname="Olivia  Moy" data-status="Completed" data-key="21" data-clientid="1258" data-clientname="Roselyne Murcutt" data-newclient="0" data-extended="0" data-primaryid="30801" data-invoiced="" data-caseid="" data-type="Services">
    
    <div class="DiaryColumnSchedule" style="color:#003399; background-color:#D0CEFF;">

<!-- Start Lunch Time -->
<!-- End Lunch Time -->
	
<!-- Start Populate Slot -->
<!-- End Populate Slot -->
    
    
    </div>
    </div>
    <!-- End Diary Column -->
    <!-- Start Diary Column -->
    <div class="DiaryColumnContainer ContextOn 21 EmptySlots" style="cursor:pointer;" data-apptid="" data-time="11:00" data-staffid="18" data-staffname="Andrew  Rashleigh" data-status="" data-key="21" data-clientid="" data-clientname="" data-newclient="" data-extended="" data-primaryid="" data-invoiced="" data-caseid="" data-type="">
    
    <div class="DiaryColumn" >

<!-- Start Lunch Time -->
<!-- End Lunch Time -->
	
<!-- Start Populate Slot -->
<!-- End Populate Slot -->
    
    
    </div>
    </div>
    <!-- End Diary Column -->
    <!-- Start Diary Column -->
    <div class="DiaryColumnContainer ContextOn 21 EmptySlots" style="cursor:pointer;" data-apptid="" data-time="11:00" data-staffid="14" data-staffname="Emile  Cloete" data-status="" data-key="21" data-clientid="" data-clientname="" data-newclient="" data-extended="" data-primaryid="" data-invoiced="" data-caseid="" data-type="">
    
    <div class="DiaryColumn" >

<!-- Start Lunch Time -->
<!-- End Lunch Time -->
	
<!-- Start Populate Slot -->
<!-- End Populate Slot -->
    
    
    </div>
    </div>
    <!-- End Diary Column -->
    <!-- Start Diary Column -->
    <div class="DiaryColumnContainer ContextOn 21 EmptySlots" style="cursor:pointer;" data-apptid="" data-time="11:00" data-staffid="1" data-staffname="Darren  Rieck" data-status="" data-key="21" data-clientid="" data-clientname="" data-newclient="" data-extended="" data-primaryid="" data-invoiced="" data-caseid="" data-type="">
    
    <div class="DiaryColumn" >

<!-- Start Lunch Time -->
<!-- End Lunch Time -->
	
<!-- Start Populate Slot -->
<!-- End Populate Slot -->
    
    
    </div>
    </div>
    <!-- End Diary Column -->
    <!-- Start Diary Column -->
    <div class="DiaryColumnContainer ContextOn 21 EmptySlots" style="cursor:pointer;" data-apptid="" data-time="11:00" data-staffid="6" data-staffname="Karen  Kitchener" data-status="" data-key="21" data-clientid="" data-clientname="" data-newclient="" data-extended="" data-primaryid="" data-invoiced="" data-caseid="" data-type="">
    
    <div class="DiaryColumn" >

<!-- Start Lunch Time -->
<!-- End Lunch Time -->
	
<!-- Start Populate Slot -->
<!-- End Populate Slot -->
    
    
    </div>
    </div>
    <!-- End Diary Column -->
    <!-- Start Diary Column -->
    <div class="DiaryColumnContainer ContextOn 22 EmptySlots" style="cursor:pointer;" data-apptid="" data-time="11:10" data-staffid="26" data-staffname="Bec Webberley" data-status="" data-key="22" data-clientid="" data-clientname="" data-newclient="" data-extended="" data-primaryid="" data-invoiced="" data-caseid="" data-type="">
    
    <div class="DiaryColumn" >

<!-- Start Lunch Time -->
<!-- End Lunch Time -->
	
<!-- Start Populate Slot -->
<!-- End Populate Slot -->
    
    
    </div>
    </div>
    <!-- End Diary Column -->
    <!-- Start Diary Column -->
    <div class="DiaryColumnContainer ContextOff 22 " style="cursor:not-allowed;" data-apptid="32324" data-time="11:10" data-staffid="7" data-staffname="Tamara Shaw" data-status="Completed" data-key="22" data-clientid="1447" data-clientname="Diane Clarke" data-newclient="1" data-extended="0" data-primaryid="32323" data-invoiced="" data-caseid="" data-type="Services">
    
    <div class="DiaryColumnSchedule" style="color:#003399; background-color:#D0CEFF;">

<!-- Start Lunch Time -->
<!-- End Lunch Time -->
	
<!-- Start Populate Slot -->
<!-- End Populate Slot -->
    
    
    </div>
    </div>
    <!-- End Diary Column -->
    <!-- Start Diary Column -->
    <div class="DiaryColumnContainer ContextOff 22 " style="cursor:not-allowed;" data-apptid="30805" data-time="11:10" data-staffid="16" data-staffname="Olivia  Moy" data-status="Completed" data-key="22" data-clientid="1258" data-clientname="Roselyne Murcutt" data-newclient="0" data-extended="0" data-primaryid="30801" data-invoiced="" data-caseid="" data-type="Services">
    
    <div class="DiaryColumnSchedule" style="color:#003399; background-color:#D0CEFF;">

<!-- Start Lunch Time -->
<!-- End Lunch Time -->
	
<!-- Start Populate Slot -->
<!-- End Populate Slot -->
    
    
    </div>
    </div>
    <!-- End Diary Column -->
    <!-- Start Diary Column -->
    <div class="DiaryColumnContainer ContextOn 22 EmptySlots" style="cursor:pointer;" data-apptid="" data-time="11:10" data-staffid="18" data-staffname="Andrew  Rashleigh" data-status="" data-key="22" data-clientid="" data-clientname="" data-newclient="" data-extended="" data-primaryid="" data-invoiced="" data-caseid="" data-type="">
    
    <div class="DiaryColumn" >

<!-- Start Lunch Time -->
<!-- End Lunch Time -->
	
<!-- Start Populate Slot -->
<!-- End Populate Slot -->
    
    
    </div>
    </div>
    <!-- End Diary Column -->
    <!-- Start Diary Column -->
    <div class="DiaryColumnContainer ContextOn 22 EmptySlots" style="cursor:pointer;" data-apptid="" data-time="11:10" data-staffid="14" data-staffname="Emile  Cloete" data-status="" data-key="22" data-clientid="" data-clientname="" data-newclient="" data-extended="" data-primaryid="" data-invoiced="" data-caseid="" data-type="">
    
    <div class="DiaryColumn" >

<!-- Start Lunch Time -->
<!-- End Lunch Time -->
	
<!-- Start Populate Slot -->
<!-- End Populate Slot -->
    
    
    </div>
    </div>
    <!-- End Diary Column -->
    <!-- Start Diary Column -->
    <div class="DiaryColumnContainer ContextOn 22 EmptySlots" style="cursor:pointer;" data-apptid="" data-time="11:10" data-staffid="1" data-staffname="Darren  Rieck" data-status="" data-key="22" data-clientid="" data-clientname="" data-newclient="" data-extended="" data-primaryid="" data-invoiced="" data-caseid="" data-type="">
    
    <div class="DiaryColumn" >

<!-- Start Lunch Time -->
<!-- End Lunch Time -->
	
<!-- Start Populate Slot -->
<!-- End Populate Slot -->
    
    
    </div>
    </div>
    <!-- End Diary Column -->
    <!-- Start Diary Column -->
    <div class="DiaryColumnContainer ContextOn 22 EmptySlots" style="cursor:pointer;" data-apptid="" data-time="11:10" data-staffid="6" data-staffname="Karen  Kitchener" data-status="" data-key="22" data-clientid="" data-clientname="" data-newclient="" data-extended="" data-primaryid="" data-invoiced="" data-caseid="" data-type="">
    
    <div class="DiaryColumn" >

<!-- Start Lunch Time -->
<!-- End Lunch Time -->
	
<!-- Start Populate Slot -->
<!-- End Populate Slot -->
    
    
    </div>
    </div>
    <!-- End Diary Column -->
    <!-- Start Diary Column -->
    <div class="DiaryColumnContainer ContextOn 23 EmptySlots" style="cursor:pointer;" data-apptid="" data-time="11:20" data-staffid="26" data-staffname="Bec Webberley" data-status="" data-key="23" data-clientid="" data-clientname="" data-newclient="" data-extended="" data-primaryid="" data-invoiced="" data-caseid="" data-type="">
    
    <div class="DiaryColumn" >

<!-- Start Lunch Time -->
<!-- End Lunch Time -->
	
<!-- Start Populate Slot -->
<!-- End Populate Slot -->
    
    
    </div>
    </div>
    <!-- End Diary Column -->
    <!-- Start Diary Column -->
    <div class="DiaryColumnContainer ContextOn 23 EmptySlots" style="cursor:pointer;" data-apptid="" data-time="11:20" data-staffid="7" data-staffname="Tamara Shaw" data-status="" data-key="23" data-clientid="" data-clientname="" data-newclient="" data-extended="" data-primaryid="" data-invoiced="" data-caseid="" data-type="">
    
    <div class="DiaryColumnSchedule" >

<!-- Start Lunch Time -->
<!-- End Lunch Time -->
	
<!-- Start Populate Slot -->
<!-- End Populate Slot -->
    
    
    </div>
    </div>
    <!-- End Diary Column -->
    <!-- Start Diary Column -->
    <div class="DiaryColumnContainer ContextOff 23 " style="cursor:not-allowed;" data-apptid="30806" data-time="11:20" data-staffid="16" data-staffname="Olivia  Moy" data-status="Completed" data-key="23" data-clientid="1258" data-clientname="Roselyne Murcutt" data-newclient="0" data-extended="0" data-primaryid="30801" data-invoiced="" data-caseid="" data-type="Services">
    
    <div class="DiaryColumnSchedule" style="color:#003399; background-color:#D0CEFF;">

<!-- Start Lunch Time -->
<!-- End Lunch Time -->
	
<!-- Start Populate Slot -->
<!-- End Populate Slot -->
    
    
    </div>
    </div>
    <!-- End Diary Column -->
    <!-- Start Diary Column -->
    <div class="DiaryColumnContainer ContextOn 23 EmptySlots" style="cursor:pointer;" data-apptid="" data-time="11:20" data-staffid="18" data-staffname="Andrew  Rashleigh" data-status="" data-key="23" data-clientid="" data-clientname="" data-newclient="" data-extended="" data-primaryid="" data-invoiced="" data-caseid="" data-type="">
    
    <div class="DiaryColumn" >

<!-- Start Lunch Time -->
<!-- End Lunch Time -->
	
<!-- Start Populate Slot -->
<!-- End Populate Slot -->
    
    
    </div>
    </div>
    <!-- End Diary Column -->
    <!-- Start Diary Column -->
    <div class="DiaryColumnContainer ContextOn 23 EmptySlots" style="cursor:pointer;" data-apptid="" data-time="11:20" data-staffid="14" data-staffname="Emile  Cloete" data-status="" data-key="23" data-clientid="" data-clientname="" data-newclient="" data-extended="" data-primaryid="" data-invoiced="" data-caseid="" data-type="">
    
    <div class="DiaryColumn" >

<!-- Start Lunch Time -->
<!-- End Lunch Time -->
	
<!-- Start Populate Slot -->
<!-- End Populate Slot -->
    
    
    </div>
    </div>
    <!-- End Diary Column -->
    <!-- Start Diary Column -->
    <div class="DiaryColumnContainer ContextOn 23 EmptySlots" style="cursor:pointer;" data-apptid="" data-time="11:20" data-staffid="1" data-staffname="Darren  Rieck" data-status="" data-key="23" data-clientid="" data-clientname="" data-newclient="" data-extended="" data-primaryid="" data-invoiced="" data-caseid="" data-type="">
    
    <div class="DiaryColumn" >

<!-- Start Lunch Time -->
<!-- End Lunch Time -->
	
<!-- Start Populate Slot -->
<!-- End Populate Slot -->
    
    
    </div>
    </div>
    <!-- End Diary Column -->
    <!-- Start Diary Column -->
    <div class="DiaryColumnContainer ContextOn 23 EmptySlots" style="cursor:pointer;" data-apptid="" data-time="11:20" data-staffid="6" data-staffname="Karen  Kitchener" data-status="" data-key="23" data-clientid="" data-clientname="" data-newclient="" data-extended="" data-primaryid="" data-invoiced="" data-caseid="" data-type="">
    
    <div class="DiaryColumn" >

<!-- Start Lunch Time -->
<!-- End Lunch Time -->
	
<!-- Start Populate Slot -->
<!-- End Populate Slot -->
    
    
    </div>
    </div>
    <!-- End Diary Column -->
    <!-- Start Diary Column -->
    <div class="DiaryColumnContainer ContextOn 24 EmptySlots" style="cursor:pointer;" data-apptid="" data-time="11:30" data-staffid="26" data-staffname="Bec Webberley" data-status="" data-key="24" data-clientid="" data-clientname="" data-newclient="" data-extended="" data-primaryid="" data-invoiced="" data-caseid="" data-type="">
    
    <div class="DiaryColumn" >

<!-- Start Lunch Time -->
<!-- End Lunch Time -->
	
<!-- Start Populate Slot -->
<!-- End Populate Slot -->
    
    
    </div>
    </div>
    <!-- End Diary Column -->
    <!-- Start Diary Column -->
    <div class="DiaryColumnContainer ContextOn 24 FilledSlots" style="cursor:pointer;" data-apptid="32340" data-time="11:30" data-staffid="7" data-staffname="Tamara Shaw" data-status="Completed" data-key="24" data-clientid="1445" data-clientname="Cheresse Heffernan" data-newclient="0" data-extended="1" data-primaryid="0" data-invoiced="" data-caseid="2787" data-type="Services">
    
    <div class="DiaryColumnSchedule" style="color:#003399; background-color:#D0CEFF;">

<!-- Start Lunch Time -->
<!-- End Lunch Time -->
	
<!-- Start Populate Slot -->
    <div class="ClientType SlotContent" style="float:left; width:15px; background-color:#006; color:#FFF; margin-left:2px; margin-top:2px;">P</div>
    

    <div class="Patient SlotContent DiaryToolTip" 
    title="<span>Provider : Tamara Shaw<hr />Date : 19/07/2012 - Time : 11:30</span><hr />Cheresse Heffernan<br /><br />Contact No : 0401758966<hr />Private -  Physio Std<hr />Case : PVT - Back<hr />" 
    style="float:left; margin:2px 0px 0px 5px; font-weight:bold; font-size:11px; ">
	Cheresse H     
    </div>

<!-- End Populate Slot -->
    
    
    </div>
    </div>
    <!-- End Diary Column -->
    <!-- Start Diary Column -->
    <div class="DiaryColumnContainer ContextOn 24 FilledSlots" style="cursor:pointer;" data-apptid="32887" data-time="11:30" data-staffid="16" data-staffname="Olivia  Moy" data-status="StdAppt" data-key="24" data-clientid="1399" data-clientname="Cora Gatbonton" data-newclient="0" data-extended="1" data-primaryid="0" data-invoiced="" data-caseid="2719" data-type="Services">
    
    <div class="DiaryColumnSchedule" style="color:#003399; background-color:#D1D6D6;">

<!-- Start Lunch Time -->
<!-- End Lunch Time -->
	
<!-- Start Populate Slot -->
    <div class="ClientType SlotContent" style="float:left; width:15px; background-color:#006; color:#FFF; margin-left:2px; margin-top:2px;">P</div>
    

    <div class="Patient SlotContent DiaryToolTip" 
    title="<span>Provider : Olivia  Moy<hr />Date : 19/07/2012 - Time : 11:30</span><hr />Cora Gatbonton<br /><br />Contact No : 0431 517 215<hr />Remedial Massage 1 Hr<hr />Case : Massage<hr />" 
    style="float:left; margin:2px 0px 0px 5px; font-weight:bold; font-size:11px; ">
	Cora Gatbonton    
    </div>

<!-- End Populate Slot -->
    
    
    </div>
    </div>
    <!-- End Diary Column -->
    <!-- Start Diary Column -->
    <div class="DiaryColumnContainer ContextOn 24 EmptySlots" style="cursor:pointer;" data-apptid="" data-time="11:30" data-staffid="18" data-staffname="Andrew  Rashleigh" data-status="" data-key="24" data-clientid="" data-clientname="" data-newclient="" data-extended="" data-primaryid="" data-invoiced="" data-caseid="" data-type="">
    
    <div class="DiaryColumn" >

<!-- Start Lunch Time -->
<!-- End Lunch Time -->
	
<!-- Start Populate Slot -->
<!-- End Populate Slot -->
    
    
    </div>
    </div>
    <!-- End Diary Column -->
    <!-- Start Diary Column -->
    <div class="DiaryColumnContainer ContextOn 24 EmptySlots" style="cursor:pointer;" data-apptid="" data-time="11:30" data-staffid="14" data-staffname="Emile  Cloete" data-status="" data-key="24" data-clientid="" data-clientname="" data-newclient="" data-extended="" data-primaryid="" data-invoiced="" data-caseid="" data-type="">
    
    <div class="DiaryColumn" >

<!-- Start Lunch Time -->
<!-- End Lunch Time -->
	
<!-- Start Populate Slot -->
<!-- End Populate Slot -->
    
    
    </div>
    </div>
    <!-- End Diary Column -->
    <!-- Start Diary Column -->
    <div class="DiaryColumnContainer ContextOn 24 EmptySlots" style="cursor:pointer;" data-apptid="" data-time="11:30" data-staffid="1" data-staffname="Darren  Rieck" data-status="" data-key="24" data-clientid="" data-clientname="" data-newclient="" data-extended="" data-primaryid="" data-invoiced="" data-caseid="" data-type="">
    
    <div class="DiaryColumn" >

<!-- Start Lunch Time -->
<!-- End Lunch Time -->
	
<!-- Start Populate Slot -->
<!-- End Populate Slot -->
    
    
    </div>
    </div>
    <!-- End Diary Column -->
    <!-- Start Diary Column -->
    <div class="DiaryColumnContainer ContextOn 24 EmptySlots" style="cursor:pointer;" data-apptid="" data-time="11:30" data-staffid="6" data-staffname="Karen  Kitchener" data-status="" data-key="24" data-clientid="" data-clientname="" data-newclient="" data-extended="" data-primaryid="" data-invoiced="" data-caseid="" data-type="">
    
    <div class="DiaryColumn" >

<!-- Start Lunch Time -->
<!-- End Lunch Time -->
	
<!-- Start Populate Slot -->
<!-- End Populate Slot -->
    
    
    </div>
    </div>
    <!-- End Diary Column -->
    <!-- Start Diary Column -->
    <div class="DiaryColumnContainer ContextOn 25 EmptySlots" style="cursor:pointer;" data-apptid="" data-time="11:40" data-staffid="26" data-staffname="Bec Webberley" data-status="" data-key="25" data-clientid="" data-clientname="" data-newclient="" data-extended="" data-primaryid="" data-invoiced="" data-caseid="" data-type="">
    
    <div class="DiaryColumn" >

<!-- Start Lunch Time -->
<!-- End Lunch Time -->
	
<!-- Start Populate Slot -->
<!-- End Populate Slot -->
    
    
    </div>
    </div>
    <!-- End Diary Column -->
    <!-- Start Diary Column -->
    <div class="DiaryColumnContainer ContextOff 25 " style="cursor:not-allowed;" data-apptid="32342" data-time="11:40" data-staffid="7" data-staffname="Tamara Shaw" data-status="Completed" data-key="25" data-clientid="1445" data-clientname="Cheresse Heffernan" data-newclient="0" data-extended="0" data-primaryid="32340" data-invoiced="" data-caseid="" data-type="Services">
    
    <div class="DiaryColumnSchedule" style="color:#003399; background-color:#D0CEFF;">

<!-- Start Lunch Time -->
<!-- End Lunch Time -->
	
<!-- Start Populate Slot -->
<!-- End Populate Slot -->
    
    
    </div>
    </div>
    <!-- End Diary Column -->
    <!-- Start Diary Column -->
    <div class="DiaryColumnContainer ContextOff 25 " style="cursor:not-allowed;" data-apptid="32888" data-time="11:40" data-staffid="16" data-staffname="Olivia  Moy" data-status="StdAppt" data-key="25" data-clientid="1399" data-clientname="Cora Gatbonton" data-newclient="0" data-extended="0" data-primaryid="32887" data-invoiced="" data-caseid="" data-type="Services">
    
    <div class="DiaryColumnSchedule" style="color:#003399; background-color:#D1D6D6;">

<!-- Start Lunch Time -->
<!-- End Lunch Time -->
	
<!-- Start Populate Slot -->
<!-- End Populate Slot -->
    
    
    </div>
    </div>
    <!-- End Diary Column -->
    <!-- Start Diary Column -->
    <div class="DiaryColumnContainer ContextOn 25 EmptySlots" style="cursor:pointer;" data-apptid="" data-time="11:40" data-staffid="18" data-staffname="Andrew  Rashleigh" data-status="" data-key="25" data-clientid="" data-clientname="" data-newclient="" data-extended="" data-primaryid="" data-invoiced="" data-caseid="" data-type="">
    
    <div class="DiaryColumn" >

<!-- Start Lunch Time -->
<!-- End Lunch Time -->
	
<!-- Start Populate Slot -->
<!-- End Populate Slot -->
    
    
    </div>
    </div>
    <!-- End Diary Column -->
    <!-- Start Diary Column -->
    <div class="DiaryColumnContainer ContextOn 25 EmptySlots" style="cursor:pointer;" data-apptid="" data-time="11:40" data-staffid="14" data-staffname="Emile  Cloete" data-status="" data-key="25" data-clientid="" data-clientname="" data-newclient="" data-extended="" data-primaryid="" data-invoiced="" data-caseid="" data-type="">
    
    <div class="DiaryColumn" >

<!-- Start Lunch Time -->
<!-- End Lunch Time -->
	
<!-- Start Populate Slot -->
<!-- End Populate Slot -->
    
    
    </div>
    </div>
    <!-- End Diary Column -->
    <!-- Start Diary Column -->
    <div class="DiaryColumnContainer ContextOn 25 EmptySlots" style="cursor:pointer;" data-apptid="" data-time="11:40" data-staffid="1" data-staffname="Darren  Rieck" data-status="" data-key="25" data-clientid="" data-clientname="" data-newclient="" data-extended="" data-primaryid="" data-invoiced="" data-caseid="" data-type="">
    
    <div class="DiaryColumn" >

<!-- Start Lunch Time -->
<!-- End Lunch Time -->
	
<!-- Start Populate Slot -->
<!-- End Populate Slot -->
    
    
    </div>
    </div>
    <!-- End Diary Column -->
    <!-- Start Diary Column -->
    <div class="DiaryColumnContainer ContextOn 25 EmptySlots" style="cursor:pointer;" data-apptid="" data-time="11:40" data-staffid="6" data-staffname="Karen  Kitchener" data-status="" data-key="25" data-clientid="" data-clientname="" data-newclient="" data-extended="" data-primaryid="" data-invoiced="" data-caseid="" data-type="">
    
    <div class="DiaryColumn" >

<!-- Start Lunch Time -->
<!-- End Lunch Time -->
	
<!-- Start Populate Slot -->
<!-- End Populate Slot -->
    
    
    </div>
    </div>
    <!-- End Diary Column -->
    <!-- Start Diary Column -->
    <div class="DiaryColumnContainer ContextOn 26 EmptySlots" style="cursor:pointer;" data-apptid="" data-time="11:50" data-staffid="26" data-staffname="Bec Webberley" data-status="" data-key="26" data-clientid="" data-clientname="" data-newclient="" data-extended="" data-primaryid="" data-invoiced="" data-caseid="" data-type="">
    
    <div class="DiaryColumn" >

<!-- Start Lunch Time -->
<!-- End Lunch Time -->
	
<!-- Start Populate Slot -->
<!-- End Populate Slot -->
    
    
    </div>
    </div>
    <!-- End Diary Column -->
    <!-- Start Diary Column -->
    <div class="DiaryColumnContainer ContextOff 26 " style="cursor:not-allowed;" data-apptid="32343" data-time="11:50" data-staffid="7" data-staffname="Tamara Shaw" data-status="Completed" data-key="26" data-clientid="1445" data-clientname="Cheresse Heffernan" data-newclient="0" data-extended="0" data-primaryid="32340" data-invoiced="" data-caseid="" data-type="Services">
    
    <div class="DiaryColumnSchedule" style="color:#003399; background-color:#D0CEFF;">

<!-- Start Lunch Time -->
<!-- End Lunch Time -->
	
<!-- Start Populate Slot -->
<!-- End Populate Slot -->
    
    
    </div>
    </div>
    <!-- End Diary Column -->
    <!-- Start Diary Column -->
    <div class="DiaryColumnContainer ContextOff 26 " style="cursor:not-allowed;" data-apptid="32889" data-time="11:50" data-staffid="16" data-staffname="Olivia  Moy" data-status="StdAppt" data-key="26" data-clientid="1399" data-clientname="Cora Gatbonton" data-newclient="0" data-extended="0" data-primaryid="32887" data-invoiced="" data-caseid="" data-type="Services">
    
    <div class="DiaryColumnSchedule" style="color:#003399; background-color:#D1D6D6;">

<!-- Start Lunch Time -->
<!-- End Lunch Time -->
	
<!-- Start Populate Slot -->
<!-- End Populate Slot -->
    
    
    </div>
    </div>
    <!-- End Diary Column -->
    <!-- Start Diary Column -->
    <div class="DiaryColumnContainer ContextOn 26 EmptySlots" style="cursor:pointer;" data-apptid="" data-time="11:50" data-staffid="18" data-staffname="Andrew  Rashleigh" data-status="" data-key="26" data-clientid="" data-clientname="" data-newclient="" data-extended="" data-primaryid="" data-invoiced="" data-caseid="" data-type="">
    
    <div class="DiaryColumn" >

<!-- Start Lunch Time -->
<!-- End Lunch Time -->
	
<!-- Start Populate Slot -->
<!-- End Populate Slot -->
    
    
    </div>
    </div>
    <!-- End Diary Column -->
    <!-- Start Diary Column -->
    <div class="DiaryColumnContainer ContextOn 26 EmptySlots" style="cursor:pointer;" data-apptid="" data-time="11:50" data-staffid="14" data-staffname="Emile  Cloete" data-status="" data-key="26" data-clientid="" data-clientname="" data-newclient="" data-extended="" data-primaryid="" data-invoiced="" data-caseid="" data-type="">
    
    <div class="DiaryColumn" >

<!-- Start Lunch Time -->
<!-- End Lunch Time -->
	
<!-- Start Populate Slot -->
<!-- End Populate Slot -->
    
    
    </div>
    </div>
    <!-- End Diary Column -->
    <!-- Start Diary Column -->
    <div class="DiaryColumnContainer ContextOn 26 EmptySlots" style="cursor:pointer;" data-apptid="" data-time="11:50" data-staffid="1" data-staffname="Darren  Rieck" data-status="" data-key="26" data-clientid="" data-clientname="" data-newclient="" data-extended="" data-primaryid="" data-invoiced="" data-caseid="" data-type="">
    
    <div class="DiaryColumn" >

<!-- Start Lunch Time -->
<!-- End Lunch Time -->
	
<!-- Start Populate Slot -->
<!-- End Populate Slot -->
    
    
    </div>
    </div>
    <!-- End Diary Column -->
    <!-- Start Diary Column -->
    <div class="DiaryColumnContainer ContextOn 26 EmptySlots" style="cursor:pointer;" data-apptid="" data-time="11:50" data-staffid="6" data-staffname="Karen  Kitchener" data-status="" data-key="26" data-clientid="" data-clientname="" data-newclient="" data-extended="" data-primaryid="" data-invoiced="" data-caseid="" data-type="">
    
    <div class="DiaryColumn" >

<!-- Start Lunch Time -->
<!-- End Lunch Time -->
	
<!-- Start Populate Slot -->
<!-- End Populate Slot -->
    
    
    </div>
    </div>
    <!-- End Diary Column -->
    <!-- Start Diary Column -->
    <div class="DiaryColumnContainer ContextOn 27 EmptySlots" style="cursor:pointer;" data-apptid="" data-time="12:00" data-staffid="26" data-staffname="Bec Webberley" data-status="" data-key="27" data-clientid="" data-clientname="" data-newclient="" data-extended="" data-primaryid="" data-invoiced="" data-caseid="" data-type="">
    
    <div class="DiaryColumn" >

<!-- Start Lunch Time -->
<!-- End Lunch Time -->
	
<!-- Start Populate Slot -->
<!-- End Populate Slot -->
    
    
    </div>
    </div>
    <!-- End Diary Column -->
    <!-- Start Diary Column -->
    <div class="DiaryColumnContainer ContextOn 27 EmptySlots" style="cursor:pointer;" data-apptid="" data-time="12:00" data-staffid="7" data-staffname="Tamara Shaw" data-status="" data-key="27" data-clientid="" data-clientname="" data-newclient="" data-extended="" data-primaryid="" data-invoiced="" data-caseid="" data-type="">
    
    <div class="DiaryColumn" >

<!-- Start Lunch Time -->
<div style="color:#666; margin-top:3px; font-style:italic; font-size:9px;">Lunch</div><!-- End Lunch Time -->
	
<!-- Start Populate Slot -->
<!-- End Populate Slot -->
    
    
    </div>
    </div>
    <!-- End Diary Column -->
    <!-- Start Diary Column -->
    <div class="DiaryColumnContainer ContextOff 27 " style="cursor:not-allowed;" data-apptid="32890" data-time="12:00" data-staffid="16" data-staffname="Olivia  Moy" data-status="StdAppt" data-key="27" data-clientid="1399" data-clientname="Cora Gatbonton" data-newclient="0" data-extended="0" data-primaryid="32887" data-invoiced="" data-caseid="" data-type="Services">
    
    <div class="DiaryColumn" style="color:#003399; background-color:#D1D6D6;">

<!-- Start Lunch Time -->
<!-- End Lunch Time -->
	
<!-- Start Populate Slot -->
<!-- End Populate Slot -->
    
    
    </div>
    </div>
    <!-- End Diary Column -->
    <!-- Start Diary Column -->
    <div class="DiaryColumnContainer ContextOn 27 EmptySlots" style="cursor:pointer;" data-apptid="" data-time="12:00" data-staffid="18" data-staffname="Andrew  Rashleigh" data-status="" data-key="27" data-clientid="" data-clientname="" data-newclient="" data-extended="" data-primaryid="" data-invoiced="" data-caseid="" data-type="">
    
    <div class="DiaryColumn" >

<!-- Start Lunch Time -->
<!-- End Lunch Time -->
	
<!-- Start Populate Slot -->
<!-- End Populate Slot -->
    
    
    </div>
    </div>
    <!-- End Diary Column -->
    <!-- Start Diary Column -->
    <div class="DiaryColumnContainer ContextOn 27 EmptySlots" style="cursor:pointer;" data-apptid="" data-time="12:00" data-staffid="14" data-staffname="Emile  Cloete" data-status="" data-key="27" data-clientid="" data-clientname="" data-newclient="" data-extended="" data-primaryid="" data-invoiced="" data-caseid="" data-type="">
    
    <div class="DiaryColumn" >

<!-- Start Lunch Time -->
<!-- End Lunch Time -->
	
<!-- Start Populate Slot -->
<!-- End Populate Slot -->
    
    
    </div>
    </div>
    <!-- End Diary Column -->
    <!-- Start Diary Column -->
    <div class="DiaryColumnContainer ContextOn 27 EmptySlots" style="cursor:pointer;" data-apptid="" data-time="12:00" data-staffid="1" data-staffname="Darren  Rieck" data-status="" data-key="27" data-clientid="" data-clientname="" data-newclient="" data-extended="" data-primaryid="" data-invoiced="" data-caseid="" data-type="">
    
    <div class="DiaryColumn" >

<!-- Start Lunch Time -->
<!-- End Lunch Time -->
	
<!-- Start Populate Slot -->
<!-- End Populate Slot -->
    
    
    </div>
    </div>
    <!-- End Diary Column -->
    <!-- Start Diary Column -->
    <div class="DiaryColumnContainer ContextOn 27 EmptySlots" style="cursor:pointer;" data-apptid="" data-time="12:00" data-staffid="6" data-staffname="Karen  Kitchener" data-status="" data-key="27" data-clientid="" data-clientname="" data-newclient="" data-extended="" data-primaryid="" data-invoiced="" data-caseid="" data-type="">
    
    <div class="DiaryColumn" >

<!-- Start Lunch Time -->
<!-- End Lunch Time -->
	
<!-- Start Populate Slot -->
<!-- End Populate Slot -->
    
    
    </div>
    </div>
    <!-- End Diary Column -->
    <!-- Start Diary Column -->
    <div class="DiaryColumnContainer ContextOn 28 EmptySlots" style="cursor:pointer;" data-apptid="" data-time="12:10" data-staffid="26" data-staffname="Bec Webberley" data-status="" data-key="28" data-clientid="" data-clientname="" data-newclient="" data-extended="" data-primaryid="" data-invoiced="" data-caseid="" data-type="">
    
    <div class="DiaryColumn" >

<!-- Start Lunch Time -->
<!-- End Lunch Time -->
	
<!-- Start Populate Slot -->
<!-- End Populate Slot -->
    
    
    </div>
    </div>
    <!-- End Diary Column -->
    <!-- Start Diary Column -->
    <div class="DiaryColumnContainer ContextOn 28 EmptySlots" style="cursor:pointer;" data-apptid="" data-time="12:10" data-staffid="7" data-staffname="Tamara Shaw" data-status="" data-key="28" data-clientid="" data-clientname="" data-newclient="" data-extended="" data-primaryid="" data-invoiced="" data-caseid="" data-type="">
    
    <div class="DiaryColumn" >

<!-- Start Lunch Time -->
<div style="color:#666; margin-top:3px; font-style:italic; font-size:9px;">Lunch</div><!-- End Lunch Time -->
	
<!-- Start Populate Slot -->
<!-- End Populate Slot -->
    
    
    </div>
    </div>
    <!-- End Diary Column -->
    <!-- Start Diary Column -->
    <div class="DiaryColumnContainer ContextOff 28 " style="cursor:not-allowed;" data-apptid="32891" data-time="12:10" data-staffid="16" data-staffname="Olivia  Moy" data-status="StdAppt" data-key="28" data-clientid="1399" data-clientname="Cora Gatbonton" data-newclient="0" data-extended="0" data-primaryid="32887" data-invoiced="" data-caseid="" data-type="Services">
    
    <div class="DiaryColumn" style="color:#003399; background-color:#D1D6D6;">

<!-- Start Lunch Time -->
<!-- End Lunch Time -->
	
<!-- Start Populate Slot -->
<!-- End Populate Slot -->
    
    
    </div>
    </div>
    <!-- End Diary Column -->
    <!-- Start Diary Column -->
    <div class="DiaryColumnContainer ContextOn 28 EmptySlots" style="cursor:pointer;" data-apptid="" data-time="12:10" data-staffid="18" data-staffname="Andrew  Rashleigh" data-status="" data-key="28" data-clientid="" data-clientname="" data-newclient="" data-extended="" data-primaryid="" data-invoiced="" data-caseid="" data-type="">
    
    <div class="DiaryColumn" >

<!-- Start Lunch Time -->
<!-- End Lunch Time -->
	
<!-- Start Populate Slot -->
<!-- End Populate Slot -->
    
    
    </div>
    </div>
    <!-- End Diary Column -->
    <!-- Start Diary Column -->
    <div class="DiaryColumnContainer ContextOn 28 EmptySlots" style="cursor:pointer;" data-apptid="" data-time="12:10" data-staffid="14" data-staffname="Emile  Cloete" data-status="" data-key="28" data-clientid="" data-clientname="" data-newclient="" data-extended="" data-primaryid="" data-invoiced="" data-caseid="" data-type="">
    
    <div class="DiaryColumn" >

<!-- Start Lunch Time -->
<!-- End Lunch Time -->
	
<!-- Start Populate Slot -->
<!-- End Populate Slot -->
    
    
    </div>
    </div>
    <!-- End Diary Column -->
    <!-- Start Diary Column -->
    <div class="DiaryColumnContainer ContextOn 28 EmptySlots" style="cursor:pointer;" data-apptid="" data-time="12:10" data-staffid="1" data-staffname="Darren  Rieck" data-status="" data-key="28" data-clientid="" data-clientname="" data-newclient="" data-extended="" data-primaryid="" data-invoiced="" data-caseid="" data-type="">
    
    <div class="DiaryColumn" >

<!-- Start Lunch Time -->
<!-- End Lunch Time -->
	
<!-- Start Populate Slot -->
<!-- End Populate Slot -->
    
    
    </div>
    </div>
    <!-- End Diary Column -->
    <!-- Start Diary Column -->
    <div class="DiaryColumnContainer ContextOn 28 EmptySlots" style="cursor:pointer;" data-apptid="" data-time="12:10" data-staffid="6" data-staffname="Karen  Kitchener" data-status="" data-key="28" data-clientid="" data-clientname="" data-newclient="" data-extended="" data-primaryid="" data-invoiced="" data-caseid="" data-type="">
    
    <div class="DiaryColumn" >

<!-- Start Lunch Time -->
<!-- End Lunch Time -->
	
<!-- Start Populate Slot -->
<!-- End Populate Slot -->
    
    
    </div>
    </div>
    <!-- End Diary Column -->
    <!-- Start Diary Column -->
    <div class="DiaryColumnContainer ContextOn 29 EmptySlots" style="cursor:pointer;" data-apptid="" data-time="12:20" data-staffid="26" data-staffname="Bec Webberley" data-status="" data-key="29" data-clientid="" data-clientname="" data-newclient="" data-extended="" data-primaryid="" data-invoiced="" data-caseid="" data-type="">
    
    <div class="DiaryColumn" >

<!-- Start Lunch Time -->
<!-- End Lunch Time -->
	
<!-- Start Populate Slot -->
<!-- End Populate Slot -->
    
    
    </div>
    </div>
    <!-- End Diary Column -->
    <!-- Start Diary Column -->
    <div class="DiaryColumnContainer ContextOn 29 EmptySlots" style="cursor:pointer;" data-apptid="" data-time="12:20" data-staffid="7" data-staffname="Tamara Shaw" data-status="" data-key="29" data-clientid="" data-clientname="" data-newclient="" data-extended="" data-primaryid="" data-invoiced="" data-caseid="" data-type="">
    
    <div class="DiaryColumn" >

<!-- Start Lunch Time -->
<div style="color:#666; margin-top:3px; font-style:italic; font-size:9px;">Lunch</div><!-- End Lunch Time -->
	
<!-- Start Populate Slot -->
<!-- End Populate Slot -->
    
    
    </div>
    </div>
    <!-- End Diary Column -->
    <!-- Start Diary Column -->
    <div class="DiaryColumnContainer ContextOff 29 " style="cursor:not-allowed;" data-apptid="32892" data-time="12:20" data-staffid="16" data-staffname="Olivia  Moy" data-status="StdAppt" data-key="29" data-clientid="1399" data-clientname="Cora Gatbonton" data-newclient="0" data-extended="0" data-primaryid="32887" data-invoiced="" data-caseid="" data-type="Services">
    
    <div class="DiaryColumn" style="color:#003399; background-color:#D1D6D6;">

<!-- Start Lunch Time -->
<!-- End Lunch Time -->
	
<!-- Start Populate Slot -->
<!-- End Populate Slot -->
    
    
    </div>
    </div>
    <!-- End Diary Column -->
    <!-- Start Diary Column -->
    <div class="DiaryColumnContainer ContextOn 29 EmptySlots" style="cursor:pointer;" data-apptid="" data-time="12:20" data-staffid="18" data-staffname="Andrew  Rashleigh" data-status="" data-key="29" data-clientid="" data-clientname="" data-newclient="" data-extended="" data-primaryid="" data-invoiced="" data-caseid="" data-type="">
    
    <div class="DiaryColumn" >

<!-- Start Lunch Time -->
<!-- End Lunch Time -->
	
<!-- Start Populate Slot -->
<!-- End Populate Slot -->
    
    
    </div>
    </div>
    <!-- End Diary Column -->
    <!-- Start Diary Column -->
    <div class="DiaryColumnContainer ContextOn 29 EmptySlots" style="cursor:pointer;" data-apptid="" data-time="12:20" data-staffid="14" data-staffname="Emile  Cloete" data-status="" data-key="29" data-clientid="" data-clientname="" data-newclient="" data-extended="" data-primaryid="" data-invoiced="" data-caseid="" data-type="">
    
    <div class="DiaryColumn" >

<!-- Start Lunch Time -->
<!-- End Lunch Time -->
	
<!-- Start Populate Slot -->
<!-- End Populate Slot -->
    
    
    </div>
    </div>
    <!-- End Diary Column -->
    <!-- Start Diary Column -->
    <div class="DiaryColumnContainer ContextOn 29 EmptySlots" style="cursor:pointer;" data-apptid="" data-time="12:20" data-staffid="1" data-staffname="Darren  Rieck" data-status="" data-key="29" data-clientid="" data-clientname="" data-newclient="" data-extended="" data-primaryid="" data-invoiced="" data-caseid="" data-type="">
    
    <div class="DiaryColumn" >

<!-- Start Lunch Time -->
<!-- End Lunch Time -->
	
<!-- Start Populate Slot -->
<!-- End Populate Slot -->
    
    
    </div>
    </div>
    <!-- End Diary Column -->
    <!-- Start Diary Column -->
    <div class="DiaryColumnContainer ContextOn 29 EmptySlots" style="cursor:pointer;" data-apptid="" data-time="12:20" data-staffid="6" data-staffname="Karen  Kitchener" data-status="" data-key="29" data-clientid="" data-clientname="" data-newclient="" data-extended="" data-primaryid="" data-invoiced="" data-caseid="" data-type="">
    
    <div class="DiaryColumn" >

<!-- Start Lunch Time -->
<!-- End Lunch Time -->
	
<!-- Start Populate Slot -->
<!-- End Populate Slot -->
    
    
    </div>
    </div>
    <!-- End Diary Column -->
    <!-- Start Diary Column -->
    <div class="DiaryColumnContainer ContextOn 30 EmptySlots" style="cursor:pointer;" data-apptid="" data-time="12:30" data-staffid="26" data-staffname="Bec Webberley" data-status="" data-key="30" data-clientid="" data-clientname="" data-newclient="" data-extended="" data-primaryid="" data-invoiced="" data-caseid="" data-type="">
    
    <div class="DiaryColumn" >

<!-- Start Lunch Time -->
<!-- End Lunch Time -->
	
<!-- Start Populate Slot -->
<!-- End Populate Slot -->
    
    
    </div>
    </div>
    <!-- End Diary Column -->
    <!-- Start Diary Column -->
    <div class="DiaryColumnContainer ContextOn 30 EmptySlots" style="cursor:pointer;" data-apptid="" data-time="12:30" data-staffid="7" data-staffname="Tamara Shaw" data-status="" data-key="30" data-clientid="" data-clientname="" data-newclient="" data-extended="" data-primaryid="" data-invoiced="" data-caseid="" data-type="">
    
    <div class="DiaryColumn" >

<!-- Start Lunch Time -->
<div style="color:#666; margin-top:3px; font-style:italic; font-size:9px;">Lunch</div><!-- End Lunch Time -->
	
<!-- Start Populate Slot -->
<!-- End Populate Slot -->
    
    
    </div>
    </div>
    <!-- End Diary Column -->
    <!-- Start Diary Column -->
    <div class="DiaryColumnContainer ContextOn 30 EmptySlots" style="cursor:pointer;" data-apptid="" data-time="12:30" data-staffid="16" data-staffname="Olivia  Moy" data-status="" data-key="30" data-clientid="" data-clientname="" data-newclient="" data-extended="" data-primaryid="" data-invoiced="" data-caseid="" data-type="">
    
    <div class="DiaryColumn" >

<!-- Start Lunch Time -->
<div style="color:#666; margin-top:3px; font-style:italic; font-size:9px;">Lunch</div><!-- End Lunch Time -->
	
<!-- Start Populate Slot -->
<!-- End Populate Slot -->
    
    
    </div>
    </div>
    <!-- End Diary Column -->
    <!-- Start Diary Column -->
    <div class="DiaryColumnContainer ContextOn 30 EmptySlots" style="cursor:pointer;" data-apptid="" data-time="12:30" data-staffid="18" data-staffname="Andrew  Rashleigh" data-status="" data-key="30" data-clientid="" data-clientname="" data-newclient="" data-extended="" data-primaryid="" data-invoiced="" data-caseid="" data-type="">
    
    <div class="DiaryColumn" >

<!-- Start Lunch Time -->
<!-- End Lunch Time -->
	
<!-- Start Populate Slot -->
<!-- End Populate Slot -->
    
    
    </div>
    </div>
    <!-- End Diary Column -->
    <!-- Start Diary Column -->
    <div class="DiaryColumnContainer ContextOn 30 EmptySlots" style="cursor:pointer;" data-apptid="" data-time="12:30" data-staffid="14" data-staffname="Emile  Cloete" data-status="" data-key="30" data-clientid="" data-clientname="" data-newclient="" data-extended="" data-primaryid="" data-invoiced="" data-caseid="" data-type="">
    
    <div class="DiaryColumn" >

<!-- Start Lunch Time -->
<!-- End Lunch Time -->
	
<!-- Start Populate Slot -->
<!-- End Populate Slot -->
    
    
    </div>
    </div>
    <!-- End Diary Column -->
    <!-- Start Diary Column -->
    <div class="DiaryColumnContainer ContextOn 30 EmptySlots" style="cursor:pointer;" data-apptid="" data-time="12:30" data-staffid="1" data-staffname="Darren  Rieck" data-status="" data-key="30" data-clientid="" data-clientname="" data-newclient="" data-extended="" data-primaryid="" data-invoiced="" data-caseid="" data-type="">
    
    <div class="DiaryColumn" >

<!-- Start Lunch Time -->
<!-- End Lunch Time -->
	
<!-- Start Populate Slot -->
<!-- End Populate Slot -->
    
    
    </div>
    </div>
    <!-- End Diary Column -->
    <!-- Start Diary Column -->
    <div class="DiaryColumnContainer ContextOn 30 EmptySlots" style="cursor:pointer;" data-apptid="" data-time="12:30" data-staffid="6" data-staffname="Karen  Kitchener" data-status="" data-key="30" data-clientid="" data-clientname="" data-newclient="" data-extended="" data-primaryid="" data-invoiced="" data-caseid="" data-type="">
    
    <div class="DiaryColumn" >

<!-- Start Lunch Time -->
<!-- End Lunch Time -->
	
<!-- Start Populate Slot -->
<!-- End Populate Slot -->
    
    
    </div>
    </div>
    <!-- End Diary Column -->
    <!-- Start Diary Column -->
    <div class="DiaryColumnContainer ContextOn 31 EmptySlots" style="cursor:pointer;" data-apptid="" data-time="12:40" data-staffid="26" data-staffname="Bec Webberley" data-status="" data-key="31" data-clientid="" data-clientname="" data-newclient="" data-extended="" data-primaryid="" data-invoiced="" data-caseid="" data-type="">
    
    <div class="DiaryColumn" >

<!-- Start Lunch Time -->
<!-- End Lunch Time -->
	
<!-- Start Populate Slot -->
<!-- End Populate Slot -->
    
    
    </div>
    </div>
    <!-- End Diary Column -->
    <!-- Start Diary Column -->
    <div class="DiaryColumnContainer ContextOn 31 EmptySlots" style="cursor:pointer;" data-apptid="" data-time="12:40" data-staffid="7" data-staffname="Tamara Shaw" data-status="" data-key="31" data-clientid="" data-clientname="" data-newclient="" data-extended="" data-primaryid="" data-invoiced="" data-caseid="" data-type="">
    
    <div class="DiaryColumn" >

<!-- Start Lunch Time -->
<div style="color:#666; margin-top:3px; font-style:italic; font-size:9px;">Lunch</div><!-- End Lunch Time -->
	
<!-- Start Populate Slot -->
<!-- End Populate Slot -->
    
    
    </div>
    </div>
    <!-- End Diary Column -->
    <!-- Start Diary Column -->
    <div class="DiaryColumnContainer ContextOn 31 EmptySlots" style="cursor:pointer;" data-apptid="" data-time="12:40" data-staffid="16" data-staffname="Olivia  Moy" data-status="" data-key="31" data-clientid="" data-clientname="" data-newclient="" data-extended="" data-primaryid="" data-invoiced="" data-caseid="" data-type="">
    
    <div class="DiaryColumn" >

<!-- Start Lunch Time -->
<div style="color:#666; margin-top:3px; font-style:italic; font-size:9px;">Lunch</div><!-- End Lunch Time -->
	
<!-- Start Populate Slot -->
<!-- End Populate Slot -->
    
    
    </div>
    </div>
    <!-- End Diary Column -->
    <!-- Start Diary Column -->
    <div class="DiaryColumnContainer ContextOn 31 ClassSlots" style="cursor:pointer;" data-apptid="32918" data-time="12:40" data-staffid="18" data-staffname="Andrew  Rashleigh" data-status="Class" data-key="31" data-clientid="" data-clientname="" data-newclient="0" data-extended="0" data-primaryid="0" data-invoiced="0" data-caseid="" data-type="Classes">
    
    <div class="DiaryColumn" style="color:#003399; background-color:#FFF1CC;">

<!-- Start Lunch Time -->
<!-- End Lunch Time -->
	
<!-- Start Populate Slot -->
    

    <div class="Patient SlotContent ClassToolTip" 
    title="Pilates - Casual Class<hr />Total Participants : 1<hr /><span>Darren Rieck</span><br />" 
    style="float:left; margin:2px 0px 0px 5px; font-weight:bold; font-size:11px; ">
	Pilates - Casual Class    
    </div>

<!-- End Populate Slot -->
    
    
    </div>
    </div>
    <!-- End Diary Column -->
    <!-- Start Diary Column -->
    <div class="DiaryColumnContainer ContextOn 31 EmptySlots" style="cursor:pointer;" data-apptid="" data-time="12:40" data-staffid="14" data-staffname="Emile  Cloete" data-status="" data-key="31" data-clientid="" data-clientname="" data-newclient="" data-extended="" data-primaryid="" data-invoiced="" data-caseid="" data-type="">
    
    <div class="DiaryColumn" >

<!-- Start Lunch Time -->
<!-- End Lunch Time -->
	
<!-- Start Populate Slot -->
<!-- End Populate Slot -->
    
    
    </div>
    </div>
    <!-- End Diary Column -->
    <!-- Start Diary Column -->
    <div class="DiaryColumnContainer ContextOn 31 EmptySlots" style="cursor:pointer;" data-apptid="" data-time="12:40" data-staffid="1" data-staffname="Darren  Rieck" data-status="" data-key="31" data-clientid="" data-clientname="" data-newclient="" data-extended="" data-primaryid="" data-invoiced="" data-caseid="" data-type="">
    
    <div class="DiaryColumn" >

<!-- Start Lunch Time -->
<!-- End Lunch Time -->
	
<!-- Start Populate Slot -->
<!-- End Populate Slot -->
    
    
    </div>
    </div>
    <!-- End Diary Column -->
    <!-- Start Diary Column -->
    <div class="DiaryColumnContainer ContextOn 31 EmptySlots" style="cursor:pointer;" data-apptid="" data-time="12:40" data-staffid="6" data-staffname="Karen  Kitchener" data-status="" data-key="31" data-clientid="" data-clientname="" data-newclient="" data-extended="" data-primaryid="" data-invoiced="" data-caseid="" data-type="">
    
    <div class="DiaryColumn" >

<!-- Start Lunch Time -->
<!-- End Lunch Time -->
	
<!-- Start Populate Slot -->
<!-- End Populate Slot -->
    
    
    </div>
    </div>
    <!-- End Diary Column -->
    <!-- Start Diary Column -->
    <div class="DiaryColumnContainer ContextOn 32 EmptySlots" style="cursor:pointer;" data-apptid="" data-time="12:50" data-staffid="26" data-staffname="Bec Webberley" data-status="" data-key="32" data-clientid="" data-clientname="" data-newclient="" data-extended="" data-primaryid="" data-invoiced="" data-caseid="" data-type="">
    
    <div class="DiaryColumn" >

<!-- Start Lunch Time -->
<!-- End Lunch Time -->
	
<!-- Start Populate Slot -->
<!-- End Populate Slot -->
    
    
    </div>
    </div>
    <!-- End Diary Column -->
    <!-- Start Diary Column -->
    <div class="DiaryColumnContainer ContextOn 32 EmptySlots" style="cursor:pointer;" data-apptid="" data-time="12:50" data-staffid="7" data-staffname="Tamara Shaw" data-status="" data-key="32" data-clientid="" data-clientname="" data-newclient="" data-extended="" data-primaryid="" data-invoiced="" data-caseid="" data-type="">
    
    <div class="DiaryColumn" >

<!-- Start Lunch Time -->
<div style="color:#666; margin-top:3px; font-style:italic; font-size:9px;">Lunch</div><!-- End Lunch Time -->
	
<!-- Start Populate Slot -->
<!-- End Populate Slot -->
    
    
    </div>
    </div>
    <!-- End Diary Column -->
    <!-- Start Diary Column -->
    <div class="DiaryColumnContainer ContextOn 32 EmptySlots" style="cursor:pointer;" data-apptid="" data-time="12:50" data-staffid="16" data-staffname="Olivia  Moy" data-status="" data-key="32" data-clientid="" data-clientname="" data-newclient="" data-extended="" data-primaryid="" data-invoiced="" data-caseid="" data-type="">
    
    <div class="DiaryColumn" >

<!-- Start Lunch Time -->
<div style="color:#666; margin-top:3px; font-style:italic; font-size:9px;">Lunch</div><!-- End Lunch Time -->
	
<!-- Start Populate Slot -->
<!-- End Populate Slot -->
    
    
    </div>
    </div>
    <!-- End Diary Column -->
    <!-- Start Diary Column -->
    <div class="DiaryColumnContainer ContextOn 32 EmptySlots" style="cursor:pointer;" data-apptid="" data-time="12:50" data-staffid="18" data-staffname="Andrew  Rashleigh" data-status="" data-key="32" data-clientid="" data-clientname="" data-newclient="" data-extended="" data-primaryid="" data-invoiced="" data-caseid="" data-type="">
    
    <div class="DiaryColumn" >

<!-- Start Lunch Time -->
<!-- End Lunch Time -->
	
<!-- Start Populate Slot -->
<!-- End Populate Slot -->
    
    
    </div>
    </div>
    <!-- End Diary Column -->
    <!-- Start Diary Column -->
    <div class="DiaryColumnContainer ContextOn 32 EmptySlots" style="cursor:pointer;" data-apptid="" data-time="12:50" data-staffid="14" data-staffname="Emile  Cloete" data-status="" data-key="32" data-clientid="" data-clientname="" data-newclient="" data-extended="" data-primaryid="" data-invoiced="" data-caseid="" data-type="">
    
    <div class="DiaryColumn" >

<!-- Start Lunch Time -->
<!-- End Lunch Time -->
	
<!-- Start Populate Slot -->
<!-- End Populate Slot -->
    
    
    </div>
    </div>
    <!-- End Diary Column -->
    <!-- Start Diary Column -->
    <div class="DiaryColumnContainer ContextOn 32 EmptySlots" style="cursor:pointer;" data-apptid="" data-time="12:50" data-staffid="1" data-staffname="Darren  Rieck" data-status="" data-key="32" data-clientid="" data-clientname="" data-newclient="" data-extended="" data-primaryid="" data-invoiced="" data-caseid="" data-type="">
    
    <div class="DiaryColumn" >

<!-- Start Lunch Time -->
<!-- End Lunch Time -->
	
<!-- Start Populate Slot -->
<!-- End Populate Slot -->
    
    
    </div>
    </div>
    <!-- End Diary Column -->
    <!-- Start Diary Column -->
    <div class="DiaryColumnContainer ContextOn 32 EmptySlots" style="cursor:pointer;" data-apptid="" data-time="12:50" data-staffid="6" data-staffname="Karen  Kitchener" data-status="" data-key="32" data-clientid="" data-clientname="" data-newclient="" data-extended="" data-primaryid="" data-invoiced="" data-caseid="" data-type="">
    
    <div class="DiaryColumn" >

<!-- Start Lunch Time -->
<!-- End Lunch Time -->
	
<!-- Start Populate Slot -->
<!-- End Populate Slot -->
    
    
    </div>
    </div>
    <!-- End Diary Column -->
    <!-- Start Diary Column -->
    <div class="DiaryColumnContainer ContextOn 33 EmptySlots" style="cursor:pointer;" data-apptid="" data-time="13:00" data-staffid="26" data-staffname="Bec Webberley" data-status="" data-key="33" data-clientid="" data-clientname="" data-newclient="" data-extended="" data-primaryid="" data-invoiced="" data-caseid="" data-type="">
    
    <div class="DiaryColumn" >

<!-- Start Lunch Time -->
<!-- End Lunch Time -->
	
<!-- Start Populate Slot -->
<!-- End Populate Slot -->
    
    
    </div>
    </div>
    <!-- End Diary Column -->
    <!-- Start Diary Column -->
    <div class="DiaryColumnContainer ContextOn 33 FilledSlots" style="cursor:pointer;" data-apptid="30431" data-time="13:00" data-staffid="7" data-staffname="Tamara Shaw" data-status="StdAppt" data-key="33" data-clientid="1387" data-clientname="Amanda Saintsbury" data-newclient="0" data-extended="1" data-primaryid="0" data-invoiced="" data-caseid="2700" data-type="Services">
    
    <div class="DiaryColumnSchedule" style="color:#003399; background-color:#D1D6D6;">

<!-- Start Lunch Time -->
<!-- End Lunch Time -->
	
<!-- Start Populate Slot -->
    <div class="ClientType SlotContent" style="float:left; width:15px; background-color:#006; color:#FFF; margin-left:2px; margin-top:2px;">P</div>
    

    <div class="Patient SlotContent DiaryToolTip" 
    title="<span>Provider : Tamara Shaw<hr />Date : 19/07/2012 - Time : 13:00</span><hr />Amanda Saintsbury<br /><br />Contact No : 0417709622<hr />Private -  Physio Std<hr />Case : PVT - Hip<hr />" 
    style="float:left; margin:2px 0px 0px 5px; font-weight:bold; font-size:11px; ">
	Amanda S     
    </div>

<!-- End Populate Slot -->
    
    
    </div>
    </div>
    <!-- End Diary Column -->
    <!-- Start Diary Column -->
    <div class="DiaryColumnContainer ContextOn 33 EmptySlots" style="cursor:pointer;" data-apptid="" data-time="13:00" data-staffid="16" data-staffname="Olivia  Moy" data-status="" data-key="33" data-clientid="" data-clientname="" data-newclient="" data-extended="" data-primaryid="" data-invoiced="" data-caseid="" data-type="">
    
    <div class="DiaryColumnSchedule" >

<!-- Start Lunch Time -->
<!-- End Lunch Time -->
	
<!-- Start Populate Slot -->
<!-- End Populate Slot -->
    
    
    </div>
    </div>
    <!-- End Diary Column -->
    <!-- Start Diary Column -->
    <div class="DiaryColumnContainer ContextOn 33 EmptySlots" style="cursor:pointer;" data-apptid="" data-time="13:00" data-staffid="18" data-staffname="Andrew  Rashleigh" data-status="" data-key="33" data-clientid="" data-clientname="" data-newclient="" data-extended="" data-primaryid="" data-invoiced="" data-caseid="" data-type="">
    
    <div class="DiaryColumn" >

<!-- Start Lunch Time -->
<!-- End Lunch Time -->
	
<!-- Start Populate Slot -->
<!-- End Populate Slot -->
    
    
    </div>
    </div>
    <!-- End Diary Column -->
    <!-- Start Diary Column -->
    <div class="DiaryColumnContainer ContextOn 33 EmptySlots" style="cursor:pointer;" data-apptid="" data-time="13:00" data-staffid="14" data-staffname="Emile  Cloete" data-status="" data-key="33" data-clientid="" data-clientname="" data-newclient="" data-extended="" data-primaryid="" data-invoiced="" data-caseid="" data-type="">
    
    <div class="DiaryColumnSchedule" >

<!-- Start Lunch Time -->
<!-- End Lunch Time -->
	
<!-- Start Populate Slot -->
<!-- End Populate Slot -->
    
    
    </div>
    </div>
    <!-- End Diary Column -->
    <!-- Start Diary Column -->
    <div class="DiaryColumnContainer ContextOn 33 EmptySlots" style="cursor:pointer;" data-apptid="" data-time="13:00" data-staffid="1" data-staffname="Darren  Rieck" data-status="" data-key="33" data-clientid="" data-clientname="" data-newclient="" data-extended="" data-primaryid="" data-invoiced="" data-caseid="" data-type="">
    
    <div class="DiaryColumn" >

<!-- Start Lunch Time -->
<!-- End Lunch Time -->
	
<!-- Start Populate Slot -->
<!-- End Populate Slot -->
    
    
    </div>
    </div>
    <!-- End Diary Column -->
    <!-- Start Diary Column -->
    <div class="DiaryColumnContainer ContextOn 33 EmptySlots" style="cursor:pointer;" data-apptid="" data-time="13:00" data-staffid="6" data-staffname="Karen  Kitchener" data-status="" data-key="33" data-clientid="" data-clientname="" data-newclient="" data-extended="" data-primaryid="" data-invoiced="" data-caseid="" data-type="">
    
    <div class="DiaryColumn" >

<!-- Start Lunch Time -->
<!-- End Lunch Time -->
	
<!-- Start Populate Slot -->
<!-- End Populate Slot -->
    
    
    </div>
    </div>
    <!-- End Diary Column -->
    <!-- Start Diary Column -->
    <div class="DiaryColumnContainer ContextOn 34 EmptySlots" style="cursor:pointer;" data-apptid="" data-time="13:10" data-staffid="26" data-staffname="Bec Webberley" data-status="" data-key="34" data-clientid="" data-clientname="" data-newclient="" data-extended="" data-primaryid="" data-invoiced="" data-caseid="" data-type="">
    
    <div class="DiaryColumn" >

<!-- Start Lunch Time -->
<!-- End Lunch Time -->
	
<!-- Start Populate Slot -->
<!-- End Populate Slot -->
    
    
    </div>
    </div>
    <!-- End Diary Column -->
    <!-- Start Diary Column -->
    <div class="DiaryColumnContainer ContextOff 34 " style="cursor:not-allowed;" data-apptid="32869" data-time="13:10" data-staffid="7" data-staffname="Tamara Shaw" data-status="StdAppt" data-key="34" data-clientid="1387" data-clientname="Amanda Saintsbury" data-newclient="0" data-extended="0" data-primaryid="30431" data-invoiced="" data-caseid="" data-type="Services">
    
    <div class="DiaryColumnSchedule" style="color:#003399; background-color:#D1D6D6;">

<!-- Start Lunch Time -->
<!-- End Lunch Time -->
	
<!-- Start Populate Slot -->
<!-- End Populate Slot -->
    
    
    </div>
    </div>
    <!-- End Diary Column -->
    <!-- Start Diary Column -->
    <div class="DiaryColumnContainer ContextOn 34 EmptySlots" style="cursor:pointer;" data-apptid="" data-time="13:10" data-staffid="16" data-staffname="Olivia  Moy" data-status="" data-key="34" data-clientid="" data-clientname="" data-newclient="" data-extended="" data-primaryid="" data-invoiced="" data-caseid="" data-type="">
    
    <div class="DiaryColumnSchedule" >

<!-- Start Lunch Time -->
<!-- End Lunch Time -->
	
<!-- Start Populate Slot -->
<!-- End Populate Slot -->
    
    
    </div>
    </div>
    <!-- End Diary Column -->
    <!-- Start Diary Column -->
    <div class="DiaryColumnContainer ContextOn 34 EmptySlots" style="cursor:pointer;" data-apptid="" data-time="13:10" data-staffid="18" data-staffname="Andrew  Rashleigh" data-status="" data-key="34" data-clientid="" data-clientname="" data-newclient="" data-extended="" data-primaryid="" data-invoiced="" data-caseid="" data-type="">
    
    <div class="DiaryColumn" >

<!-- Start Lunch Time -->
<!-- End Lunch Time -->
	
<!-- Start Populate Slot -->
<!-- End Populate Slot -->
    
    
    </div>
    </div>
    <!-- End Diary Column -->
    <!-- Start Diary Column -->
    <div class="DiaryColumnContainer ContextOn 34 EmptySlots" style="cursor:pointer;" data-apptid="" data-time="13:10" data-staffid="14" data-staffname="Emile  Cloete" data-status="" data-key="34" data-clientid="" data-clientname="" data-newclient="" data-extended="" data-primaryid="" data-invoiced="" data-caseid="" data-type="">
    
    <div class="DiaryColumnSchedule" >

<!-- Start Lunch Time -->
<!-- End Lunch Time -->
	
<!-- Start Populate Slot -->
<!-- End Populate Slot -->
    
    
    </div>
    </div>
    <!-- End Diary Column -->
    <!-- Start Diary Column -->
    <div class="DiaryColumnContainer ContextOn 34 EmptySlots" style="cursor:pointer;" data-apptid="" data-time="13:10" data-staffid="1" data-staffname="Darren  Rieck" data-status="" data-key="34" data-clientid="" data-clientname="" data-newclient="" data-extended="" data-primaryid="" data-invoiced="" data-caseid="" data-type="">
    
    <div class="DiaryColumn" >

<!-- Start Lunch Time -->
<!-- End Lunch Time -->
	
<!-- Start Populate Slot -->
<!-- End Populate Slot -->
    
    
    </div>
    </div>
    <!-- End Diary Column -->
    <!-- Start Diary Column -->
    <div class="DiaryColumnContainer ContextOn 34 EmptySlots" style="cursor:pointer;" data-apptid="" data-time="13:10" data-staffid="6" data-staffname="Karen  Kitchener" data-status="" data-key="34" data-clientid="" data-clientname="" data-newclient="" data-extended="" data-primaryid="" data-invoiced="" data-caseid="" data-type="">
    
    <div class="DiaryColumn" >

<!-- Start Lunch Time -->
<!-- End Lunch Time -->
	
<!-- Start Populate Slot -->
<!-- End Populate Slot -->
    
    
    </div>
    </div>
    <!-- End Diary Column -->
    <!-- Start Diary Column -->
    <div class="DiaryColumnContainer ContextOn 35 EmptySlots" style="cursor:pointer;" data-apptid="" data-time="13:20" data-staffid="26" data-staffname="Bec Webberley" data-status="" data-key="35" data-clientid="" data-clientname="" data-newclient="" data-extended="" data-primaryid="" data-invoiced="" data-caseid="" data-type="">
    
    <div class="DiaryColumn" >

<!-- Start Lunch Time -->
<!-- End Lunch Time -->
	
<!-- Start Populate Slot -->
<!-- End Populate Slot -->
    
    
    </div>
    </div>
    <!-- End Diary Column -->
    <!-- Start Diary Column -->
    <div class="DiaryColumnContainer ContextOff 35 " style="cursor:not-allowed;" data-apptid="32870" data-time="13:20" data-staffid="7" data-staffname="Tamara Shaw" data-status="StdAppt" data-key="35" data-clientid="1387" data-clientname="Amanda Saintsbury" data-newclient="0" data-extended="0" data-primaryid="30431" data-invoiced="" data-caseid="" data-type="Services">
    
    <div class="DiaryColumnSchedule" style="color:#003399; background-color:#D1D6D6;">

<!-- Start Lunch Time -->
<!-- End Lunch Time -->
	
<!-- Start Populate Slot -->
<!-- End Populate Slot -->
    
    
    </div>
    </div>
    <!-- End Diary Column -->
    <!-- Start Diary Column -->
    <div class="DiaryColumnContainer ContextOn 35 EmptySlots" style="cursor:pointer;" data-apptid="" data-time="13:20" data-staffid="16" data-staffname="Olivia  Moy" data-status="" data-key="35" data-clientid="" data-clientname="" data-newclient="" data-extended="" data-primaryid="" data-invoiced="" data-caseid="" data-type="">
    
    <div class="DiaryColumnSchedule" >

<!-- Start Lunch Time -->
<!-- End Lunch Time -->
	
<!-- Start Populate Slot -->
<!-- End Populate Slot -->
    
    
    </div>
    </div>
    <!-- End Diary Column -->
    <!-- Start Diary Column -->
    <div class="DiaryColumnContainer ContextOn 35 EmptySlots" style="cursor:pointer;" data-apptid="" data-time="13:20" data-staffid="18" data-staffname="Andrew  Rashleigh" data-status="" data-key="35" data-clientid="" data-clientname="" data-newclient="" data-extended="" data-primaryid="" data-invoiced="" data-caseid="" data-type="">
    
    <div class="DiaryColumn" >

<!-- Start Lunch Time -->
<!-- End Lunch Time -->
	
<!-- Start Populate Slot -->
<!-- End Populate Slot -->
    
    
    </div>
    </div>
    <!-- End Diary Column -->
    <!-- Start Diary Column -->
    <div class="DiaryColumnContainer ContextOn 35 EmptySlots" style="cursor:pointer;" data-apptid="" data-time="13:20" data-staffid="14" data-staffname="Emile  Cloete" data-status="" data-key="35" data-clientid="" data-clientname="" data-newclient="" data-extended="" data-primaryid="" data-invoiced="" data-caseid="" data-type="">
    
    <div class="DiaryColumnSchedule" >

<!-- Start Lunch Time -->
<!-- End Lunch Time -->
	
<!-- Start Populate Slot -->
<!-- End Populate Slot -->
    
    
    </div>
    </div>
    <!-- End Diary Column -->
    <!-- Start Diary Column -->
    <div class="DiaryColumnContainer ContextOn 35 EmptySlots" style="cursor:pointer;" data-apptid="" data-time="13:20" data-staffid="1" data-staffname="Darren  Rieck" data-status="" data-key="35" data-clientid="" data-clientname="" data-newclient="" data-extended="" data-primaryid="" data-invoiced="" data-caseid="" data-type="">
    
    <div class="DiaryColumn" >

<!-- Start Lunch Time -->
<!-- End Lunch Time -->
	
<!-- Start Populate Slot -->
<!-- End Populate Slot -->
    
    
    </div>
    </div>
    <!-- End Diary Column -->
    <!-- Start Diary Column -->
    <div class="DiaryColumnContainer ContextOn 35 EmptySlots" style="cursor:pointer;" data-apptid="" data-time="13:20" data-staffid="6" data-staffname="Karen  Kitchener" data-status="" data-key="35" data-clientid="" data-clientname="" data-newclient="" data-extended="" data-primaryid="" data-invoiced="" data-caseid="" data-type="">
    
    <div class="DiaryColumn" >

<!-- Start Lunch Time -->
<!-- End Lunch Time -->
	
<!-- Start Populate Slot -->
<!-- End Populate Slot -->
    
    
    </div>
    </div>
    <!-- End Diary Column -->
    <!-- Start Diary Column -->
    <div class="DiaryColumnContainer ContextOn 36 EmptySlots" style="cursor:pointer;" data-apptid="" data-time="13:30" data-staffid="26" data-staffname="Bec Webberley" data-status="" data-key="36" data-clientid="" data-clientname="" data-newclient="" data-extended="" data-primaryid="" data-invoiced="" data-caseid="" data-type="">
    
    <div class="DiaryColumn" >

<!-- Start Lunch Time -->
<!-- End Lunch Time -->
	
<!-- Start Populate Slot -->
<!-- End Populate Slot -->
    
    
    </div>
    </div>
    <!-- End Diary Column -->
    <!-- Start Diary Column -->
    <div class="DiaryColumnContainer ContextOn 36 FilledSlots" style="cursor:pointer;" data-apptid="31222" data-time="13:30" data-staffid="7" data-staffname="Tamara Shaw" data-status="StdAppt" data-key="36" data-clientid="1111" data-clientname="Jane (Berenice) McGuinness" data-newclient="0" data-extended="1" data-primaryid="0" data-invoiced="" data-caseid="2356" data-type="Services">
    
    <div class="DiaryColumnSchedule" style="color:#003399; background-color:#D1D6D6;">

<!-- Start Lunch Time -->
<!-- End Lunch Time -->
	
<!-- Start Populate Slot -->
    <div class="ClientType SlotContent" style="float:left; width:15px; background-color:#006; color:#FFF; margin-left:2px; margin-top:2px;">P</div>
    

    <div class="Patient SlotContent DiaryToolTip" 
    title="<span>Provider : Tamara Shaw<hr />Date : 19/07/2012 - Time : 13:30</span><hr />Jane (Berenice) McGuinness<br /><br />Contact No : 0409489537<hr />Private -  Physio Std<hr />Case : Pvt - <hr />" 
    style="float:left; margin:2px 0px 0px 5px; font-weight:bold; font-size:11px; ">
	Jane ( M     
    </div>

<!-- End Populate Slot -->
    
    
    </div>
    </div>
    <!-- End Diary Column -->
    <!-- Start Diary Column -->
    <div class="DiaryColumnContainer ContextOn 36 EmptySlots" style="cursor:pointer;" data-apptid="" data-time="13:30" data-staffid="16" data-staffname="Olivia  Moy" data-status="" data-key="36" data-clientid="" data-clientname="" data-newclient="" data-extended="" data-primaryid="" data-invoiced="" data-caseid="" data-type="">
    
    <div class="DiaryColumnSchedule" >

<!-- Start Lunch Time -->
<!-- End Lunch Time -->
	
<!-- Start Populate Slot -->
<!-- End Populate Slot -->
    
    
    </div>
    </div>
    <!-- End Diary Column -->
    <!-- Start Diary Column -->
    <div class="DiaryColumnContainer ContextOn 36 EmptySlots" style="cursor:pointer;" data-apptid="" data-time="13:30" data-staffid="18" data-staffname="Andrew  Rashleigh" data-status="" data-key="36" data-clientid="" data-clientname="" data-newclient="" data-extended="" data-primaryid="" data-invoiced="" data-caseid="" data-type="">
    
    <div class="DiaryColumn" >

<!-- Start Lunch Time -->
<!-- End Lunch Time -->
	
<!-- Start Populate Slot -->
<!-- End Populate Slot -->
    
    
    </div>
    </div>
    <!-- End Diary Column -->
    <!-- Start Diary Column -->
    <div class="DiaryColumnContainer ContextOn 36 EmptySlots" style="cursor:pointer;" data-apptid="" data-time="13:30" data-staffid="14" data-staffname="Emile  Cloete" data-status="" data-key="36" data-clientid="" data-clientname="" data-newclient="" data-extended="" data-primaryid="" data-invoiced="" data-caseid="" data-type="">
    
    <div class="DiaryColumnSchedule" >

<!-- Start Lunch Time -->
<!-- End Lunch Time -->
	
<!-- Start Populate Slot -->
<!-- End Populate Slot -->
    
    
    </div>
    </div>
    <!-- End Diary Column -->
    <!-- Start Diary Column -->
    <div class="DiaryColumnContainer ContextOn 36 EmptySlots" style="cursor:pointer;" data-apptid="" data-time="13:30" data-staffid="1" data-staffname="Darren  Rieck" data-status="" data-key="36" data-clientid="" data-clientname="" data-newclient="" data-extended="" data-primaryid="" data-invoiced="" data-caseid="" data-type="">
    
    <div class="DiaryColumn" >

<!-- Start Lunch Time -->
<!-- End Lunch Time -->
	
<!-- Start Populate Slot -->
<!-- End Populate Slot -->
    
    
    </div>
    </div>
    <!-- End Diary Column -->
    <!-- Start Diary Column -->
    <div class="DiaryColumnContainer ContextOn 36 EmptySlots" style="cursor:pointer;" data-apptid="" data-time="13:30" data-staffid="6" data-staffname="Karen  Kitchener" data-status="" data-key="36" data-clientid="" data-clientname="" data-newclient="" data-extended="" data-primaryid="" data-invoiced="" data-caseid="" data-type="">
    
    <div class="DiaryColumn" >

<!-- Start Lunch Time -->
<!-- End Lunch Time -->
	
<!-- Start Populate Slot -->
<!-- End Populate Slot -->
    
    
    </div>
    </div>
    <!-- End Diary Column -->
    <!-- Start Diary Column -->
    <div class="DiaryColumnContainer ContextOn 37 EmptySlots" style="cursor:pointer;" data-apptid="" data-time="13:40" data-staffid="26" data-staffname="Bec Webberley" data-status="" data-key="37" data-clientid="" data-clientname="" data-newclient="" data-extended="" data-primaryid="" data-invoiced="" data-caseid="" data-type="">
    
    <div class="DiaryColumn" >

<!-- Start Lunch Time -->
<!-- End Lunch Time -->
	
<!-- Start Populate Slot -->
<!-- End Populate Slot -->
    
    
    </div>
    </div>
    <!-- End Diary Column -->
    <!-- Start Diary Column -->
    <div class="DiaryColumnContainer ContextOff 37 " style="cursor:not-allowed;" data-apptid="31223" data-time="13:40" data-staffid="7" data-staffname="Tamara Shaw" data-status="StdAppt" data-key="37" data-clientid="1111" data-clientname="Jane (Berenice) McGuinness" data-newclient="0" data-extended="0" data-primaryid="31222" data-invoiced="" data-caseid="" data-type="Services">
    
    <div class="DiaryColumnSchedule" style="color:#003399; background-color:#D1D6D6;">

<!-- Start Lunch Time -->
<!-- End Lunch Time -->
	
<!-- Start Populate Slot -->
<!-- End Populate Slot -->
    
    
    </div>
    </div>
    <!-- End Diary Column -->
    <!-- Start Diary Column -->
    <div class="DiaryColumnContainer ContextOn 37 EmptySlots" style="cursor:pointer;" data-apptid="" data-time="13:40" data-staffid="16" data-staffname="Olivia  Moy" data-status="" data-key="37" data-clientid="" data-clientname="" data-newclient="" data-extended="" data-primaryid="" data-invoiced="" data-caseid="" data-type="">
    
    <div class="DiaryColumnSchedule" >

<!-- Start Lunch Time -->
<!-- End Lunch Time -->
	
<!-- Start Populate Slot -->
<!-- End Populate Slot -->
    
    
    </div>
    </div>
    <!-- End Diary Column -->
    <!-- Start Diary Column -->
    <div class="DiaryColumnContainer ContextOn 37 EmptySlots" style="cursor:pointer;" data-apptid="" data-time="13:40" data-staffid="18" data-staffname="Andrew  Rashleigh" data-status="" data-key="37" data-clientid="" data-clientname="" data-newclient="" data-extended="" data-primaryid="" data-invoiced="" data-caseid="" data-type="">
    
    <div class="DiaryColumn" >

<!-- Start Lunch Time -->
<!-- End Lunch Time -->
	
<!-- Start Populate Slot -->
<!-- End Populate Slot -->
    
    
    </div>
    </div>
    <!-- End Diary Column -->
    <!-- Start Diary Column -->
    <div class="DiaryColumnContainer ContextOn 37 EmptySlots" style="cursor:pointer;" data-apptid="" data-time="13:40" data-staffid="14" data-staffname="Emile  Cloete" data-status="" data-key="37" data-clientid="" data-clientname="" data-newclient="" data-extended="" data-primaryid="" data-invoiced="" data-caseid="" data-type="">
    
    <div class="DiaryColumnSchedule" >

<!-- Start Lunch Time -->
<!-- End Lunch Time -->
	
<!-- Start Populate Slot -->
<!-- End Populate Slot -->
    
    
    </div>
    </div>
    <!-- End Diary Column -->
    <!-- Start Diary Column -->
    <div class="DiaryColumnContainer ContextOn 37 EmptySlots" style="cursor:pointer;" data-apptid="" data-time="13:40" data-staffid="1" data-staffname="Darren  Rieck" data-status="" data-key="37" data-clientid="" data-clientname="" data-newclient="" data-extended="" data-primaryid="" data-invoiced="" data-caseid="" data-type="">
    
    <div class="DiaryColumn" >

<!-- Start Lunch Time -->
<!-- End Lunch Time -->
	
<!-- Start Populate Slot -->
<!-- End Populate Slot -->
    
    
    </div>
    </div>
    <!-- End Diary Column -->
    <!-- Start Diary Column -->
    <div class="DiaryColumnContainer ContextOn 37 EmptySlots" style="cursor:pointer;" data-apptid="" data-time="13:40" data-staffid="6" data-staffname="Karen  Kitchener" data-status="" data-key="37" data-clientid="" data-clientname="" data-newclient="" data-extended="" data-primaryid="" data-invoiced="" data-caseid="" data-type="">
    
    <div class="DiaryColumn" >

<!-- Start Lunch Time -->
<!-- End Lunch Time -->
	
<!-- Start Populate Slot -->
<!-- End Populate Slot -->
    
    
    </div>
    </div>
    <!-- End Diary Column -->
    <!-- Start Diary Column -->
    <div class="DiaryColumnContainer ContextOn 38 EmptySlots" style="cursor:pointer;" data-apptid="" data-time="13:50" data-staffid="26" data-staffname="Bec Webberley" data-status="" data-key="38" data-clientid="" data-clientname="" data-newclient="" data-extended="" data-primaryid="" data-invoiced="" data-caseid="" data-type="">
    
    <div class="DiaryColumn" >

<!-- Start Lunch Time -->
<!-- End Lunch Time -->
	
<!-- Start Populate Slot -->
<!-- End Populate Slot -->
    
    
    </div>
    </div>
    <!-- End Diary Column -->
    <!-- Start Diary Column -->
    <div class="DiaryColumnContainer ContextOff 38 " style="cursor:not-allowed;" data-apptid="31224" data-time="13:50" data-staffid="7" data-staffname="Tamara Shaw" data-status="StdAppt" data-key="38" data-clientid="1111" data-clientname="Jane (Berenice) McGuinness" data-newclient="0" data-extended="0" data-primaryid="31222" data-invoiced="" data-caseid="" data-type="Services">
    
    <div class="DiaryColumnSchedule" style="color:#003399; background-color:#D1D6D6;">

<!-- Start Lunch Time -->
<!-- End Lunch Time -->
	
<!-- Start Populate Slot -->
<!-- End Populate Slot -->
    
    
    </div>
    </div>
    <!-- End Diary Column -->
    <!-- Start Diary Column -->
    <div class="DiaryColumnContainer ContextOn 38 EmptySlots" style="cursor:pointer;" data-apptid="" data-time="13:50" data-staffid="16" data-staffname="Olivia  Moy" data-status="" data-key="38" data-clientid="" data-clientname="" data-newclient="" data-extended="" data-primaryid="" data-invoiced="" data-caseid="" data-type="">
    
    <div class="DiaryColumnSchedule" >

<!-- Start Lunch Time -->
<!-- End Lunch Time -->
	
<!-- Start Populate Slot -->
<!-- End Populate Slot -->
    
    
    </div>
    </div>
    <!-- End Diary Column -->
    <!-- Start Diary Column -->
    <div class="DiaryColumnContainer ContextOn 38 EmptySlots" style="cursor:pointer;" data-apptid="" data-time="13:50" data-staffid="18" data-staffname="Andrew  Rashleigh" data-status="" data-key="38" data-clientid="" data-clientname="" data-newclient="" data-extended="" data-primaryid="" data-invoiced="" data-caseid="" data-type="">
    
    <div class="DiaryColumn" >

<!-- Start Lunch Time -->
<!-- End Lunch Time -->
	
<!-- Start Populate Slot -->
<!-- End Populate Slot -->
    
    
    </div>
    </div>
    <!-- End Diary Column -->
    <!-- Start Diary Column -->
    <div class="DiaryColumnContainer ContextOn 38 EmptySlots" style="cursor:pointer;" data-apptid="" data-time="13:50" data-staffid="14" data-staffname="Emile  Cloete" data-status="" data-key="38" data-clientid="" data-clientname="" data-newclient="" data-extended="" data-primaryid="" data-invoiced="" data-caseid="" data-type="">
    
    <div class="DiaryColumnSchedule" >

<!-- Start Lunch Time -->
<!-- End Lunch Time -->
	
<!-- Start Populate Slot -->
<!-- End Populate Slot -->
    
    
    </div>
    </div>
    <!-- End Diary Column -->
    <!-- Start Diary Column -->
    <div class="DiaryColumnContainer ContextOn 38 EmptySlots" style="cursor:pointer;" data-apptid="" data-time="13:50" data-staffid="1" data-staffname="Darren  Rieck" data-status="" data-key="38" data-clientid="" data-clientname="" data-newclient="" data-extended="" data-primaryid="" data-invoiced="" data-caseid="" data-type="">
    
    <div class="DiaryColumn" >

<!-- Start Lunch Time -->
<!-- End Lunch Time -->
	
<!-- Start Populate Slot -->
<!-- End Populate Slot -->
    
    
    </div>
    </div>
    <!-- End Diary Column -->
    <!-- Start Diary Column -->
    <div class="DiaryColumnContainer ContextOn 38 EmptySlots" style="cursor:pointer;" data-apptid="" data-time="13:50" data-staffid="6" data-staffname="Karen  Kitchener" data-status="" data-key="38" data-clientid="" data-clientname="" data-newclient="" data-extended="" data-primaryid="" data-invoiced="" data-caseid="" data-type="">
    
    <div class="DiaryColumn" >

<!-- Start Lunch Time -->
<!-- End Lunch Time -->
	
<!-- Start Populate Slot -->
<!-- End Populate Slot -->
    
    
    </div>
    </div>
    <!-- End Diary Column -->
    <!-- Start Diary Column -->
    <div class="DiaryColumnContainer ContextOn 39 EmptySlots" style="cursor:pointer;" data-apptid="" data-time="14:00" data-staffid="26" data-staffname="Bec Webberley" data-status="" data-key="39" data-clientid="" data-clientname="" data-newclient="" data-extended="" data-primaryid="" data-invoiced="" data-caseid="" data-type="">
    
    <div class="DiaryColumn" >

<!-- Start Lunch Time -->
<!-- End Lunch Time -->
	
<!-- Start Populate Slot -->
<!-- End Populate Slot -->
    
    
    </div>
    </div>
    <!-- End Diary Column -->
    <!-- Start Diary Column -->
    <div class="DiaryColumnContainer ContextOn 39 FilledSlots" style="cursor:pointer;" data-apptid="32103" data-time="14:00" data-staffid="7" data-staffname="Tamara Shaw" data-status="StdAppt" data-key="39" data-clientid="1402" data-clientname="Liban Salad" data-newclient="0" data-extended="1" data-primaryid="0" data-invoiced="" data-caseid="2723" data-type="Services">
    
    <div class="DiaryColumnSchedule" style="color:#003399; background-color:#D1D6D6;">

<!-- Start Lunch Time -->
<!-- End Lunch Time -->
	
<!-- Start Populate Slot -->
    <div class="ClientType SlotContent" style="float:left; width:15px; background-color:#360; color:#FFF; margin-left:2px; margin-top:2px;">T</div>
    

    <div class="Patient SlotContent DiaryToolTip" 
    title="<span>Provider : Tamara Shaw<hr />Date : 19/07/2012 - Time : 14:00</span><hr />Liban Salad<br /><br />Contact No : 0478798482<hr /><span>Good Health
Med Cert to 17/7</span><hr />Third Party : Workcover<hr />WC - Subs Consult Std Level B<hr />Case : W/C - Back<hr />" 
    style="float:left; margin:2px 0px 0px 5px; font-weight:bold; font-size:11px; ">
	Liban Salad    
    </div>

<img src="/images/icons/numbers/0.png" style="float:right; margin-right:2px;" title="Third Party Sessions Left"; /><!-- End Populate Slot -->
    
    
    </div>
    </div>
    <!-- End Diary Column -->
    <!-- Start Diary Column -->
    <div class="DiaryColumnContainer ContextOn 39 FilledSlots" style="cursor:pointer;" data-apptid="32757" data-time="14:00" data-staffid="16" data-staffname="Olivia  Moy" data-status="StdAppt" data-key="39" data-clientid="1304" data-clientname="Peta Austyn" data-newclient="0" data-extended="1" data-primaryid="0" data-invoiced="" data-caseid="2788" data-type="Services">

    
    <div class="DiaryColumnSchedule" style="color:#003399; background-color:#D1D6D6;">

<!-- Start Lunch Time -->
<!-- End Lunch Time -->
	
<!-- Start Populate Slot -->
    <div class="ClientType SlotContent" style="float:left; width:15px; background-color:#006; color:#FFF; margin-left:2px; margin-top:2px;">P</div>
    

    <div class="Patient SlotContent DiaryToolTip" 
    title="<span>Provider : Olivia  Moy<hr />Date : 19/07/2012 - Time : 14:00</span><hr />Peta Austyn<br /><br />Contact No : 0412 644 588<hr />Remedial Massage 1 Hr<hr />Case : Massage<hr />" 
    style="float:left; margin:2px 0px 0px 5px; font-weight:bold; font-size:11px; ">
	Peta Austyn    
    </div>

<!-- End Populate Slot -->
    
    
    </div>
    </div>
    <!-- End Diary Column -->
    <!-- Start Diary Column -->
    <div class="DiaryColumnContainer ContextOn 39 EmptySlots" style="cursor:pointer;" data-apptid="" data-time="14:00" data-staffid="18" data-staffname="Andrew  Rashleigh" data-status="" data-key="39" data-clientid="" data-clientname="" data-newclient="" data-extended="" data-primaryid="" data-invoiced="" data-caseid="" data-type="">
    
    <div class="DiaryColumn" >

<!-- Start Lunch Time -->
<!-- End Lunch Time -->
	
<!-- Start Populate Slot -->
<!-- End Populate Slot -->
    
    
    </div>
    </div>
    <!-- End Diary Column -->
    <!-- Start Diary Column -->
    <div class="DiaryColumnContainer ContextOn 39 EmptySlots" style="cursor:pointer;" data-apptid="" data-time="14:00" data-staffid="14" data-staffname="Emile  Cloete" data-status="" data-key="39" data-clientid="" data-clientname="" data-newclient="" data-extended="" data-primaryid="" data-invoiced="" data-caseid="" data-type="">
    
    <div class="DiaryColumnSchedule" >

<!-- Start Lunch Time -->
<!-- End Lunch Time -->
	
<!-- Start Populate Slot -->
<!-- End Populate Slot -->
    
    
    </div>
    </div>
    <!-- End Diary Column -->
    <!-- Start Diary Column -->
    <div class="DiaryColumnContainer ContextOn 39 EmptySlots" style="cursor:pointer;" data-apptid="" data-time="14:00" data-staffid="1" data-staffname="Darren  Rieck" data-status="" data-key="39" data-clientid="" data-clientname="" data-newclient="" data-extended="" data-primaryid="" data-invoiced="" data-caseid="" data-type="">
    
    <div class="DiaryColumn" >

<!-- Start Lunch Time -->
<!-- End Lunch Time -->
	
<!-- Start Populate Slot -->
<!-- End Populate Slot -->
    
    
    </div>
    </div>
    <!-- End Diary Column -->
    <!-- Start Diary Column -->
    <div class="DiaryColumnContainer ContextOn 39 EmptySlots" style="cursor:pointer;" data-apptid="" data-time="14:00" data-staffid="6" data-staffname="Karen  Kitchener" data-status="" data-key="39" data-clientid="" data-clientname="" data-newclient="" data-extended="" data-primaryid="" data-invoiced="" data-caseid="" data-type="">
    
    <div class="DiaryColumn" >

<!-- Start Lunch Time -->
<!-- End Lunch Time -->
	
<!-- Start Populate Slot -->
<!-- End Populate Slot -->
    
    
    </div>
    </div>
    <!-- End Diary Column -->
    <!-- Start Diary Column -->
    <div class="DiaryColumnContainer ContextOn 40 EmptySlots" style="cursor:pointer;" data-apptid="" data-time="14:10" data-staffid="26" data-staffname="Bec Webberley" data-status="" data-key="40" data-clientid="" data-clientname="" data-newclient="" data-extended="" data-primaryid="" data-invoiced="" data-caseid="" data-type="">
    
    <div class="DiaryColumn" >

<!-- Start Lunch Time -->
<!-- End Lunch Time -->
	
<!-- Start Populate Slot -->
<!-- End Populate Slot -->
    
    
    </div>
    </div>
    <!-- End Diary Column -->
    <!-- Start Diary Column -->
    <div class="DiaryColumnContainer ContextOff 40 " style="cursor:not-allowed;" data-apptid="32104" data-time="14:10" data-staffid="7" data-staffname="Tamara Shaw" data-status="StdAppt" data-key="40" data-clientid="1402" data-clientname="Liban Salad" data-newclient="0" data-extended="0" data-primaryid="32103" data-invoiced="" data-caseid="" data-type="Services">
    
    <div class="DiaryColumnSchedule" style="color:#003399; background-color:#D1D6D6;">

<!-- Start Lunch Time -->
<!-- End Lunch Time -->
	
<!-- Start Populate Slot -->
<!-- End Populate Slot -->
    
    
    </div>
    </div>
    <!-- End Diary Column -->
    <!-- Start Diary Column -->
    <div class="DiaryColumnContainer ContextOff 40 " style="cursor:not-allowed;" data-apptid="32759" data-time="14:10" data-staffid="16" data-staffname="Olivia  Moy" data-status="StdAppt" data-key="40" data-clientid="1304" data-clientname="Peta Austyn" data-newclient="0" data-extended="0" data-primaryid="32757" data-invoiced="" data-caseid="" data-type="Services">
    
    <div class="DiaryColumnSchedule" style="color:#003399; background-color:#D1D6D6;">

<!-- Start Lunch Time -->
<!-- End Lunch Time -->
	
<!-- Start Populate Slot -->
<!-- End Populate Slot -->
    
    
    </div>
    </div>
    <!-- End Diary Column -->
    <!-- Start Diary Column -->
    <div class="DiaryColumnContainer ContextOn 40 EmptySlots" style="cursor:pointer;" data-apptid="" data-time="14:10" data-staffid="18" data-staffname="Andrew  Rashleigh" data-status="" data-key="40" data-clientid="" data-clientname="" data-newclient="" data-extended="" data-primaryid="" data-invoiced="" data-caseid="" data-type="">
    
    <div class="DiaryColumn" >

<!-- Start Lunch Time -->
<!-- End Lunch Time -->
	
<!-- Start Populate Slot -->
<!-- End Populate Slot -->
    
    
    </div>
    </div>
    <!-- End Diary Column -->
    <!-- Start Diary Column -->
    <div class="DiaryColumnContainer ContextOn 40 EmptySlots" style="cursor:pointer;" data-apptid="" data-time="14:10" data-staffid="14" data-staffname="Emile  Cloete" data-status="" data-key="40" data-clientid="" data-clientname="" data-newclient="" data-extended="" data-primaryid="" data-invoiced="" data-caseid="" data-type="">
    
    <div class="DiaryColumnSchedule" >

<!-- Start Lunch Time -->
<!-- End Lunch Time -->
	
<!-- Start Populate Slot -->
<!-- End Populate Slot -->
    
    
    </div>
    </div>
    <!-- End Diary Column -->
    <!-- Start Diary Column -->
    <div class="DiaryColumnContainer ContextOn 40 EmptySlots" style="cursor:pointer;" data-apptid="" data-time="14:10" data-staffid="1" data-staffname="Darren  Rieck" data-status="" data-key="40" data-clientid="" data-clientname="" data-newclient="" data-extended="" data-primaryid="" data-invoiced="" data-caseid="" data-type="">
    
    <div class="DiaryColumn" >

<!-- Start Lunch Time -->
<!-- End Lunch Time -->
	
<!-- Start Populate Slot -->
<!-- End Populate Slot -->
    
    
    </div>
    </div>
    <!-- End Diary Column -->
    <!-- Start Diary Column -->
    <div class="DiaryColumnContainer ContextOn 40 EmptySlots" style="cursor:pointer;" data-apptid="" data-time="14:10" data-staffid="6" data-staffname="Karen  Kitchener" data-status="" data-key="40" data-clientid="" data-clientname="" data-newclient="" data-extended="" data-primaryid="" data-invoiced="" data-caseid="" data-type="">
    
    <div class="DiaryColumn" >

<!-- Start Lunch Time -->
<!-- End Lunch Time -->
	
<!-- Start Populate Slot -->
<!-- End Populate Slot -->
    
    
    </div>
    </div>
    <!-- End Diary Column -->
    <!-- Start Diary Column -->
    <div class="DiaryColumnContainer ContextOn 41 EmptySlots" style="cursor:pointer;" data-apptid="" data-time="14:20" data-staffid="26" data-staffname="Bec Webberley" data-status="" data-key="41" data-clientid="" data-clientname="" data-newclient="" data-extended="" data-primaryid="" data-invoiced="" data-caseid="" data-type="">
    
    <div class="DiaryColumn" >

<!-- Start Lunch Time -->
<!-- End Lunch Time -->
	
<!-- Start Populate Slot -->
<!-- End Populate Slot -->
    
    
    </div>
    </div>
    <!-- End Diary Column -->
    <!-- Start Diary Column -->
    <div class="DiaryColumnContainer ContextOff 41 " style="cursor:not-allowed;" data-apptid="32105" data-time="14:20" data-staffid="7" data-staffname="Tamara Shaw" data-status="StdAppt" data-key="41" data-clientid="1402" data-clientname="Liban Salad" data-newclient="0" data-extended="0" data-primaryid="32103" data-invoiced="" data-caseid="" data-type="Services">
    
    <div class="DiaryColumnSchedule" style="color:#003399; background-color:#D1D6D6;">

<!-- Start Lunch Time -->
<!-- End Lunch Time -->
	
<!-- Start Populate Slot -->
<!-- End Populate Slot -->
    
    
    </div>
    </div>
    <!-- End Diary Column -->
    <!-- Start Diary Column -->
    <div class="DiaryColumnContainer ContextOff 41 " style="cursor:not-allowed;" data-apptid="32760" data-time="14:20" data-staffid="16" data-staffname="Olivia  Moy" data-status="StdAppt" data-key="41" data-clientid="1304" data-clientname="Peta Austyn" data-newclient="0" data-extended="0" data-primaryid="32757" data-invoiced="" data-caseid="" data-type="Services">
    
    <div class="DiaryColumnSchedule" style="color:#003399; background-color:#D1D6D6;">

<!-- Start Lunch Time -->
<!-- End Lunch Time -->
	
<!-- Start Populate Slot -->
<!-- End Populate Slot -->
    
    
    </div>
    </div>
    <!-- End Diary Column -->
    <!-- Start Diary Column -->
    <div class="DiaryColumnContainer ContextOn 41 EmptySlots" style="cursor:pointer;" data-apptid="" data-time="14:20" data-staffid="18" data-staffname="Andrew  Rashleigh" data-status="" data-key="41" data-clientid="" data-clientname="" data-newclient="" data-extended="" data-primaryid="" data-invoiced="" data-caseid="" data-type="">
    
    <div class="DiaryColumn" >

<!-- Start Lunch Time -->
<!-- End Lunch Time -->
	
<!-- Start Populate Slot -->
<!-- End Populate Slot -->
    
    
    </div>
    </div>
    <!-- End Diary Column -->
    <!-- Start Diary Column -->
    <div class="DiaryColumnContainer ContextOn 41 EmptySlots" style="cursor:pointer;" data-apptid="" data-time="14:20" data-staffid="14" data-staffname="Emile  Cloete" data-status="" data-key="41" data-clientid="" data-clientname="" data-newclient="" data-extended="" data-primaryid="" data-invoiced="" data-caseid="" data-type="">
    
    <div class="DiaryColumnSchedule" >

<!-- Start Lunch Time -->
<!-- End Lunch Time -->
	
<!-- Start Populate Slot -->
<!-- End Populate Slot -->
    
    
    </div>
    </div>
    <!-- End Diary Column -->
    <!-- Start Diary Column -->
    <div class="DiaryColumnContainer ContextOn 41 EmptySlots" style="cursor:pointer;" data-apptid="" data-time="14:20" data-staffid="1" data-staffname="Darren  Rieck" data-status="" data-key="41" data-clientid="" data-clientname="" data-newclient="" data-extended="" data-primaryid="" data-invoiced="" data-caseid="" data-type="">
    
    <div class="DiaryColumn" >

<!-- Start Lunch Time -->
<!-- End Lunch Time -->
	
<!-- Start Populate Slot -->
<!-- End Populate Slot -->
    
    
    </div>
    </div>
    <!-- End Diary Column -->
    <!-- Start Diary Column -->
    <div class="DiaryColumnContainer ContextOn 41 EmptySlots" style="cursor:pointer;" data-apptid="" data-time="14:20" data-staffid="6" data-staffname="Karen  Kitchener" data-status="" data-key="41" data-clientid="" data-clientname="" data-newclient="" data-extended="" data-primaryid="" data-invoiced="" data-caseid="" data-type="">
    
    <div class="DiaryColumn" >

<!-- Start Lunch Time -->
<!-- End Lunch Time -->
	
<!-- Start Populate Slot -->
<!-- End Populate Slot -->
    
    
    </div>
    </div>
    <!-- End Diary Column -->
    <!-- Start Diary Column -->
    <div class="DiaryColumnContainer ContextOn 42 EmptySlots" style="cursor:pointer;" data-apptid="" data-time="14:30" data-staffid="26" data-staffname="Bec Webberley" data-status="" data-key="42" data-clientid="" data-clientname="" data-newclient="" data-extended="" data-primaryid="" data-invoiced="" data-caseid="" data-type="">
    
    <div class="DiaryColumn" >

<!-- Start Lunch Time -->
<!-- End Lunch Time -->
	
<!-- Start Populate Slot -->
<!-- End Populate Slot -->
    
    
    </div>
    </div>
    <!-- End Diary Column -->
    <!-- Start Diary Column -->
    <div class="DiaryColumnContainer ContextOn 42 FilledSlots" style="cursor:pointer;" data-apptid="32305" data-time="14:30" data-staffid="7" data-staffname="Tamara Shaw" data-status="StdAppt" data-key="42" data-clientid="1430" data-clientname="Jamie-Marree Mulder" data-newclient="0" data-extended="1" data-primaryid="0" data-invoiced="" data-caseid="2764" data-type="Services">
    
    <div class="DiaryColumnSchedule" style="color:#003399; background-color:#D1D6D6;">

<!-- Start Lunch Time -->
<!-- End Lunch Time -->
	
<!-- Start Populate Slot -->
    <div class="ClientType SlotContent" style="float:left; width:15px; background-color:#006; color:#FFF; margin-left:2px; margin-top:2px;">P</div>
    

    <div class="Patient SlotContent DiaryToolTip" 
    title="<span>Provider : Tamara Shaw<hr />Date : 19/07/2012 - Time : 14:30</span><hr />Jamie-Marree Mulder<br /><br />Contact No : 0411 779 133<hr /><span>not yet approved by W/C 17/7
S12AW982239</span><hr />Private -  Physio Std<hr /><span>Pay privately as no w/c details yet</span><hr />Case : W/C Back<hr />" 
    style="float:left; margin:2px 0px 0px 5px; font-weight:bold; font-size:11px; ">
	Jamie-Marree M     
    </div>

<img src="/images/icons/icon_warning.png" class="DiaryToolTip" style="float:right; margin-right:2px;" title="Appt Notes<hr /><span>Pay privately as no w/c details yet</span><hr />"; /><!-- End Populate Slot -->
    
    
    </div>
    </div>
    <!-- End Diary Column -->
    <!-- Start Diary Column -->
    <div class="DiaryColumnContainer ContextOff 42 " style="cursor:not-allowed;" data-apptid="32761" data-time="14:30" data-staffid="16" data-staffname="Olivia  Moy" data-status="StdAppt" data-key="42" data-clientid="1304" data-clientname="Peta Austyn" data-newclient="0" data-extended="0" data-primaryid="32757" data-invoiced="" data-caseid="" data-type="Services">
    
    <div class="DiaryColumnSchedule" style="color:#003399; background-color:#D1D6D6;">

<!-- Start Lunch Time -->
<!-- End Lunch Time -->
	
<!-- Start Populate Slot -->
<!-- End Populate Slot -->
    
    
    </div>
    </div>
    <!-- End Diary Column -->
    <!-- Start Diary Column -->
    <div class="DiaryColumnContainer ContextOn 42 EmptySlots" style="cursor:pointer;" data-apptid="" data-time="14:30" data-staffid="18" data-staffname="Andrew  Rashleigh" data-status="" data-key="42" data-clientid="" data-clientname="" data-newclient="" data-extended="" data-primaryid="" data-invoiced="" data-caseid="" data-type="">
    
    <div class="DiaryColumn" >

<!-- Start Lunch Time -->
<!-- End Lunch Time -->
	
<!-- Start Populate Slot -->
<!-- End Populate Slot -->
    
    
    </div>
    </div>
    <!-- End Diary Column -->
    <!-- Start Diary Column -->
    <div class="DiaryColumnContainer ContextOn 42 EmptySlots" style="cursor:pointer;" data-apptid="" data-time="14:30" data-staffid="14" data-staffname="Emile  Cloete" data-status="" data-key="42" data-clientid="" data-clientname="" data-newclient="" data-extended="" data-primaryid="" data-invoiced="" data-caseid="" data-type="">
    
    <div class="DiaryColumnSchedule" >

<!-- Start Lunch Time -->
<!-- End Lunch Time -->
	
<!-- Start Populate Slot -->
<!-- End Populate Slot -->
    
    
    </div>
    </div>
    <!-- End Diary Column -->
    <!-- Start Diary Column -->
    <div class="DiaryColumnContainer ContextOn 42 EmptySlots" style="cursor:pointer;" data-apptid="" data-time="14:30" data-staffid="1" data-staffname="Darren  Rieck" data-status="" data-key="42" data-clientid="" data-clientname="" data-newclient="" data-extended="" data-primaryid="" data-invoiced="" data-caseid="" data-type="">
    
    <div class="DiaryColumn" >

<!-- Start Lunch Time -->
<!-- End Lunch Time -->
	
<!-- Start Populate Slot -->
<!-- End Populate Slot -->
    
    
    </div>
    </div>
    <!-- End Diary Column -->
    <!-- Start Diary Column -->
    <div class="DiaryColumnContainer ContextOn 42 EmptySlots" style="cursor:pointer;" data-apptid="" data-time="14:30" data-staffid="6" data-staffname="Karen  Kitchener" data-status="" data-key="42" data-clientid="" data-clientname="" data-newclient="" data-extended="" data-primaryid="" data-invoiced="" data-caseid="" data-type="">
    
    <div class="DiaryColumn" >

<!-- Start Lunch Time -->
<!-- End Lunch Time -->
	
<!-- Start Populate Slot -->
<!-- End Populate Slot -->
    
    
    </div>
    </div>
    <!-- End Diary Column -->
    <!-- Start Diary Column -->
    <div class="DiaryColumnContainer ContextOn 43 EmptySlots" style="cursor:pointer;" data-apptid="" data-time="14:40" data-staffid="26" data-staffname="Bec Webberley" data-status="" data-key="43" data-clientid="" data-clientname="" data-newclient="" data-extended="" data-primaryid="" data-invoiced="" data-caseid="" data-type="">
    
    <div class="DiaryColumn" >

<!-- Start Lunch Time -->
<!-- End Lunch Time -->
	
<!-- Start Populate Slot -->
<!-- End Populate Slot -->
    
    
    </div>
    </div>
    <!-- End Diary Column -->
    <!-- Start Diary Column -->
    <div class="DiaryColumnContainer ContextOff 43 " style="cursor:not-allowed;" data-apptid="32306" data-time="14:40" data-staffid="7" data-staffname="Tamara Shaw" data-status="StdAppt" data-key="43" data-clientid="1430" data-clientname="Jamie-Marree Mulder" data-newclient="0" data-extended="0" data-primaryid="32305" data-invoiced="" data-caseid="" data-type="Services">
    
    <div class="DiaryColumnSchedule" style="color:#003399; background-color:#D1D6D6;">

<!-- Start Lunch Time -->
<!-- End Lunch Time -->
	
<!-- Start Populate Slot -->
<!-- End Populate Slot -->
    
    
    </div>
    </div>
    <!-- End Diary Column -->
    <!-- Start Diary Column -->
    <div class="DiaryColumnContainer ContextOff 43 " style="cursor:not-allowed;" data-apptid="32762" data-time="14:40" data-staffid="16" data-staffname="Olivia  Moy" data-status="StdAppt" data-key="43" data-clientid="1304" data-clientname="Peta Austyn" data-newclient="0" data-extended="0" data-primaryid="32757" data-invoiced="" data-caseid="" data-type="Services">
    
    <div class="DiaryColumnSchedule" style="color:#003399; background-color:#D1D6D6;">

<!-- Start Lunch Time -->
<!-- End Lunch Time -->
	
<!-- Start Populate Slot -->
<!-- End Populate Slot -->
    
    
    </div>
    </div>
    <!-- End Diary Column -->
    <!-- Start Diary Column -->
    <div class="DiaryColumnContainer ContextOn 43 EmptySlots" style="cursor:pointer;" data-apptid="" data-time="14:40" data-staffid="18" data-staffname="Andrew  Rashleigh" data-status="" data-key="43" data-clientid="" data-clientname="" data-newclient="" data-extended="" data-primaryid="" data-invoiced="" data-caseid="" data-type="">
    
    <div class="DiaryColumn" >

<!-- Start Lunch Time -->
<!-- End Lunch Time -->
	
<!-- Start Populate Slot -->
<!-- End Populate Slot -->
    
    
    </div>
    </div>
    <!-- End Diary Column -->
    <!-- Start Diary Column -->
    <div class="DiaryColumnContainer ContextOn 43 EmptySlots" style="cursor:pointer;" data-apptid="" data-time="14:40" data-staffid="14" data-staffname="Emile  Cloete" data-status="" data-key="43" data-clientid="" data-clientname="" data-newclient="" data-extended="" data-primaryid="" data-invoiced="" data-caseid="" data-type="">
    
    <div class="DiaryColumnSchedule" >

<!-- Start Lunch Time -->
<!-- End Lunch Time -->
	
<!-- Start Populate Slot -->
<!-- End Populate Slot -->
    
    
    </div>
    </div>
    <!-- End Diary Column -->
    <!-- Start Diary Column -->
    <div class="DiaryColumnContainer ContextOn 43 EmptySlots" style="cursor:pointer;" data-apptid="" data-time="14:40" data-staffid="1" data-staffname="Darren  Rieck" data-status="" data-key="43" data-clientid="" data-clientname="" data-newclient="" data-extended="" data-primaryid="" data-invoiced="" data-caseid="" data-type="">
    
    <div class="DiaryColumn" >

<!-- Start Lunch Time -->
<!-- End Lunch Time -->
	
<!-- Start Populate Slot -->
<!-- End Populate Slot -->
    
    
    </div>
    </div>
    <!-- End Diary Column -->
    <!-- Start Diary Column -->
    <div class="DiaryColumnContainer ContextOn 43 EmptySlots" style="cursor:pointer;" data-apptid="" data-time="14:40" data-staffid="6" data-staffname="Karen  Kitchener" data-status="" data-key="43" data-clientid="" data-clientname="" data-newclient="" data-extended="" data-primaryid="" data-invoiced="" data-caseid="" data-type="">
    
    <div class="DiaryColumn" >

<!-- Start Lunch Time -->
<!-- End Lunch Time -->
	
<!-- Start Populate Slot -->
<!-- End Populate Slot -->
    
    
    </div>
    </div>
    <!-- End Diary Column -->
    <!-- Start Diary Column -->
    <div class="DiaryColumnContainer ContextOn 44 EmptySlots" style="cursor:pointer;" data-apptid="" data-time="14:50" data-staffid="26" data-staffname="Bec Webberley" data-status="" data-key="44" data-clientid="" data-clientname="" data-newclient="" data-extended="" data-primaryid="" data-invoiced="" data-caseid="" data-type="">
    
    <div class="DiaryColumn" >

<!-- Start Lunch Time -->
<!-- End Lunch Time -->
	
<!-- Start Populate Slot -->
<!-- End Populate Slot -->
    
    
    </div>
    </div>
    <!-- End Diary Column -->
    <!-- Start Diary Column -->
    <div class="DiaryColumnContainer ContextOff 44 " style="cursor:not-allowed;" data-apptid="32307" data-time="14:50" data-staffid="7" data-staffname="Tamara Shaw" data-status="StdAppt" data-key="44" data-clientid="1430" data-clientname="Jamie-Marree Mulder" data-newclient="0" data-extended="0" data-primaryid="32305" data-invoiced="" data-caseid="" data-type="Services">
    
    <div class="DiaryColumnSchedule" style="color:#003399; background-color:#D1D6D6;">

<!-- Start Lunch Time -->
<!-- End Lunch Time -->
	
<!-- Start Populate Slot -->
<!-- End Populate Slot -->
    
    
    </div>
    </div>
    <!-- End Diary Column -->
    <!-- Start Diary Column -->
    <div class="DiaryColumnContainer ContextOff 44 " style="cursor:not-allowed;" data-apptid="32763" data-time="14:50" data-staffid="16" data-staffname="Olivia  Moy" data-status="StdAppt" data-key="44" data-clientid="1304" data-clientname="Peta Austyn" data-newclient="0" data-extended="0" data-primaryid="32757" data-invoiced="" data-caseid="" data-type="Services">
    
    <div class="DiaryColumnSchedule" style="color:#003399; background-color:#D1D6D6;">

<!-- Start Lunch Time -->
<!-- End Lunch Time -->
	
<!-- Start Populate Slot -->
<!-- End Populate Slot -->
    
    
    </div>
    </div>
    <!-- End Diary Column -->
    <!-- Start Diary Column -->
    <div class="DiaryColumnContainer ContextOn 44 EmptySlots" style="cursor:pointer;" data-apptid="" data-time="14:50" data-staffid="18" data-staffname="Andrew  Rashleigh" data-status="" data-key="44" data-clientid="" data-clientname="" data-newclient="" data-extended="" data-primaryid="" data-invoiced="" data-caseid="" data-type="">
    
    <div class="DiaryColumn" >

<!-- Start Lunch Time -->
<!-- End Lunch Time -->
	
<!-- Start Populate Slot -->
<!-- End Populate Slot -->
    
    
    </div>
    </div>
    <!-- End Diary Column -->
    <!-- Start Diary Column -->
    <div class="DiaryColumnContainer ContextOn 44 EmptySlots" style="cursor:pointer;" data-apptid="" data-time="14:50" data-staffid="14" data-staffname="Emile  Cloete" data-status="" data-key="44" data-clientid="" data-clientname="" data-newclient="" data-extended="" data-primaryid="" data-invoiced="" data-caseid="" data-type="">
    
    <div class="DiaryColumnSchedule" >

<!-- Start Lunch Time -->
<!-- End Lunch Time -->
	
<!-- Start Populate Slot -->
<!-- End Populate Slot -->
    
    
    </div>
    </div>
    <!-- End Diary Column -->
    <!-- Start Diary Column -->
    <div class="DiaryColumnContainer ContextOn 44 EmptySlots" style="cursor:pointer;" data-apptid="" data-time="14:50" data-staffid="1" data-staffname="Darren  Rieck" data-status="" data-key="44" data-clientid="" data-clientname="" data-newclient="" data-extended="" data-primaryid="" data-invoiced="" data-caseid="" data-type="">
    
    <div class="DiaryColumn" >

<!-- Start Lunch Time -->
<!-- End Lunch Time -->
	
<!-- Start Populate Slot -->
<!-- End Populate Slot -->
    
    
    </div>
    </div>
    <!-- End Diary Column -->
    <!-- Start Diary Column -->
    <div class="DiaryColumnContainer ContextOn 44 EmptySlots" style="cursor:pointer;" data-apptid="" data-time="14:50" data-staffid="6" data-staffname="Karen  Kitchener" data-status="" data-key="44" data-clientid="" data-clientname="" data-newclient="" data-extended="" data-primaryid="" data-invoiced="" data-caseid="" data-type="">
    
    <div class="DiaryColumn" >

<!-- Start Lunch Time -->
<!-- End Lunch Time -->
	
<!-- Start Populate Slot -->
<!-- End Populate Slot -->
    
    
    </div>
    </div>
    <!-- End Diary Column -->
    <!-- Start Diary Column -->
    <div class="DiaryColumnContainer ContextOn 45 EmptySlots" style="cursor:pointer;" data-apptid="" data-time="15:00" data-staffid="26" data-staffname="Bec Webberley" data-status="" data-key="45" data-clientid="" data-clientname="" data-newclient="" data-extended="" data-primaryid="" data-invoiced="" data-caseid="" data-type="">
    
    <div class="DiaryColumn" >

<!-- Start Lunch Time -->
<!-- End Lunch Time -->
	
<!-- Start Populate Slot -->
<!-- End Populate Slot -->
    
    
    </div>
    </div>
    <!-- End Diary Column -->
    <!-- Start Diary Column -->
    <div class="DiaryColumnContainer ContextOn 45 FilledSlots" style="cursor:pointer;" data-apptid="32353" data-time="15:00" data-staffid="7" data-staffname="Tamara Shaw" data-status="StdAppt" data-key="45" data-clientid="1001" data-clientname="Annette Kennedy" data-newclient="0" data-extended="1" data-primaryid="0" data-invoiced="" data-caseid="2186" data-type="Services">
    
    <div class="DiaryColumnSchedule" style="color:#003399; background-color:#D1D6D6;">

<!-- Start Lunch Time -->
<!-- End Lunch Time -->
	
<!-- Start Populate Slot -->
    <div class="ClientType SlotContent" style="float:left; width:15px; background-color:#006; color:#FFF; margin-left:2px; margin-top:2px;">P</div>
    

    <div class="Patient SlotContent DiaryToolTip" 
    title="<span>Provider : Tamara Shaw<hr />Date : 19/07/2012 - Time : 15:00</span><hr />Annette Kennedy<br /><br />Contact No : 0411304993<hr />Private -  Physio Std<hr />Case : Pvt - Neck<hr />" 
    style="float:left; margin:2px 0px 0px 5px; font-weight:bold; font-size:11px; ">
	Annette Kennedy    
    </div>

<!-- End Populate Slot -->
    
    
    </div>
    </div>
    <!-- End Diary Column -->
    <!-- Start Diary Column -->
    <div class="DiaryColumnContainer ContextOn 45 EmptySlots" style="cursor:pointer;" data-apptid="" data-time="15:00" data-staffid="16" data-staffname="Olivia  Moy" data-status="" data-key="45" data-clientid="" data-clientname="" data-newclient="" data-extended="" data-primaryid="" data-invoiced="" data-caseid="" data-type="">
    
    <div class="DiaryColumnSchedule" >

<!-- Start Lunch Time -->
<!-- End Lunch Time -->
	
<!-- Start Populate Slot -->
<!-- End Populate Slot -->
    
    
    </div>
    </div>
    <!-- End Diary Column -->
    <!-- Start Diary Column -->
    <div class="DiaryColumnContainer ContextOn 45 EmptySlots" style="cursor:pointer;" data-apptid="" data-time="15:00" data-staffid="18" data-staffname="Andrew  Rashleigh" data-status="" data-key="45" data-clientid="" data-clientname="" data-newclient="" data-extended="" data-primaryid="" data-invoiced="" data-caseid="" data-type="">
    
    <div class="DiaryColumn" >

<!-- Start Lunch Time -->
<!-- End Lunch Time -->
	
<!-- Start Populate Slot -->
<!-- End Populate Slot -->
    
    
    </div>
    </div>
    <!-- End Diary Column -->
    <!-- Start Diary Column -->
    <div class="DiaryColumnContainer ContextOn 45 EmptySlots" style="cursor:pointer;" data-apptid="" data-time="15:00" data-staffid="14" data-staffname="Emile  Cloete" data-status="" data-key="45" data-clientid="" data-clientname="" data-newclient="" data-extended="" data-primaryid="" data-invoiced="" data-caseid="" data-type="">
    
    <div class="DiaryColumnSchedule" >

<!-- Start Lunch Time -->
<!-- End Lunch Time -->
	
<!-- Start Populate Slot -->
<!-- End Populate Slot -->
    
    
    </div>
    </div>
    <!-- End Diary Column -->
    <!-- Start Diary Column -->
    <div class="DiaryColumnContainer ContextOn 45 EmptySlots" style="cursor:pointer;" data-apptid="" data-time="15:00" data-staffid="1" data-staffname="Darren  Rieck" data-status="" data-key="45" data-clientid="" data-clientname="" data-newclient="" data-extended="" data-primaryid="" data-invoiced="" data-caseid="" data-type="">
    
    <div class="DiaryColumn" >

<!-- Start Lunch Time -->
<!-- End Lunch Time -->
	
<!-- Start Populate Slot -->
<!-- End Populate Slot -->
    
    
    </div>
    </div>
    <!-- End Diary Column -->
    <!-- Start Diary Column -->
    <div class="DiaryColumnContainer ContextOn 45 EmptySlots" style="cursor:pointer;" data-apptid="" data-time="15:00" data-staffid="6" data-staffname="Karen  Kitchener" data-status="" data-key="45" data-clientid="" data-clientname="" data-newclient="" data-extended="" data-primaryid="" data-invoiced="" data-caseid="" data-type="">
    
    <div class="DiaryColumn" >

<!-- Start Lunch Time -->
<!-- End Lunch Time -->
	
<!-- Start Populate Slot -->
<!-- End Populate Slot -->
    
    
    </div>
    </div>
    <!-- End Diary Column -->
    <!-- Start Diary Column -->
    <div class="DiaryColumnContainer ContextOn 46 EmptySlots" style="cursor:pointer;" data-apptid="" data-time="15:10" data-staffid="26" data-staffname="Bec Webberley" data-status="" data-key="46" data-clientid="" data-clientname="" data-newclient="" data-extended="" data-primaryid="" data-invoiced="" data-caseid="" data-type="">
    
    <div class="DiaryColumn" >

<!-- Start Lunch Time -->
<!-- End Lunch Time -->
	
<!-- Start Populate Slot -->
<!-- End Populate Slot -->
    
    
    </div>
    </div>
    <!-- End Diary Column -->
    <!-- Start Diary Column -->
    <div class="DiaryColumnContainer ContextOff 46 " style="cursor:not-allowed;" data-apptid="32354" data-time="15:10" data-staffid="7" data-staffname="Tamara Shaw" data-status="StdAppt" data-key="46" data-clientid="1001" data-clientname="Annette Kennedy" data-newclient="0" data-extended="0" data-primaryid="32353" data-invoiced="" data-caseid="" data-type="Services">
    
    <div class="DiaryColumnSchedule" style="color:#003399; background-color:#D1D6D6;">

<!-- Start Lunch Time -->
<!-- End Lunch Time -->
	
<!-- Start Populate Slot -->
<!-- End Populate Slot -->
    
    
    </div>
    </div>
    <!-- End Diary Column -->
    <!-- Start Diary Column -->
    <div class="DiaryColumnContainer ContextOn 46 EmptySlots" style="cursor:pointer;" data-apptid="" data-time="15:10" data-staffid="16" data-staffname="Olivia  Moy" data-status="" data-key="46" data-clientid="" data-clientname="" data-newclient="" data-extended="" data-primaryid="" data-invoiced="" data-caseid="" data-type="">
    
    <div class="DiaryColumnSchedule" >

<!-- Start Lunch Time -->
<!-- End Lunch Time -->
	
<!-- Start Populate Slot -->
<!-- End Populate Slot -->
    
    
    </div>
    </div>
    <!-- End Diary Column -->
    <!-- Start Diary Column -->
    <div class="DiaryColumnContainer ContextOn 46 EmptySlots" style="cursor:pointer;" data-apptid="" data-time="15:10" data-staffid="18" data-staffname="Andrew  Rashleigh" data-status="" data-key="46" data-clientid="" data-clientname="" data-newclient="" data-extended="" data-primaryid="" data-invoiced="" data-caseid="" data-type="">
    
    <div class="DiaryColumn" >

<!-- Start Lunch Time -->
<!-- End Lunch Time -->
	
<!-- Start Populate Slot -->
<!-- End Populate Slot -->
    
    
    </div>
    </div>
    <!-- End Diary Column -->
    <!-- Start Diary Column -->
    <div class="DiaryColumnContainer ContextOn 46 EmptySlots" style="cursor:pointer;" data-apptid="" data-time="15:10" data-staffid="14" data-staffname="Emile  Cloete" data-status="" data-key="46" data-clientid="" data-clientname="" data-newclient="" data-extended="" data-primaryid="" data-invoiced="" data-caseid="" data-type="">
    
    <div class="DiaryColumnSchedule" >

<!-- Start Lunch Time -->
<!-- End Lunch Time -->
	
<!-- Start Populate Slot -->
<!-- End Populate Slot -->
    
    
    </div>
    </div>
    <!-- End Diary Column -->
    <!-- Start Diary Column -->
    <div class="DiaryColumnContainer ContextOn 46 EmptySlots" style="cursor:pointer;" data-apptid="" data-time="15:10" data-staffid="1" data-staffname="Darren  Rieck" data-status="" data-key="46" data-clientid="" data-clientname="" data-newclient="" data-extended="" data-primaryid="" data-invoiced="" data-caseid="" data-type="">
    
    <div class="DiaryColumn" >

<!-- Start Lunch Time -->
<!-- End Lunch Time -->
	
<!-- Start Populate Slot -->
<!-- End Populate Slot -->
    
    
    </div>
    </div>
    <!-- End Diary Column -->
    <!-- Start Diary Column -->
    <div class="DiaryColumnContainer ContextOn 46 EmptySlots" style="cursor:pointer;" data-apptid="" data-time="15:10" data-staffid="6" data-staffname="Karen  Kitchener" data-status="" data-key="46" data-clientid="" data-clientname="" data-newclient="" data-extended="" data-primaryid="" data-invoiced="" data-caseid="" data-type="">
    
    <div class="DiaryColumn" >

<!-- Start Lunch Time -->
<!-- End Lunch Time -->
	
<!-- Start Populate Slot -->
<!-- End Populate Slot -->
    
    
    </div>
    </div>
    <!-- End Diary Column -->
    <!-- Start Diary Column -->
    <div class="DiaryColumnContainer ContextOn 47 EmptySlots" style="cursor:pointer;" data-apptid="" data-time="15:20" data-staffid="26" data-staffname="Bec Webberley" data-status="" data-key="47" data-clientid="" data-clientname="" data-newclient="" data-extended="" data-primaryid="" data-invoiced="" data-caseid="" data-type="">
    
    <div class="DiaryColumn" >

<!-- Start Lunch Time -->
<!-- End Lunch Time -->
	
<!-- Start Populate Slot -->
<!-- End Populate Slot -->
    
    
    </div>
    </div>
    <!-- End Diary Column -->
    <!-- Start Diary Column -->
    <div class="DiaryColumnContainer ContextOff 47 " style="cursor:not-allowed;" data-apptid="32355" data-time="15:20" data-staffid="7" data-staffname="Tamara Shaw" data-status="StdAppt" data-key="47" data-clientid="1001" data-clientname="Annette Kennedy" data-newclient="0" data-extended="0" data-primaryid="32353" data-invoiced="" data-caseid="" data-type="Services">
    
    <div class="DiaryColumnSchedule" style="color:#003399; background-color:#D1D6D6;">

<!-- Start Lunch Time -->
<!-- End Lunch Time -->
	
<!-- Start Populate Slot -->
<!-- End Populate Slot -->
    
    
    </div>
    </div>
    <!-- End Diary Column -->
    <!-- Start Diary Column -->
    <div class="DiaryColumnContainer ContextOn 47 EmptySlots" style="cursor:pointer;" data-apptid="" data-time="15:20" data-staffid="16" data-staffname="Olivia  Moy" data-status="" data-key="47" data-clientid="" data-clientname="" data-newclient="" data-extended="" data-primaryid="" data-invoiced="" data-caseid="" data-type="">
    
    <div class="DiaryColumnSchedule" >

<!-- Start Lunch Time -->
<!-- End Lunch Time -->
	
<!-- Start Populate Slot -->
<!-- End Populate Slot -->
    
    
    </div>
    </div>
    <!-- End Diary Column -->
    <!-- Start Diary Column -->
    <div class="DiaryColumnContainer ContextOn 47 EmptySlots" style="cursor:pointer;" data-apptid="" data-time="15:20" data-staffid="18" data-staffname="Andrew  Rashleigh" data-status="" data-key="47" data-clientid="" data-clientname="" data-newclient="" data-extended="" data-primaryid="" data-invoiced="" data-caseid="" data-type="">
    
    <div class="DiaryColumn" >

<!-- Start Lunch Time -->
<!-- End Lunch Time -->
	
<!-- Start Populate Slot -->
<!-- End Populate Slot -->
    
    
    </div>
    </div>
    <!-- End Diary Column -->
    <!-- Start Diary Column -->
    <div class="DiaryColumnContainer ContextOn 47 EmptySlots" style="cursor:pointer;" data-apptid="" data-time="15:20" data-staffid="14" data-staffname="Emile  Cloete" data-status="" data-key="47" data-clientid="" data-clientname="" data-newclient="" data-extended="" data-primaryid="" data-invoiced="" data-caseid="" data-type="">
    
    <div class="DiaryColumnSchedule" >

<!-- Start Lunch Time -->
<!-- End Lunch Time -->
	
<!-- Start Populate Slot -->
<!-- End Populate Slot -->
    
    
    </div>
    </div>
    <!-- End Diary Column -->
    <!-- Start Diary Column -->
    <div class="DiaryColumnContainer ContextOn 47 EmptySlots" style="cursor:pointer;" data-apptid="" data-time="15:20" data-staffid="1" data-staffname="Darren  Rieck" data-status="" data-key="47" data-clientid="" data-clientname="" data-newclient="" data-extended="" data-primaryid="" data-invoiced="" data-caseid="" data-type="">
    
    <div class="DiaryColumn" >

<!-- Start Lunch Time -->
<!-- End Lunch Time -->
	
<!-- Start Populate Slot -->
<!-- End Populate Slot -->
    
    
    </div>
    </div>
    <!-- End Diary Column -->
    <!-- Start Diary Column -->
    <div class="DiaryColumnContainer ContextOn 47 EmptySlots" style="cursor:pointer;" data-apptid="" data-time="15:20" data-staffid="6" data-staffname="Karen  Kitchener" data-status="" data-key="47" data-clientid="" data-clientname="" data-newclient="" data-extended="" data-primaryid="" data-invoiced="" data-caseid="" data-type="">
    
    <div class="DiaryColumn" >

<!-- Start Lunch Time -->
<!-- End Lunch Time -->
	
<!-- Start Populate Slot -->
<!-- End Populate Slot -->
    
    
    </div>
    </div>
    <!-- End Diary Column -->
    <!-- Start Diary Column -->
    <div class="DiaryColumnContainer ContextOn 48 EmptySlots" style="cursor:pointer;" data-apptid="" data-time="15:30" data-staffid="26" data-staffname="Bec Webberley" data-status="" data-key="48" data-clientid="" data-clientname="" data-newclient="" data-extended="" data-primaryid="" data-invoiced="" data-caseid="" data-type="">
    
    <div class="DiaryColumn" >

<!-- Start Lunch Time -->
<!-- End Lunch Time -->
	
<!-- Start Populate Slot -->
<!-- End Populate Slot -->
    
    
    </div>
    </div>
    <!-- End Diary Column -->
    <!-- Start Diary Column -->
    <div class="DiaryColumnContainer ContextOn 48 FilledSlots" style="cursor:pointer;" data-apptid="32792" data-time="15:30" data-staffid="7" data-staffname="Tamara Shaw" data-status="StdAppt" data-key="48" data-clientid="437" data-clientname="Freya Bricknell" data-newclient="0" data-extended="1" data-primaryid="0" data-invoiced="" data-caseid="982" data-type="Services">
    
    <div class="DiaryColumnSchedule" style="color:#003399; background-color:#D1D6D6;">

<!-- Start Lunch Time -->
<!-- End Lunch Time -->
	
<!-- Start Populate Slot -->
    <div class="ClientType SlotContent" style="float:left; width:15px; background-color:#006; color:#FFF; margin-left:2px; margin-top:2px;">P</div>
    

    <div class="Patient SlotContent DiaryToolTip" 
    title="<span>Provider : Tamara Shaw<hr />Date : 19/07/2012 - Time : 15:30</span><hr />Freya Bricknell<br /><br />Contact No : 0402167984<hr /><span>0403338733 - Nathan</span><hr />Private -  Physio Initial<hr /><span>New case - initial?</span><hr />Case : PVT<hr />" 
    style="float:left; margin:2px 0px 0px 5px; font-weight:bold; font-size:11px; ">
	Freya Bricknell    
    </div>

<img src="/images/icons/icon_warning.png" class="DiaryToolTip" style="float:right; margin-right:2px;" title="Appt Notes<hr /><span>New case - initial?</span><hr />"; /><!-- End Populate Slot -->
    
    
    </div>
    </div>
    <!-- End Diary Column -->
    <!-- Start Diary Column -->
    <div class="DiaryColumnContainer ContextOn 48 FilledSlots" style="cursor:pointer;" data-apptid="31185" data-time="15:30" data-staffid="16" data-staffname="Olivia  Moy" data-status="StdAppt" data-key="48" data-clientid="574" data-clientname="Aj Sipple" data-newclient="0" data-extended="1" data-primaryid="0" data-invoiced="" data-caseid="2713" data-type="Services">
    
    <div class="DiaryColumnSchedule" style="color:#003399; background-color:#D1D6D6;">

<!-- Start Lunch Time -->
<!-- End Lunch Time -->
	
<!-- Start Populate Slot -->
    <div class="ClientType SlotContent" style="float:left; width:15px; background-color:#006; color:#FFF; margin-left:2px; margin-top:2px;">P</div>
    

    <div class="Patient SlotContent DiaryToolTip" 
    title="<span>Provider : Olivia  Moy<hr />Date : 19/07/2012 - Time : 15:30</span><hr />Aj Sipple<br /><br />Contact No : 0422850585<hr /><span>10% discount AFL</span><hr />Remedial Massage 1 Hr<hr />Case : Massage<hr />" 
    style="float:left; margin:2px 0px 0px 5px; font-weight:bold; font-size:11px; ">
	Aj Sipple    
    </div>

<!-- End Populate Slot -->
    
    
    </div>
    </div>
    <!-- End Diary Column -->
    <!-- Start Diary Column -->
    <div class="DiaryColumnContainer ContextOn 48 EmptySlots" style="cursor:pointer;" data-apptid="" data-time="15:30" data-staffid="18" data-staffname="Andrew  Rashleigh" data-status="" data-key="48" data-clientid="" data-clientname="" data-newclient="" data-extended="" data-primaryid="" data-invoiced="" data-caseid="" data-type="">
    
    <div class="DiaryColumn" >

<!-- Start Lunch Time -->
<!-- End Lunch Time -->
	
<!-- Start Populate Slot -->
<!-- End Populate Slot -->
    
    
    </div>
    </div>
    <!-- End Diary Column -->
    <!-- Start Diary Column -->
    <div class="DiaryColumnContainer ContextOn 48 EmptySlots" style="cursor:pointer;" data-apptid="" data-time="15:30" data-staffid="14" data-staffname="Emile  Cloete" data-status="" data-key="48" data-clientid="" data-clientname="" data-newclient="" data-extended="" data-primaryid="" data-invoiced="" data-caseid="" data-type="">
    
    <div class="DiaryColumnSchedule" >

<!-- Start Lunch Time -->
<!-- End Lunch Time -->
	
<!-- Start Populate Slot -->
<!-- End Populate Slot -->
    
    
    </div>
    </div>
    <!-- End Diary Column -->
    <!-- Start Diary Column -->
    <div class="DiaryColumnContainer ContextOn 48 EmptySlots" style="cursor:pointer;" data-apptid="" data-time="15:30" data-staffid="1" data-staffname="Darren  Rieck" data-status="" data-key="48" data-clientid="" data-clientname="" data-newclient="" data-extended="" data-primaryid="" data-invoiced="" data-caseid="" data-type="">
    
    <div class="DiaryColumn" >

<!-- Start Lunch Time -->
<!-- End Lunch Time -->
	
<!-- Start Populate Slot -->
<!-- End Populate Slot -->
    
    
    </div>
    </div>
    <!-- End Diary Column -->
    <!-- Start Diary Column -->
    <div class="DiaryColumnContainer ContextOn 48 EmptySlots" style="cursor:pointer;" data-apptid="" data-time="15:30" data-staffid="6" data-staffname="Karen  Kitchener" data-status="" data-key="48" data-clientid="" data-clientname="" data-newclient="" data-extended="" data-primaryid="" data-invoiced="" data-caseid="" data-type="">
    
    <div class="DiaryColumn" >

<!-- Start Lunch Time -->
<!-- End Lunch Time -->
	
<!-- Start Populate Slot -->
<!-- End Populate Slot -->
    
    
    </div>
    </div>
    <!-- End Diary Column -->
    <!-- Start Diary Column -->
    <div class="DiaryColumnContainer ContextOn 49 EmptySlots" style="cursor:pointer;" data-apptid="" data-time="15:40" data-staffid="26" data-staffname="Bec Webberley" data-status="" data-key="49" data-clientid="" data-clientname="" data-newclient="" data-extended="" data-primaryid="" data-invoiced="" data-caseid="" data-type="">
    
    <div class="DiaryColumn" >

<!-- Start Lunch Time -->
<!-- End Lunch Time -->
	
<!-- Start Populate Slot -->
<!-- End Populate Slot -->
    
    
    </div>
    </div>
    <!-- End Diary Column -->
    <!-- Start Diary Column -->
    <div class="DiaryColumnContainer ContextOff 49 " style="cursor:not-allowed;" data-apptid="32873" data-time="15:40" data-staffid="7" data-staffname="Tamara Shaw" data-status="StdAppt" data-key="49" data-clientid="437" data-clientname="Freya Bricknell" data-newclient="0" data-extended="0" data-primaryid="32792" data-invoiced="" data-caseid="" data-type="Services">
    
    <div class="DiaryColumnSchedule" style="color:#003399; background-color:#D1D6D6;">

<!-- Start Lunch Time -->
<!-- End Lunch Time -->
	
<!-- Start Populate Slot -->
<!-- End Populate Slot -->
    
    
    </div>
    </div>
    <!-- End Diary Column -->
    <!-- Start Diary Column -->
    <div class="DiaryColumnContainer ContextOff 49 " style="cursor:not-allowed;" data-apptid="32861" data-time="15:40" data-staffid="16" data-staffname="Olivia  Moy" data-status="StdAppt" data-key="49" data-clientid="574" data-clientname="Aj Sipple" data-newclient="0" data-extended="0" data-primaryid="31185" data-invoiced="" data-caseid="" data-type="Services">
    
    <div class="DiaryColumnSchedule" style="color:#003399; background-color:#D1D6D6;">

<!-- Start Lunch Time -->
<!-- End Lunch Time -->
	
<!-- Start Populate Slot -->
<!-- End Populate Slot -->
    
    
    </div>
    </div>
    <!-- End Diary Column -->
    <!-- Start Diary Column -->
    <div class="DiaryColumnContainer ContextOn 49 EmptySlots" style="cursor:pointer;" data-apptid="" data-time="15:40" data-staffid="18" data-staffname="Andrew  Rashleigh" data-status="" data-key="49" data-clientid="" data-clientname="" data-newclient="" data-extended="" data-primaryid="" data-invoiced="" data-caseid="" data-type="">
    
    <div class="DiaryColumn" >

<!-- Start Lunch Time -->
<!-- End Lunch Time -->
	
<!-- Start Populate Slot -->
<!-- End Populate Slot -->
    
    
    </div>
    </div>
    <!-- End Diary Column -->
    <!-- Start Diary Column -->
    <div class="DiaryColumnContainer ContextOn 49 EmptySlots" style="cursor:pointer;" data-apptid="" data-time="15:40" data-staffid="14" data-staffname="Emile  Cloete" data-status="" data-key="49" data-clientid="" data-clientname="" data-newclient="" data-extended="" data-primaryid="" data-invoiced="" data-caseid="" data-type="">
    
    <div class="DiaryColumnSchedule" >

<!-- Start Lunch Time -->
<!-- End Lunch Time -->
	
<!-- Start Populate Slot -->
<!-- End Populate Slot -->
    
    
    </div>
    </div>
    <!-- End Diary Column -->
    <!-- Start Diary Column -->
    <div class="DiaryColumnContainer ContextOn 49 EmptySlots" style="cursor:pointer;" data-apptid="" data-time="15:40" data-staffid="1" data-staffname="Darren  Rieck" data-status="" data-key="49" data-clientid="" data-clientname="" data-newclient="" data-extended="" data-primaryid="" data-invoiced="" data-caseid="" data-type="">
    
    <div class="DiaryColumn" >

<!-- Start Lunch Time -->
<!-- End Lunch Time -->
	
<!-- Start Populate Slot -->
<!-- End Populate Slot -->
    
    
    </div>
    </div>
    <!-- End Diary Column -->
    <!-- Start Diary Column -->
    <div class="DiaryColumnContainer ContextOn 49 EmptySlots" style="cursor:pointer;" data-apptid="" data-time="15:40" data-staffid="6" data-staffname="Karen  Kitchener" data-status="" data-key="49" data-clientid="" data-clientname="" data-newclient="" data-extended="" data-primaryid="" data-invoiced="" data-caseid="" data-type="">
    
    <div class="DiaryColumn" >

<!-- Start Lunch Time -->
<!-- End Lunch Time -->
	
<!-- Start Populate Slot -->
<!-- End Populate Slot -->
    
    
    </div>
    </div>
    <!-- End Diary Column -->
    <!-- Start Diary Column -->
    <div class="DiaryColumnContainer ContextOn 50 EmptySlots" style="cursor:pointer;" data-apptid="" data-time="15:50" data-staffid="26" data-staffname="Bec Webberley" data-status="" data-key="50" data-clientid="" data-clientname="" data-newclient="" data-extended="" data-primaryid="" data-invoiced="" data-caseid="" data-type="">
    
    <div class="DiaryColumn" >

<!-- Start Lunch Time -->
<!-- End Lunch Time -->
	
<!-- Start Populate Slot -->
<!-- End Populate Slot -->
    
    
    </div>
    </div>
    <!-- End Diary Column -->
    <!-- Start Diary Column -->
    <div class="DiaryColumnContainer ContextOn 50 EmptySlots" style="cursor:pointer;" data-apptid="" data-time="15:50" data-staffid="7" data-staffname="Tamara Shaw" data-status="" data-key="50" data-clientid="" data-clientname="" data-newclient="" data-extended="" data-primaryid="" data-invoiced="" data-caseid="" data-type="">
    
    <div class="DiaryColumnSchedule" >

<!-- Start Lunch Time -->
<!-- End Lunch Time -->
	
<!-- Start Populate Slot -->
<!-- End Populate Slot -->
    
    
    </div>
    </div>
    <!-- End Diary Column -->
    <!-- Start Diary Column -->
    <div class="DiaryColumnContainer ContextOff 50 " style="cursor:not-allowed;" data-apptid="32862" data-time="15:50" data-staffid="16" data-staffname="Olivia  Moy" data-status="StdAppt" data-key="50" data-clientid="574" data-clientname="Aj Sipple" data-newclient="0" data-extended="0" data-primaryid="31185" data-invoiced="" data-caseid="" data-type="Services">
    
    <div class="DiaryColumnSchedule" style="color:#003399; background-color:#D1D6D6;">

<!-- Start Lunch Time -->
<!-- End Lunch Time -->
	
<!-- Start Populate Slot -->
<!-- End Populate Slot -->
    
    
    </div>
    </div>
    <!-- End Diary Column -->
    <!-- Start Diary Column -->
    <div class="DiaryColumnContainer ContextOn 50 EmptySlots" style="cursor:pointer;" data-apptid="" data-time="15:50" data-staffid="18" data-staffname="Andrew  Rashleigh" data-status="" data-key="50" data-clientid="" data-clientname="" data-newclient="" data-extended="" data-primaryid="" data-invoiced="" data-caseid="" data-type="">
    
    <div class="DiaryColumn" >

<!-- Start Lunch Time -->
<!-- End Lunch Time -->
	
<!-- Start Populate Slot -->
<!-- End Populate Slot -->
    
    
    </div>
    </div>
    <!-- End Diary Column -->
    <!-- Start Diary Column -->
    <div class="DiaryColumnContainer ContextOn 50 EmptySlots" style="cursor:pointer;" data-apptid="" data-time="15:50" data-staffid="14" data-staffname="Emile  Cloete" data-status="" data-key="50" data-clientid="" data-clientname="" data-newclient="" data-extended="" data-primaryid="" data-invoiced="" data-caseid="" data-type="">
    
    <div class="DiaryColumnSchedule" >

<!-- Start Lunch Time -->
<!-- End Lunch Time -->
	
<!-- Start Populate Slot -->
<!-- End Populate Slot -->
    
    
    </div>
    </div>
    <!-- End Diary Column -->
    <!-- Start Diary Column -->
    <div class="DiaryColumnContainer ContextOn 50 EmptySlots" style="cursor:pointer;" data-apptid="" data-time="15:50" data-staffid="1" data-staffname="Darren  Rieck" data-status="" data-key="50" data-clientid="" data-clientname="" data-newclient="" data-extended="" data-primaryid="" data-invoiced="" data-caseid="" data-type="">
    
    <div class="DiaryColumn" >

<!-- Start Lunch Time -->
<!-- End Lunch Time -->
	
<!-- Start Populate Slot -->
<!-- End Populate Slot -->
    
    
    </div>
    </div>
    <!-- End Diary Column -->
    <!-- Start Diary Column -->
    <div class="DiaryColumnContainer ContextOn 50 EmptySlots" style="cursor:pointer;" data-apptid="" data-time="15:50" data-staffid="6" data-staffname="Karen  Kitchener" data-status="" data-key="50" data-clientid="" data-clientname="" data-newclient="" data-extended="" data-primaryid="" data-invoiced="" data-caseid="" data-type="">
    
    <div class="DiaryColumn" >

<!-- Start Lunch Time -->
<!-- End Lunch Time -->
	
<!-- Start Populate Slot -->
<!-- End Populate Slot -->
    
    
    </div>
    </div>
    <!-- End Diary Column -->
    <!-- Start Diary Column -->
    <div class="DiaryColumnContainer ContextOn 51 EmptySlots" style="cursor:pointer;" data-apptid="" data-time="16:00" data-staffid="26" data-staffname="Bec Webberley" data-status="" data-key="51" data-clientid="" data-clientname="" data-newclient="" data-extended="" data-primaryid="" data-invoiced="" data-caseid="" data-type="">
    
    <div class="DiaryColumn" >

<!-- Start Lunch Time -->
<!-- End Lunch Time -->
	
<!-- Start Populate Slot -->
<!-- End Populate Slot -->
    
    
    </div>
    </div>
    <!-- End Diary Column -->
    <!-- Start Diary Column -->
    <div class="DiaryColumnContainer ContextOn 51 FilledSlots" style="cursor:pointer;" data-apptid="30824" data-time="16:00" data-staffid="7" data-staffname="Tamara Shaw" data-status="StdAppt" data-key="51" data-clientid="563" data-clientname="Amy McKenzie" data-newclient="0" data-extended="1" data-primaryid="0" data-invoiced="" data-caseid="1258" data-type="Services">
    
    <div class="DiaryColumnSchedule" style="color:#003399; background-color:#D1D6D6;">

<!-- Start Lunch Time -->
<!-- End Lunch Time -->
	
<!-- Start Populate Slot -->
    <div class="ClientType SlotContent" style="float:left; width:15px; background-color:#006; color:#FFF; margin-left:2px; margin-top:2px;">P</div>
    

    <div class="Patient SlotContent DiaryToolTip" 
    title="<span>Provider : Tamara Shaw<hr />Date : 19/07/2012 - Time : 16:00</span><hr />Amy McKenzie<br /><br />Contact No : 0402 813 916<hr />Private -  Physio Std<hr />Case : General<hr />" 
    style="float:left; margin:2px 0px 0px 5px; font-weight:bold; font-size:11px; ">
	Amy McKenzie    
    </div>

<!-- End Populate Slot -->
    
    
    </div>
    </div>
    <!-- End Diary Column -->
    <!-- Start Diary Column -->
    <div class="DiaryColumnContainer ContextOff 51 " style="cursor:not-allowed;" data-apptid="32863" data-time="16:00" data-staffid="16" data-staffname="Olivia  Moy" data-status="StdAppt" data-key="51" data-clientid="574" data-clientname="Aj Sipple" data-newclient="0" data-extended="0" data-primaryid="31185" data-invoiced="" data-caseid="" data-type="Services">
    
    <div class="DiaryColumn" style="color:#003399; background-color:#D1D6D6;">

<!-- Start Lunch Time -->
<!-- End Lunch Time -->
	
<!-- Start Populate Slot -->
<!-- End Populate Slot -->
    
    
    </div>
    </div>
    <!-- End Diary Column -->
    <!-- Start Diary Column -->
    <div class="DiaryColumnContainer ContextOn 51 EmptySlots" style="cursor:pointer;" data-apptid="" data-time="16:00" data-staffid="18" data-staffname="Andrew  Rashleigh" data-status="" data-key="51" data-clientid="" data-clientname="" data-newclient="" data-extended="" data-primaryid="" data-invoiced="" data-caseid="" data-type="">
    
    <div class="DiaryColumn" >

<!-- Start Lunch Time -->
<!-- End Lunch Time -->
	
<!-- Start Populate Slot -->
<!-- End Populate Slot -->
    
    
    </div>
    </div>
    <!-- End Diary Column -->
    <!-- Start Diary Column -->
    <div class="DiaryColumnContainer ContextOn 51 EmptySlots" style="cursor:pointer;" data-apptid="" data-time="16:00" data-staffid="14" data-staffname="Emile  Cloete" data-status="" data-key="51" data-clientid="" data-clientname="" data-newclient="" data-extended="" data-primaryid="" data-invoiced="" data-caseid="" data-type="">
    
    <div class="DiaryColumnSchedule" >

<!-- Start Lunch Time -->
<!-- End Lunch Time -->
	
<!-- Start Populate Slot -->
<!-- End Populate Slot -->
    
    
    </div>
    </div>
    <!-- End Diary Column -->
    <!-- Start Diary Column -->
    <div class="DiaryColumnContainer ContextOn 51 EmptySlots" style="cursor:pointer;" data-apptid="" data-time="16:00" data-staffid="1" data-staffname="Darren  Rieck" data-status="" data-key="51" data-clientid="" data-clientname="" data-newclient="" data-extended="" data-primaryid="" data-invoiced="" data-caseid="" data-type="">
    
    <div class="DiaryColumn" >

<!-- Start Lunch Time -->
<!-- End Lunch Time -->
	
<!-- Start Populate Slot -->
<!-- End Populate Slot -->
    
    
    </div>
    </div>
    <!-- End Diary Column -->
    <!-- Start Diary Column -->
    <div class="DiaryColumnContainer ContextOn 51 EmptySlots" style="cursor:pointer;" data-apptid="" data-time="16:00" data-staffid="6" data-staffname="Karen  Kitchener" data-status="" data-key="51" data-clientid="" data-clientname="" data-newclient="" data-extended="" data-primaryid="" data-invoiced="" data-caseid="" data-type="">
    
    <div class="DiaryColumn" >

<!-- Start Lunch Time -->
<!-- End Lunch Time -->
	
<!-- Start Populate Slot -->
<!-- End Populate Slot -->
    
    
    </div>
    </div>
    <!-- End Diary Column -->
    <!-- Start Diary Column -->
    <div class="DiaryColumnContainer ContextOn 52 EmptySlots" style="cursor:pointer;" data-apptid="" data-time="16:10" data-staffid="26" data-staffname="Bec Webberley" data-status="" data-key="52" data-clientid="" data-clientname="" data-newclient="" data-extended="" data-primaryid="" data-invoiced="" data-caseid="" data-type="">
    
    <div class="DiaryColumn" >

<!-- Start Lunch Time -->
<!-- End Lunch Time -->
	
<!-- Start Populate Slot -->
<!-- End Populate Slot -->
    
    
    </div>
    </div>
    <!-- End Diary Column -->
    <!-- Start Diary Column -->
    <div class="DiaryColumnContainer ContextOff 52 " style="cursor:not-allowed;" data-apptid="32874" data-time="16:10" data-staffid="7" data-staffname="Tamara Shaw" data-status="StdAppt" data-key="52" data-clientid="563" data-clientname="Amy McKenzie" data-newclient="0" data-extended="0" data-primaryid="30824" data-invoiced="" data-caseid="" data-type="Services">
    
    <div class="DiaryColumnSchedule" style="color:#003399; background-color:#D1D6D6;">

<!-- Start Lunch Time -->
<!-- End Lunch Time -->
	
<!-- Start Populate Slot -->
<!-- End Populate Slot -->
    
    
    </div>
    </div>
    <!-- End Diary Column -->
    <!-- Start Diary Column -->
    <div class="DiaryColumnContainer ContextOff 52 " style="cursor:not-allowed;" data-apptid="32864" data-time="16:10" data-staffid="16" data-staffname="Olivia  Moy" data-status="StdAppt" data-key="52" data-clientid="574" data-clientname="Aj Sipple" data-newclient="0" data-extended="0" data-primaryid="31185" data-invoiced="" data-caseid="" data-type="Services">
    
    <div class="DiaryColumn" style="color:#003399; background-color:#D1D6D6;">

<!-- Start Lunch Time -->
<!-- End Lunch Time -->
	
<!-- Start Populate Slot -->
<!-- End Populate Slot -->
    
    
    </div>
    </div>
    <!-- End Diary Column -->
    <!-- Start Diary Column -->
    <div class="DiaryColumnContainer ContextOn 52 EmptySlots" style="cursor:pointer;" data-apptid="" data-time="16:10" data-staffid="18" data-staffname="Andrew  Rashleigh" data-status="" data-key="52" data-clientid="" data-clientname="" data-newclient="" data-extended="" data-primaryid="" data-invoiced="" data-caseid="" data-type="">
    
    <div class="DiaryColumn" >

<!-- Start Lunch Time -->
<!-- End Lunch Time -->
	
<!-- Start Populate Slot -->
<!-- End Populate Slot -->
    
    
    </div>
    </div>
    <!-- End Diary Column -->
    <!-- Start Diary Column -->
    <div class="DiaryColumnContainer ContextOn 52 EmptySlots" style="cursor:pointer;" data-apptid="" data-time="16:10" data-staffid="14" data-staffname="Emile  Cloete" data-status="" data-key="52" data-clientid="" data-clientname="" data-newclient="" data-extended="" data-primaryid="" data-invoiced="" data-caseid="" data-type="">
    
    <div class="DiaryColumnSchedule" >

<!-- Start Lunch Time -->
<!-- End Lunch Time -->
	
<!-- Start Populate Slot -->
<!-- End Populate Slot -->
    
    
    </div>
    </div>
    <!-- End Diary Column -->
    <!-- Start Diary Column -->
    <div class="DiaryColumnContainer ContextOn 52 EmptySlots" style="cursor:pointer;" data-apptid="" data-time="16:10" data-staffid="1" data-staffname="Darren  Rieck" data-status="" data-key="52" data-clientid="" data-clientname="" data-newclient="" data-extended="" data-primaryid="" data-invoiced="" data-caseid="" data-type="">
    
    <div class="DiaryColumn" >

<!-- Start Lunch Time -->
<!-- End Lunch Time -->
	
<!-- Start Populate Slot -->
<!-- End Populate Slot -->
    
    
    </div>
    </div>
    <!-- End Diary Column -->
    <!-- Start Diary Column -->
    <div class="DiaryColumnContainer ContextOn 52 EmptySlots" style="cursor:pointer;" data-apptid="" data-time="16:10" data-staffid="6" data-staffname="Karen  Kitchener" data-status="" data-key="52" data-clientid="" data-clientname="" data-newclient="" data-extended="" data-primaryid="" data-invoiced="" data-caseid="" data-type="">
    
    <div class="DiaryColumn" >

<!-- Start Lunch Time -->
<!-- End Lunch Time -->
	
<!-- Start Populate Slot -->
<!-- End Populate Slot -->
    
    
    </div>
    </div>
    <!-- End Diary Column -->
    <!-- Start Diary Column -->
    <div class="DiaryColumnContainer ContextOn 53 EmptySlots" style="cursor:pointer;" data-apptid="" data-time="16:20" data-staffid="26" data-staffname="Bec Webberley" data-status="" data-key="53" data-clientid="" data-clientname="" data-newclient="" data-extended="" data-primaryid="" data-invoiced="" data-caseid="" data-type="">
    
    <div class="DiaryColumn" >

<!-- Start Lunch Time -->
<!-- End Lunch Time -->
	
<!-- Start Populate Slot -->
<!-- End Populate Slot -->
    
    
    </div>
    </div>
    <!-- End Diary Column -->
    <!-- Start Diary Column -->
    <div class="DiaryColumnContainer ContextOff 53 " style="cursor:not-allowed;" data-apptid="32875" data-time="16:20" data-staffid="7" data-staffname="Tamara Shaw" data-status="StdAppt" data-key="53" data-clientid="563" data-clientname="Amy McKenzie" data-newclient="0" data-extended="0" data-primaryid="30824" data-invoiced="" data-caseid="" data-type="Services">
    
    <div class="DiaryColumnSchedule" style="color:#003399; background-color:#D1D6D6;">

<!-- Start Lunch Time -->
<!-- End Lunch Time -->
	
<!-- Start Populate Slot -->
<!-- End Populate Slot -->
    
    
    </div>
    </div>
    <!-- End Diary Column -->
    <!-- Start Diary Column -->
    <div class="DiaryColumnContainer ContextOff 53 " style="cursor:not-allowed;" data-apptid="32865" data-time="16:20" data-staffid="16" data-staffname="Olivia  Moy" data-status="StdAppt" data-key="53" data-clientid="574" data-clientname="Aj Sipple" data-newclient="0" data-extended="0" data-primaryid="31185" data-invoiced="" data-caseid="" data-type="Services">
    
    <div class="DiaryColumn" style="color:#003399; background-color:#D1D6D6;">

<!-- Start Lunch Time -->
<!-- End Lunch Time -->
	
<!-- Start Populate Slot -->
<!-- End Populate Slot -->
    
    
    </div>
    </div>
    <!-- End Diary Column -->
    <!-- Start Diary Column -->
    <div class="DiaryColumnContainer ContextOn 53 EmptySlots" style="cursor:pointer;" data-apptid="" data-time="16:20" data-staffid="18" data-staffname="Andrew  Rashleigh" data-status="" data-key="53" data-clientid="" data-clientname="" data-newclient="" data-extended="" data-primaryid="" data-invoiced="" data-caseid="" data-type="">
    
    <div class="DiaryColumn" >

<!-- Start Lunch Time -->
<!-- End Lunch Time -->
	
<!-- Start Populate Slot -->
<!-- End Populate Slot -->
    
    
    </div>
    </div>
    <!-- End Diary Column -->
    <!-- Start Diary Column -->
    <div class="DiaryColumnContainer ContextOn 53 EmptySlots" style="cursor:pointer;" data-apptid="" data-time="16:20" data-staffid="14" data-staffname="Emile  Cloete" data-status="" data-key="53" data-clientid="" data-clientname="" data-newclient="" data-extended="" data-primaryid="" data-invoiced="" data-caseid="" data-type="">
    
    <div class="DiaryColumnSchedule" >

<!-- Start Lunch Time -->
<!-- End Lunch Time -->
	
<!-- Start Populate Slot -->
<!-- End Populate Slot -->
    
    
    </div>
    </div>
    <!-- End Diary Column -->
    <!-- Start Diary Column -->
    <div class="DiaryColumnContainer ContextOn 53 EmptySlots" style="cursor:pointer;" data-apptid="" data-time="16:20" data-staffid="1" data-staffname="Darren  Rieck" data-status="" data-key="53" data-clientid="" data-clientname="" data-newclient="" data-extended="" data-primaryid="" data-invoiced="" data-caseid="" data-type="">
    
    <div class="DiaryColumn" >

<!-- Start Lunch Time -->
<!-- End Lunch Time -->
	
<!-- Start Populate Slot -->
<!-- End Populate Slot -->
    
    
    </div>
    </div>
    <!-- End Diary Column -->
    <!-- Start Diary Column -->
    <div class="DiaryColumnContainer ContextOn 53 EmptySlots" style="cursor:pointer;" data-apptid="" data-time="16:20" data-staffid="6" data-staffname="Karen  Kitchener" data-status="" data-key="53" data-clientid="" data-clientname="" data-newclient="" data-extended="" data-primaryid="" data-invoiced="" data-caseid="" data-type="">
    
    <div class="DiaryColumn" >

<!-- Start Lunch Time -->
<!-- End Lunch Time -->
	
<!-- Start Populate Slot -->
<!-- End Populate Slot -->
    
    
    </div>
    </div>
    <!-- End Diary Column -->
    <!-- Start Diary Column -->
    <div class="DiaryColumnContainer ContextOn 54 EmptySlots" style="cursor:pointer;" data-apptid="" data-time="16:30" data-staffid="26" data-staffname="Bec Webberley" data-status="" data-key="54" data-clientid="" data-clientname="" data-newclient="" data-extended="" data-primaryid="" data-invoiced="" data-caseid="" data-type="">
    
    <div class="DiaryColumn" >

<!-- Start Lunch Time -->
<!-- End Lunch Time -->
	
<!-- Start Populate Slot -->
<!-- End Populate Slot -->
    
    
    </div>
    </div>
    <!-- End Diary Column -->
    <!-- Start Diary Column -->
    <div class="DiaryColumnContainer ContextOn 54 FilledSlots" style="cursor:pointer;" data-apptid="28963" data-time="16:30" data-staffid="7" data-staffname="Tamara Shaw" data-status="StdAppt" data-key="54" data-clientid="214" data-clientname="Warren Hodson" data-newclient="0" data-extended="1" data-primaryid="0" data-invoiced="" data-caseid="476" data-type="Services">
    
    <div class="DiaryColumnSchedule" style="color:#003399; background-color:#D1D6D6;">

<!-- Start Lunch Time -->
<!-- End Lunch Time -->
	
<!-- Start Populate Slot -->
    <div class="ClientType SlotContent" style="float:left; width:15px; background-color:#006; color:#FFF; margin-left:2px; margin-top:2px;">P</div>
    

    <div class="Patient SlotContent DiaryToolTip" 
    title="<span>Provider : Tamara Shaw<hr />Date : 19/07/2012 - Time : 16:30</span><hr />Warren Hodson<br /><br />Contact No : 0427230173<hr />Private -  Physio Std<hr />Case : PVT<hr />" 
    style="float:left; margin:2px 0px 0px 5px; font-weight:bold; font-size:11px; ">
	Warren Hodson    
    </div>

<!-- End Populate Slot -->
    
    
    </div>
    </div>
    <!-- End Diary Column -->
    <!-- Start Diary Column -->
    <div class="DiaryColumnContainer ContextOn 54 EmptySlots" style="cursor:pointer;" data-apptid="" data-time="16:30" data-staffid="16" data-staffname="Olivia  Moy" data-status="" data-key="54" data-clientid="" data-clientname="" data-newclient="" data-extended="" data-primaryid="" data-invoiced="" data-caseid="" data-type="">
    
    <div class="DiaryColumn" >

<!-- Start Lunch Time -->
<!-- End Lunch Time -->
	
<!-- Start Populate Slot -->
<!-- End Populate Slot -->
    
    
    </div>
    </div>
    <!-- End Diary Column -->
    <!-- Start Diary Column -->
    <div class="DiaryColumnContainer ContextOn 54 EmptySlots" style="cursor:pointer;" data-apptid="" data-time="16:30" data-staffid="18" data-staffname="Andrew  Rashleigh" data-status="" data-key="54" data-clientid="" data-clientname="" data-newclient="" data-extended="" data-primaryid="" data-invoiced="" data-caseid="" data-type="">
    
    <div class="DiaryColumn" >

<!-- Start Lunch Time -->
<!-- End Lunch Time -->
	
<!-- Start Populate Slot -->
<!-- End Populate Slot -->
    
    
    </div>
    </div>
    <!-- End Diary Column -->
    <!-- Start Diary Column -->
    <div class="DiaryColumnContainer ContextOn 54 EmptySlots" style="cursor:pointer;" data-apptid="" data-time="16:30" data-staffid="14" data-staffname="Emile  Cloete" data-status="" data-key="54" data-clientid="" data-clientname="" data-newclient="" data-extended="" data-primaryid="" data-invoiced="" data-caseid="" data-type="">
    
    <div class="DiaryColumnSchedule" >

<!-- Start Lunch Time -->
<!-- End Lunch Time -->
	
<!-- Start Populate Slot -->
<!-- End Populate Slot -->
    
    
    </div>
    </div>
    <!-- End Diary Column -->
    <!-- Start Diary Column -->
    <div class="DiaryColumnContainer ContextOn 54 EmptySlots" style="cursor:pointer;" data-apptid="" data-time="16:30" data-staffid="1" data-staffname="Darren  Rieck" data-status="" data-key="54" data-clientid="" data-clientname="" data-newclient="" data-extended="" data-primaryid="" data-invoiced="" data-caseid="" data-type="">
    
    <div class="DiaryColumn" >

<!-- Start Lunch Time -->
<!-- End Lunch Time -->
	
<!-- Start Populate Slot -->
<!-- End Populate Slot -->
    
    
    </div>
    </div>
    <!-- End Diary Column -->
    <!-- Start Diary Column -->
    <div class="DiaryColumnContainer ContextOn 54 EmptySlots" style="cursor:pointer;" data-apptid="" data-time="16:30" data-staffid="6" data-staffname="Karen  Kitchener" data-status="" data-key="54" data-clientid="" data-clientname="" data-newclient="" data-extended="" data-primaryid="" data-invoiced="" data-caseid="" data-type="">
    
    <div class="DiaryColumn" >

<!-- Start Lunch Time -->
<!-- End Lunch Time -->
	
<!-- Start Populate Slot -->
<!-- End Populate Slot -->
    
    
    </div>
    </div>
    <!-- End Diary Column -->
    <!-- Start Diary Column -->
    <div class="DiaryColumnContainer ContextOn 55 EmptySlots" style="cursor:pointer;" data-apptid="" data-time="16:40" data-staffid="26" data-staffname="Bec Webberley" data-status="" data-key="55" data-clientid="" data-clientname="" data-newclient="" data-extended="" data-primaryid="" data-invoiced="" data-caseid="" data-type="">
    
    <div class="DiaryColumn" >

<!-- Start Lunch Time -->
<!-- End Lunch Time -->
	
<!-- Start Populate Slot -->
<!-- End Populate Slot -->
    
    
    </div>
    </div>
    <!-- End Diary Column -->
    <!-- Start Diary Column -->
    <div class="DiaryColumnContainer ContextOff 55 " style="cursor:not-allowed;" data-apptid="28964" data-time="16:40" data-staffid="7" data-staffname="Tamara Shaw" data-status="StdAppt" data-key="55" data-clientid="214" data-clientname="Warren Hodson" data-newclient="0" data-extended="0" data-primaryid="28963" data-invoiced="" data-caseid="" data-type="Services">
    
    <div class="DiaryColumnSchedule" style="color:#003399; background-color:#D1D6D6;">

<!-- Start Lunch Time -->
<!-- End Lunch Time -->
	
<!-- Start Populate Slot -->
<!-- End Populate Slot -->
    
    
    </div>
    </div>
    <!-- End Diary Column -->
    <!-- Start Diary Column -->
    <div class="DiaryColumnContainer ContextOn 55 EmptySlots" style="cursor:pointer;" data-apptid="" data-time="16:40" data-staffid="16" data-staffname="Olivia  Moy" data-status="" data-key="55" data-clientid="" data-clientname="" data-newclient="" data-extended="" data-primaryid="" data-invoiced="" data-caseid="" data-type="">
    
    <div class="DiaryColumn" >

<!-- Start Lunch Time -->
<!-- End Lunch Time -->
	
<!-- Start Populate Slot -->
<!-- End Populate Slot -->
    
    
    </div>
    </div>
    <!-- End Diary Column -->
    <!-- Start Diary Column -->
    <div class="DiaryColumnContainer ContextOn 55 EmptySlots" style="cursor:pointer;" data-apptid="" data-time="16:40" data-staffid="18" data-staffname="Andrew  Rashleigh" data-status="" data-key="55" data-clientid="" data-clientname="" data-newclient="" data-extended="" data-primaryid="" data-invoiced="" data-caseid="" data-type="">
    
    <div class="DiaryColumn" >

<!-- Start Lunch Time -->
<!-- End Lunch Time -->
	
<!-- Start Populate Slot -->
<!-- End Populate Slot -->
    
    
    </div>
    </div>
    <!-- End Diary Column -->
    <!-- Start Diary Column -->
    <div class="DiaryColumnContainer ContextOn 55 EmptySlots" style="cursor:pointer;" data-apptid="" data-time="16:40" data-staffid="14" data-staffname="Emile  Cloete" data-status="" data-key="55" data-clientid="" data-clientname="" data-newclient="" data-extended="" data-primaryid="" data-invoiced="" data-caseid="" data-type="">
    
    <div class="DiaryColumnSchedule" >

<!-- Start Lunch Time -->
<!-- End Lunch Time -->
	
<!-- Start Populate Slot -->
<!-- End Populate Slot -->
    
    
    </div>
    </div>
    <!-- End Diary Column -->
    <!-- Start Diary Column -->
    <div class="DiaryColumnContainer ContextOn 55 EmptySlots" style="cursor:pointer;" data-apptid="" data-time="16:40" data-staffid="1" data-staffname="Darren  Rieck" data-status="" data-key="55" data-clientid="" data-clientname="" data-newclient="" data-extended="" data-primaryid="" data-invoiced="" data-caseid="" data-type="">
    
    <div class="DiaryColumn" >

<!-- Start Lunch Time -->
<!-- End Lunch Time -->
	
<!-- Start Populate Slot -->
<!-- End Populate Slot -->
    
    
    </div>
    </div>
    <!-- End Diary Column -->
    <!-- Start Diary Column -->
    <div class="DiaryColumnContainer ContextOn 55 EmptySlots" style="cursor:pointer;" data-apptid="" data-time="16:40" data-staffid="6" data-staffname="Karen  Kitchener" data-status="" data-key="55" data-clientid="" data-clientname="" data-newclient="" data-extended="" data-primaryid="" data-invoiced="" data-caseid="" data-type="">
    
    <div class="DiaryColumn" >

<!-- Start Lunch Time -->
<!-- End Lunch Time -->
	
<!-- Start Populate Slot -->
<!-- End Populate Slot -->
    
    
    </div>
    </div>
    <!-- End Diary Column -->
    <!-- Start Diary Column -->
    <div class="DiaryColumnContainer ContextOn 56 EmptySlots" style="cursor:pointer;" data-apptid="" data-time="16:50" data-staffid="26" data-staffname="Bec Webberley" data-status="" data-key="56" data-clientid="" data-clientname="" data-newclient="" data-extended="" data-primaryid="" data-invoiced="" data-caseid="" data-type="">
    
    <div class="DiaryColumn" >

<!-- Start Lunch Time -->
<!-- End Lunch Time -->
	
<!-- Start Populate Slot -->
<!-- End Populate Slot -->
    
    
    </div>
    </div>
    <!-- End Diary Column -->
    <!-- Start Diary Column -->
    <div class="DiaryColumnContainer ContextOff 56 " style="cursor:not-allowed;" data-apptid="28965" data-time="16:50" data-staffid="7" data-staffname="Tamara Shaw" data-status="StdAppt" data-key="56" data-clientid="214" data-clientname="Warren Hodson" data-newclient="0" data-extended="0" data-primaryid="28963" data-invoiced="" data-caseid="" data-type="Services">
    
    <div class="DiaryColumnSchedule" style="color:#003399; background-color:#D1D6D6;">

<!-- Start Lunch Time -->
<!-- End Lunch Time -->
	
<!-- Start Populate Slot -->
<!-- End Populate Slot -->
    
    
    </div>
    </div>
    <!-- End Diary Column -->
    <!-- Start Diary Column -->
    <div class="DiaryColumnContainer ContextOn 56 EmptySlots" style="cursor:pointer;" data-apptid="" data-time="16:50" data-staffid="16" data-staffname="Olivia  Moy" data-status="" data-key="56" data-clientid="" data-clientname="" data-newclient="" data-extended="" data-primaryid="" data-invoiced="" data-caseid="" data-type="">
    
    <div class="DiaryColumn" >

<!-- Start Lunch Time -->
<!-- End Lunch Time -->
	
<!-- Start Populate Slot -->
<!-- End Populate Slot -->
    
    
    </div>
    </div>
    <!-- End Diary Column -->
    <!-- Start Diary Column -->
    <div class="DiaryColumnContainer ContextOn 56 EmptySlots" style="cursor:pointer;" data-apptid="" data-time="16:50" data-staffid="18" data-staffname="Andrew  Rashleigh" data-status="" data-key="56" data-clientid="" data-clientname="" data-newclient="" data-extended="" data-primaryid="" data-invoiced="" data-caseid="" data-type="">
    
    <div class="DiaryColumn" >

<!-- Start Lunch Time -->
<!-- End Lunch Time -->
	
<!-- Start Populate Slot -->
<!-- End Populate Slot -->
    
    
    </div>
    </div>
    <!-- End Diary Column -->
    <!-- Start Diary Column -->
    <div class="DiaryColumnContainer ContextOn 56 EmptySlots" style="cursor:pointer;" data-apptid="" data-time="16:50" data-staffid="14" data-staffname="Emile  Cloete" data-status="" data-key="56" data-clientid="" data-clientname="" data-newclient="" data-extended="" data-primaryid="" data-invoiced="" data-caseid="" data-type="">
    
    <div class="DiaryColumnSchedule" >

<!-- Start Lunch Time -->
<!-- End Lunch Time -->
	
<!-- Start Populate Slot -->
<!-- End Populate Slot -->
    
    
    </div>
    </div>
    <!-- End Diary Column -->
    <!-- Start Diary Column -->
    <div class="DiaryColumnContainer ContextOn 56 EmptySlots" style="cursor:pointer;" data-apptid="" data-time="16:50" data-staffid="1" data-staffname="Darren  Rieck" data-status="" data-key="56" data-clientid="" data-clientname="" data-newclient="" data-extended="" data-primaryid="" data-invoiced="" data-caseid="" data-type="">
    
    <div class="DiaryColumn" >

<!-- Start Lunch Time -->
<!-- End Lunch Time -->
	
<!-- Start Populate Slot -->
<!-- End Populate Slot -->
    
    
    </div>
    </div>
    <!-- End Diary Column -->
    <!-- Start Diary Column -->
    <div class="DiaryColumnContainer ContextOn 56 EmptySlots" style="cursor:pointer;" data-apptid="" data-time="16:50" data-staffid="6" data-staffname="Karen  Kitchener" data-status="" data-key="56" data-clientid="" data-clientname="" data-newclient="" data-extended="" data-primaryid="" data-invoiced="" data-caseid="" data-type="">
    
    <div class="DiaryColumn" >

<!-- Start Lunch Time -->
<!-- End Lunch Time -->
	
<!-- Start Populate Slot -->
<!-- End Populate Slot -->
    
    
    </div>
    </div>
    <!-- End Diary Column -->
    <!-- Start Diary Column -->
    <div class="DiaryColumnContainer ContextOn 57 EmptySlots" style="cursor:pointer;" data-apptid="" data-time="17:00" data-staffid="26" data-staffname="Bec Webberley" data-status="" data-key="57" data-clientid="" data-clientname="" data-newclient="" data-extended="" data-primaryid="" data-invoiced="" data-caseid="" data-type="">
    
    <div class="DiaryColumn" >

<!-- Start Lunch Time -->
<!-- End Lunch Time -->
	
<!-- Start Populate Slot -->
<!-- End Populate Slot -->
    
    
    </div>
    </div>
    <!-- End Diary Column -->
    <!-- Start Diary Column -->
    <div class="DiaryColumnContainer ContextOn 57 FilledSlots" style="cursor:pointer;" data-apptid="28971" data-time="17:00" data-staffid="7" data-staffname="Tamara Shaw" data-status="StdAppt" data-key="57" data-clientid="229" data-clientname="Cherie Hodson" data-newclient="0" data-extended="1" data-primaryid="0" data-invoiced="" data-caseid="508" data-type="Services">
    
    <div class="DiaryColumnSchedule" style="color:#003399; background-color:#D1D6D6;">

<!-- Start Lunch Time -->
<!-- End Lunch Time -->
	
<!-- Start Populate Slot -->
    <div class="ClientType SlotContent" style="float:left; width:15px; background-color:#006; color:#FFF; margin-left:2px; margin-top:2px;">P</div>
    

    <div class="Patient SlotContent DiaryToolTip" 
    title="<span>Provider : Tamara Shaw<hr />Date : 19/07/2012 - Time : 17:00</span><hr />Cherie Hodson<br /><br />Contact No : 0402016381<hr />Private -  Physio Std<hr />Case : PVT: Ankle / Back / wrist<hr />" 
    style="float:left; margin:2px 0px 0px 5px; font-weight:bold; font-size:11px; ">
	Cherie Hodson    
    </div>

<!-- End Populate Slot -->
    
    
    </div>
    </div>
    <!-- End Diary Column -->
    <!-- Start Diary Column -->
    <div class="DiaryColumnContainer ContextOn 57 EmptySlots" style="cursor:pointer;" data-apptid="" data-time="17:00" data-staffid="16" data-staffname="Olivia  Moy" data-status="" data-key="57" data-clientid="" data-clientname="" data-newclient="" data-extended="" data-primaryid="" data-invoiced="" data-caseid="" data-type="">
    
    <div class="DiaryColumn" >

<!-- Start Lunch Time -->
<!-- End Lunch Time -->
	
<!-- Start Populate Slot -->
<!-- End Populate Slot -->
    
    
    </div>
    </div>
    <!-- End Diary Column -->
    <!-- Start Diary Column -->
    <div class="DiaryColumnContainer ContextOn 57 EmptySlots" style="cursor:pointer;" data-apptid="" data-time="17:00" data-staffid="18" data-staffname="Andrew  Rashleigh" data-status="" data-key="57" data-clientid="" data-clientname="" data-newclient="" data-extended="" data-primaryid="" data-invoiced="" data-caseid="" data-type="">
    
    <div class="DiaryColumn" >

<!-- Start Lunch Time -->
<!-- End Lunch Time -->
	
<!-- Start Populate Slot -->
<!-- End Populate Slot -->
    
    
    </div>
    </div>
    <!-- End Diary Column -->
    <!-- Start Diary Column -->
    <div class="DiaryColumnContainer ContextOn 57 EmptySlots" style="cursor:pointer;" data-apptid="" data-time="17:00" data-staffid="14" data-staffname="Emile  Cloete" data-status="" data-key="57" data-clientid="" data-clientname="" data-newclient="" data-extended="" data-primaryid="" data-invoiced="" data-caseid="" data-type="">
    
    <div class="DiaryColumnSchedule" >

<!-- Start Lunch Time -->
<!-- End Lunch Time -->
	
<!-- Start Populate Slot -->
<!-- End Populate Slot -->
    
    
    </div>
    </div>
    <!-- End Diary Column -->
    <!-- Start Diary Column -->
    <div class="DiaryColumnContainer ContextOn 57 EmptySlots" style="cursor:pointer;" data-apptid="" data-time="17:00" data-staffid="1" data-staffname="Darren  Rieck" data-status="" data-key="57" data-clientid="" data-clientname="" data-newclient="" data-extended="" data-primaryid="" data-invoiced="" data-caseid="" data-type="">
    
    <div class="DiaryColumn" >

<!-- Start Lunch Time -->
<!-- End Lunch Time -->
	
<!-- Start Populate Slot -->
<!-- End Populate Slot -->
    
    
    </div>
    </div>
    <!-- End Diary Column -->
    <!-- Start Diary Column -->
    <div class="DiaryColumnContainer ContextOn 57 EmptySlots" style="cursor:pointer;" data-apptid="" data-time="17:00" data-staffid="6" data-staffname="Karen  Kitchener" data-status="" data-key="57" data-clientid="" data-clientname="" data-newclient="" data-extended="" data-primaryid="" data-invoiced="" data-caseid="" data-type="">
    
    <div class="DiaryColumn" >

<!-- Start Lunch Time -->
<!-- End Lunch Time -->
	
<!-- Start Populate Slot -->
<!-- End Populate Slot -->
    
    
    </div>
    </div>
    <!-- End Diary Column -->
    <!-- Start Diary Column -->
    <div class="DiaryColumnContainer ContextOn 58 EmptySlots" style="cursor:pointer;" data-apptid="" data-time="17:10" data-staffid="26" data-staffname="Bec Webberley" data-status="" data-key="58" data-clientid="" data-clientname="" data-newclient="" data-extended="" data-primaryid="" data-invoiced="" data-caseid="" data-type="">
    
    <div class="DiaryColumn" >

<!-- Start Lunch Time -->
<!-- End Lunch Time -->
	
<!-- Start Populate Slot -->
<!-- End Populate Slot -->
    
    
    </div>
    </div>
    <!-- End Diary Column -->
    <!-- Start Diary Column -->
    <div class="DiaryColumnContainer ContextOff 58 " style="cursor:not-allowed;" data-apptid="28972" data-time="17:10" data-staffid="7" data-staffname="Tamara Shaw" data-status="StdAppt" data-key="58" data-clientid="229" data-clientname="Cherie Hodson" data-newclient="0" data-extended="0" data-primaryid="28971" data-invoiced="" data-caseid="" data-type="Services">
    
    <div class="DiaryColumnSchedule" style="color:#003399; background-color:#D1D6D6;">

<!-- Start Lunch Time -->
<!-- End Lunch Time -->
	
<!-- Start Populate Slot -->
<!-- End Populate Slot -->
    
    
    </div>
    </div>
    <!-- End Diary Column -->
    <!-- Start Diary Column -->
    <div class="DiaryColumnContainer ContextOn 58 EmptySlots" style="cursor:pointer;" data-apptid="" data-time="17:10" data-staffid="16" data-staffname="Olivia  Moy" data-status="" data-key="58" data-clientid="" data-clientname="" data-newclient="" data-extended="" data-primaryid="" data-invoiced="" data-caseid="" data-type="">
    
    <div class="DiaryColumn" >

<!-- Start Lunch Time -->
<!-- End Lunch Time -->
	
<!-- Start Populate Slot -->
<!-- End Populate Slot -->
    
    
    </div>
    </div>
    <!-- End Diary Column -->
    <!-- Start Diary Column -->
    <div class="DiaryColumnContainer ContextOn 58 EmptySlots" style="cursor:pointer;" data-apptid="" data-time="17:10" data-staffid="18" data-staffname="Andrew  Rashleigh" data-status="" data-key="58" data-clientid="" data-clientname="" data-newclient="" data-extended="" data-primaryid="" data-invoiced="" data-caseid="" data-type="">
    
    <div class="DiaryColumn" >

<!-- Start Lunch Time -->
<!-- End Lunch Time -->
	
<!-- Start Populate Slot -->
<!-- End Populate Slot -->
    
    
    </div>
    </div>
    <!-- End Diary Column -->
    <!-- Start Diary Column -->
    <div class="DiaryColumnContainer ContextOn 58 EmptySlots" style="cursor:pointer;" data-apptid="" data-time="17:10" data-staffid="14" data-staffname="Emile  Cloete" data-status="" data-key="58" data-clientid="" data-clientname="" data-newclient="" data-extended="" data-primaryid="" data-invoiced="" data-caseid="" data-type="">
    
    <div class="DiaryColumnSchedule" >

<!-- Start Lunch Time -->
<!-- End Lunch Time -->
	
<!-- Start Populate Slot -->
<!-- End Populate Slot -->
    
    
    </div>
    </div>
    <!-- End Diary Column -->
    <!-- Start Diary Column -->
    <div class="DiaryColumnContainer ContextOn 58 EmptySlots" style="cursor:pointer;" data-apptid="" data-time="17:10" data-staffid="1" data-staffname="Darren  Rieck" data-status="" data-key="58" data-clientid="" data-clientname="" data-newclient="" data-extended="" data-primaryid="" data-invoiced="" data-caseid="" data-type="">
    
    <div class="DiaryColumn" >

<!-- Start Lunch Time -->
<!-- End Lunch Time -->
	
<!-- Start Populate Slot -->
<!-- End Populate Slot -->
    
    
    </div>
    </div>
    <!-- End Diary Column -->
    <!-- Start Diary Column -->
    <div class="DiaryColumnContainer ContextOn 58 EmptySlots" style="cursor:pointer;" data-apptid="" data-time="17:10" data-staffid="6" data-staffname="Karen  Kitchener" data-status="" data-key="58" data-clientid="" data-clientname="" data-newclient="" data-extended="" data-primaryid="" data-invoiced="" data-caseid="" data-type="">
    
    <div class="DiaryColumn" >

<!-- Start Lunch Time -->
<!-- End Lunch Time -->
	
<!-- Start Populate Slot -->
<!-- End Populate Slot -->
    
    
    </div>
    </div>
    <!-- End Diary Column -->
    <!-- Start Diary Column -->
    <div class="DiaryColumnContainer ContextOn 59 EmptySlots" style="cursor:pointer;" data-apptid="" data-time="17:20" data-staffid="26" data-staffname="Bec Webberley" data-status="" data-key="59" data-clientid="" data-clientname="" data-newclient="" data-extended="" data-primaryid="" data-invoiced="" data-caseid="" data-type="">
    
    <div class="DiaryColumn" >

<!-- Start Lunch Time -->
<!-- End Lunch Time -->
	
<!-- Start Populate Slot -->
<!-- End Populate Slot -->
    
    
    </div>
    </div>
    <!-- End Diary Column -->
    <!-- Start Diary Column -->
    <div class="DiaryColumnContainer ContextOff 59 " style="cursor:not-allowed;" data-apptid="28973" data-time="17:20" data-staffid="7" data-staffname="Tamara Shaw" data-status="StdAppt" data-key="59" data-clientid="229" data-clientname="Cherie Hodson" data-newclient="0" data-extended="0" data-primaryid="28971" data-invoiced="" data-caseid="" data-type="Services">
    
    <div class="DiaryColumnSchedule" style="color:#003399; background-color:#D1D6D6;">

<!-- Start Lunch Time -->
<!-- End Lunch Time -->
	
<!-- Start Populate Slot -->
<!-- End Populate Slot -->
    
    
    </div>
    </div>
    <!-- End Diary Column -->
    <!-- Start Diary Column -->
    <div class="DiaryColumnContainer ContextOn 59 EmptySlots" style="cursor:pointer;" data-apptid="" data-time="17:20" data-staffid="16" data-staffname="Olivia  Moy" data-status="" data-key="59" data-clientid="" data-clientname="" data-newclient="" data-extended="" data-primaryid="" data-invoiced="" data-caseid="" data-type="">
    
    <div class="DiaryColumn" >

<!-- Start Lunch Time -->
<!-- End Lunch Time -->
	
<!-- Start Populate Slot -->
<!-- End Populate Slot -->
    
    
    </div>
    </div>
    <!-- End Diary Column -->
    <!-- Start Diary Column -->
    <div class="DiaryColumnContainer ContextOn 59 EmptySlots" style="cursor:pointer;" data-apptid="" data-time="17:20" data-staffid="18" data-staffname="Andrew  Rashleigh" data-status="" data-key="59" data-clientid="" data-clientname="" data-newclient="" data-extended="" data-primaryid="" data-invoiced="" data-caseid="" data-type="">
    
    <div class="DiaryColumn" >

<!-- Start Lunch Time -->
<!-- End Lunch Time -->
	
<!-- Start Populate Slot -->
<!-- End Populate Slot -->
    
    
    </div>
    </div>
    <!-- End Diary Column -->
    <!-- Start Diary Column -->
    <div class="DiaryColumnContainer ContextOn 59 EmptySlots" style="cursor:pointer;" data-apptid="" data-time="17:20" data-staffid="14" data-staffname="Emile  Cloete" data-status="" data-key="59" data-clientid="" data-clientname="" data-newclient="" data-extended="" data-primaryid="" data-invoiced="" data-caseid="" data-type="">
    
    <div class="DiaryColumnSchedule" >

<!-- Start Lunch Time -->
<!-- End Lunch Time -->
	
<!-- Start Populate Slot -->
<!-- End Populate Slot -->
    
    
    </div>
    </div>
    <!-- End Diary Column -->
    <!-- Start Diary Column -->
    <div class="DiaryColumnContainer ContextOn 59 EmptySlots" style="cursor:pointer;" data-apptid="" data-time="17:20" data-staffid="1" data-staffname="Darren  Rieck" data-status="" data-key="59" data-clientid="" data-clientname="" data-newclient="" data-extended="" data-primaryid="" data-invoiced="" data-caseid="" data-type="">
    
    <div class="DiaryColumn" >

<!-- Start Lunch Time -->
<!-- End Lunch Time -->
	
<!-- Start Populate Slot -->
<!-- End Populate Slot -->
    
    
    </div>
    </div>
    <!-- End Diary Column -->
    <!-- Start Diary Column -->
    <div class="DiaryColumnContainer ContextOn 59 EmptySlots" style="cursor:pointer;" data-apptid="" data-time="17:20" data-staffid="6" data-staffname="Karen  Kitchener" data-status="" data-key="59" data-clientid="" data-clientname="" data-newclient="" data-extended="" data-primaryid="" data-invoiced="" data-caseid="" data-type="">
    
    <div class="DiaryColumn" >

<!-- Start Lunch Time -->
<!-- End Lunch Time -->
	
<!-- Start Populate Slot -->
<!-- End Populate Slot -->
    
    
    </div>
    </div>
    <!-- End Diary Column -->
    <!-- Start Diary Column -->
    <div class="DiaryColumnContainer ContextOn 60 EmptySlots" style="cursor:pointer;" data-apptid="" data-time="17:30" data-staffid="26" data-staffname="Bec Webberley" data-status="" data-key="60" data-clientid="" data-clientname="" data-newclient="" data-extended="" data-primaryid="" data-invoiced="" data-caseid="" data-type="">
    
    <div class="DiaryColumn" >

<!-- Start Lunch Time -->
<!-- End Lunch Time -->
	
<!-- Start Populate Slot -->
<!-- End Populate Slot -->
    
    
    </div>
    </div>
    <!-- End Diary Column -->
    <!-- Start Diary Column -->
    <div class="DiaryColumnContainer ContextOn 60 FilledSlots" style="cursor:pointer;" data-apptid="32825" data-time="17:30" data-staffid="7" data-staffname="Tamara Shaw" data-status="StdAppt" data-key="60" data-clientid="1290" data-clientname="Monica Balarezo" data-newclient="0" data-extended="1" data-primaryid="0" data-invoiced="" data-caseid="2578" data-type="Services">
    
    <div class="DiaryColumnSchedule" style="color:#003399; background-color:#D1D6D6;">

<!-- Start Lunch Time -->
<!-- End Lunch Time -->
	
<!-- Start Populate Slot -->
    <div class="ClientType SlotContent" style="float:left; width:15px; background-color:#360; color:#FFF; margin-left:2px; margin-top:2px;">T</div>
    

    <div class="Patient SlotContent DiaryToolTip" 
    title="<span>Provider : Tamara Shaw<hr />Date : 19/07/2012 - Time : 17:30</span><hr />Monica Balarezo<br /><br />Contact No : 0430 942 622<hr /><span>med cert to 10/08</span><hr />Third Party : Workcover<hr />WC - Subs Consult Std Level B<hr />Case : WC neck/arm <hr />" 
    style="float:left; margin:2px 0px 0px 5px; font-weight:bold; font-size:11px; ">
	Monica Balarezo    
    </div>

<img src="/images/icons/numbers/2.png" style="float:right; margin-right:2px;" title="Third Party Sessions Left"; /><!-- End Populate Slot -->
    
    
    </div>
    </div>
    <!-- End Diary Column -->
    <!-- Start Diary Column -->
    <div class="DiaryColumnContainer ContextOn 60 EmptySlots" style="cursor:pointer;" data-apptid="" data-time="17:30" data-staffid="16" data-staffname="Olivia  Moy" data-status="" data-key="60" data-clientid="" data-clientname="" data-newclient="" data-extended="" data-primaryid="" data-invoiced="" data-caseid="" data-type="">
    
    <div class="DiaryColumn" >

<!-- Start Lunch Time -->
<!-- End Lunch Time -->
	
<!-- Start Populate Slot -->
<!-- End Populate Slot -->
    
    
    </div>
    </div>
    <!-- End Diary Column -->
    <!-- Start Diary Column -->
    <div class="DiaryColumnContainer ContextOn 60 EmptySlots" style="cursor:pointer;" data-apptid="" data-time="17:30" data-staffid="18" data-staffname="Andrew  Rashleigh" data-status="" data-key="60" data-clientid="" data-clientname="" data-newclient="" data-extended="" data-primaryid="" data-invoiced="" data-caseid="" data-type="">
    
    <div class="DiaryColumn" >

<!-- Start Lunch Time -->
<!-- End Lunch Time -->
	
<!-- Start Populate Slot -->
<!-- End Populate Slot -->
    
    
    </div>
    </div>
    <!-- End Diary Column -->
    <!-- Start Diary Column -->
    <div class="DiaryColumnContainer ContextOn 60 EmptySlots" style="cursor:pointer;" data-apptid="" data-time="17:30" data-staffid="14" data-staffname="Emile  Cloete" data-status="" data-key="60" data-clientid="" data-clientname="" data-newclient="" data-extended="" data-primaryid="" data-invoiced="" data-caseid="" data-type="">
    
    <div class="DiaryColumnSchedule" >

<!-- Start Lunch Time -->
<!-- End Lunch Time -->
	
<!-- Start Populate Slot -->
<!-- End Populate Slot -->
    
    
    </div>
    </div>
    <!-- End Diary Column -->
    <!-- Start Diary Column -->
    <div class="DiaryColumnContainer ContextOn 60 EmptySlots" style="cursor:pointer;" data-apptid="" data-time="17:30" data-staffid="1" data-staffname="Darren  Rieck" data-status="" data-key="60" data-clientid="" data-clientname="" data-newclient="" data-extended="" data-primaryid="" data-invoiced="" data-caseid="" data-type="">
    
    <div class="DiaryColumn" >

<!-- Start Lunch Time -->
<!-- End Lunch Time -->
	
<!-- Start Populate Slot -->
<!-- End Populate Slot -->
    
    
    </div>
    </div>
    <!-- End Diary Column -->
    <!-- Start Diary Column -->
    <div class="DiaryColumnContainer ContextOn 60 EmptySlots" style="cursor:pointer;" data-apptid="" data-time="17:30" data-staffid="6" data-staffname="Karen  Kitchener" data-status="" data-key="60" data-clientid="" data-clientname="" data-newclient="" data-extended="" data-primaryid="" data-invoiced="" data-caseid="" data-type="">
    
    <div class="DiaryColumn" >

<!-- Start Lunch Time -->
<!-- End Lunch Time -->
	
<!-- Start Populate Slot -->
<!-- End Populate Slot -->
    
    
    </div>
    </div>
    <!-- End Diary Column -->
    <!-- Start Diary Column -->
    <div class="DiaryColumnContainer ContextOn 61 EmptySlots" style="cursor:pointer;" data-apptid="" data-time="17:40" data-staffid="26" data-staffname="Bec Webberley" data-status="" data-key="61" data-clientid="" data-clientname="" data-newclient="" data-extended="" data-primaryid="" data-invoiced="" data-caseid="" data-type="">
    
    <div class="DiaryColumn" >

<!-- Start Lunch Time -->
<!-- End Lunch Time -->
	
<!-- Start Populate Slot -->
<!-- End Populate Slot -->
    
    
    </div>
    </div>
    <!-- End Diary Column -->
    <!-- Start Diary Column -->
    <div class="DiaryColumnContainer ContextOff 61 " style="cursor:not-allowed;" data-apptid="32876" data-time="17:40" data-staffid="7" data-staffname="Tamara Shaw" data-status="StdAppt" data-key="61" data-clientid="1290" data-clientname="Monica Balarezo" data-newclient="0" data-extended="0" data-primaryid="32825" data-invoiced="" data-caseid="" data-type="Services">
    
    <div class="DiaryColumnSchedule" style="color:#003399; background-color:#D1D6D6;">

<!-- Start Lunch Time -->
<!-- End Lunch Time -->
	
<!-- Start Populate Slot -->
<!-- End Populate Slot -->
    
    
    </div>
    </div>
    <!-- End Diary Column -->
    <!-- Start Diary Column -->
    <div class="DiaryColumnContainer ContextOn 61 EmptySlots" style="cursor:pointer;" data-apptid="" data-time="17:40" data-staffid="16" data-staffname="Olivia  Moy" data-status="" data-key="61" data-clientid="" data-clientname="" data-newclient="" data-extended="" data-primaryid="" data-invoiced="" data-caseid="" data-type="">
    
    <div class="DiaryColumn" >

<!-- Start Lunch Time -->
<!-- End Lunch Time -->
	
<!-- Start Populate Slot -->
<!-- End Populate Slot -->
    
    
    </div>
    </div>
    <!-- End Diary Column -->
    <!-- Start Diary Column -->
    <div class="DiaryColumnContainer ContextOn 61 EmptySlots" style="cursor:pointer;" data-apptid="" data-time="17:40" data-staffid="18" data-staffname="Andrew  Rashleigh" data-status="" data-key="61" data-clientid="" data-clientname="" data-newclient="" data-extended="" data-primaryid="" data-invoiced="" data-caseid="" data-type="">
    
    <div class="DiaryColumn" >

<!-- Start Lunch Time -->
<!-- End Lunch Time -->
	
<!-- Start Populate Slot -->
<!-- End Populate Slot -->
    
    
    </div>
    </div>
    <!-- End Diary Column -->
    <!-- Start Diary Column -->
    <div class="DiaryColumnContainer ContextOn 61 EmptySlots" style="cursor:pointer;" data-apptid="" data-time="17:40" data-staffid="14" data-staffname="Emile  Cloete" data-status="" data-key="61" data-clientid="" data-clientname="" data-newclient="" data-extended="" data-primaryid="" data-invoiced="" data-caseid="" data-type="">
    
    <div class="DiaryColumnSchedule" >

<!-- Start Lunch Time -->
<!-- End Lunch Time -->
	
<!-- Start Populate Slot -->
<!-- End Populate Slot -->
    
    
    </div>
    </div>
    <!-- End Diary Column -->
    <!-- Start Diary Column -->
    <div class="DiaryColumnContainer ContextOn 61 EmptySlots" style="cursor:pointer;" data-apptid="" data-time="17:40" data-staffid="1" data-staffname="Darren  Rieck" data-status="" data-key="61" data-clientid="" data-clientname="" data-newclient="" data-extended="" data-primaryid="" data-invoiced="" data-caseid="" data-type="">
    
    <div class="DiaryColumn" >

<!-- Start Lunch Time -->
<!-- End Lunch Time -->
	
<!-- Start Populate Slot -->
<!-- End Populate Slot -->
    
    
    </div>
    </div>
    <!-- End Diary Column -->
    <!-- Start Diary Column -->
    <div class="DiaryColumnContainer ContextOn 61 EmptySlots" style="cursor:pointer;" data-apptid="" data-time="17:40" data-staffid="6" data-staffname="Karen  Kitchener" data-status="" data-key="61" data-clientid="" data-clientname="" data-newclient="" data-extended="" data-primaryid="" data-invoiced="" data-caseid="" data-type="">
    
    <div class="DiaryColumn" >

<!-- Start Lunch Time -->
<!-- End Lunch Time -->
	
<!-- Start Populate Slot -->
<!-- End Populate Slot -->
    
    
    </div>
    </div>
    <!-- End Diary Column -->
    <!-- Start Diary Column -->
    <div class="DiaryColumnContainer ContextOn 62 EmptySlots" style="cursor:pointer;" data-apptid="" data-time="17:50" data-staffid="26" data-staffname="Bec Webberley" data-status="" data-key="62" data-clientid="" data-clientname="" data-newclient="" data-extended="" data-primaryid="" data-invoiced="" data-caseid="" data-type="">
    
    <div class="DiaryColumn" >

<!-- Start Lunch Time -->
<!-- End Lunch Time -->
	
<!-- Start Populate Slot -->
<!-- End Populate Slot -->
    
    
    </div>
    </div>
    <!-- End Diary Column -->
    <!-- Start Diary Column -->
    <div class="DiaryColumnContainer ContextOff 62 " style="cursor:not-allowed;" data-apptid="32877" data-time="17:50" data-staffid="7" data-staffname="Tamara Shaw" data-status="StdAppt" data-key="62" data-clientid="1290" data-clientname="Monica Balarezo" data-newclient="0" data-extended="0" data-primaryid="32825" data-invoiced="" data-caseid="" data-type="Services">
    
    <div class="DiaryColumnSchedule" style="color:#003399; background-color:#D1D6D6;">

<!-- Start Lunch Time -->
<!-- End Lunch Time -->
	
<!-- Start Populate Slot -->
<!-- End Populate Slot -->
    
    
    </div>
    </div>
    <!-- End Diary Column -->
    <!-- Start Diary Column -->
    <div class="DiaryColumnContainer ContextOn 62 EmptySlots" style="cursor:pointer;" data-apptid="" data-time="17:50" data-staffid="16" data-staffname="Olivia  Moy" data-status="" data-key="62" data-clientid="" data-clientname="" data-newclient="" data-extended="" data-primaryid="" data-invoiced="" data-caseid="" data-type="">
    
    <div class="DiaryColumn" >

<!-- Start Lunch Time -->
<!-- End Lunch Time -->
	
<!-- Start Populate Slot -->
<!-- End Populate Slot -->
    
    
    </div>
    </div>
    <!-- End Diary Column -->
    <!-- Start Diary Column -->
    <div class="DiaryColumnContainer ContextOn 62 EmptySlots" style="cursor:pointer;" data-apptid="" data-time="17:50" data-staffid="18" data-staffname="Andrew  Rashleigh" data-status="" data-key="62" data-clientid="" data-clientname="" data-newclient="" data-extended="" data-primaryid="" data-invoiced="" data-caseid="" data-type="">
    
    <div class="DiaryColumn" >

<!-- Start Lunch Time -->
<!-- End Lunch Time -->
	
<!-- Start Populate Slot -->
<!-- End Populate Slot -->
    
    
    </div>
    </div>
    <!-- End Diary Column -->
    <!-- Start Diary Column -->
    <div class="DiaryColumnContainer ContextOn 62 EmptySlots" style="cursor:pointer;" data-apptid="" data-time="17:50" data-staffid="14" data-staffname="Emile  Cloete" data-status="" data-key="62" data-clientid="" data-clientname="" data-newclient="" data-extended="" data-primaryid="" data-invoiced="" data-caseid="" data-type="">
    
    <div class="DiaryColumnSchedule" >

<!-- Start Lunch Time -->
<!-- End Lunch Time -->
	
<!-- Start Populate Slot -->
<!-- End Populate Slot -->
    
    
    </div>
    </div>
    <!-- End Diary Column -->
    <!-- Start Diary Column -->
    <div class="DiaryColumnContainer ContextOn 62 EmptySlots" style="cursor:pointer;" data-apptid="" data-time="17:50" data-staffid="1" data-staffname="Darren  Rieck" data-status="" data-key="62" data-clientid="" data-clientname="" data-newclient="" data-extended="" data-primaryid="" data-invoiced="" data-caseid="" data-type="">
    
    <div class="DiaryColumn" >

<!-- Start Lunch Time -->
<!-- End Lunch Time -->
	
<!-- Start Populate Slot -->
<!-- End Populate Slot -->
    
    
    </div>
    </div>
    <!-- End Diary Column -->
    <!-- Start Diary Column -->
    <div class="DiaryColumnContainer ContextOn 62 EmptySlots" style="cursor:pointer;" data-apptid="" data-time="17:50" data-staffid="6" data-staffname="Karen  Kitchener" data-status="" data-key="62" data-clientid="" data-clientname="" data-newclient="" data-extended="" data-primaryid="" data-invoiced="" data-caseid="" data-type="">
    
    <div class="DiaryColumn" >

<!-- Start Lunch Time -->
<!-- End Lunch Time -->
	
<!-- Start Populate Slot -->
<!-- End Populate Slot -->
    
    
    </div>
    </div>
    <!-- End Diary Column -->
    <!-- Start Diary Column -->
    <div class="DiaryColumnContainer ContextOn 63 EmptySlots" style="cursor:pointer;" data-apptid="" data-time="18:00" data-staffid="26" data-staffname="Bec Webberley" data-status="" data-key="63" data-clientid="" data-clientname="" data-newclient="" data-extended="" data-primaryid="" data-invoiced="" data-caseid="" data-type="">
    
    <div class="DiaryColumn" >

<!-- Start Lunch Time -->
<!-- End Lunch Time -->
	
<!-- Start Populate Slot -->
<!-- End Populate Slot -->
    
    
    </div>
    </div>
    <!-- End Diary Column -->
    <!-- Start Diary Column -->
    <div class="DiaryColumnContainer ContextOn 63 FilledSlots" style="cursor:pointer;" data-apptid="32821" data-time="18:00" data-staffid="7" data-staffname="Tamara Shaw" data-status="StdAppt" data-key="63" data-clientid="829" data-clientname="Jenny Ingram" data-newclient="0" data-extended="1" data-primaryid="0" data-invoiced="" data-caseid="2812" data-type="Services">
    
    <div class="DiaryColumnSchedule" style="color:#003399; background-color:#D1D6D6;">

<!-- Start Lunch Time -->
<!-- End Lunch Time -->
	
<!-- Start Populate Slot -->
    <div class="ClientType SlotContent" style="float:left; width:15px; background-color:#006; color:#FFF; margin-left:2px; margin-top:2px;">P</div>
    

    <div class="Patient SlotContent DiaryToolTip" 
    title="<span>Provider : Tamara Shaw<hr />Date : 19/07/2012 - Time : 18:00</span><hr />Jenny Ingram<br /><br />Contact No : 0404008067<hr />Private -  Physio Std<hr />Case : Hip<hr />" 
    style="float:left; margin:2px 0px 0px 5px; font-weight:bold; font-size:11px; ">
	Jenny Ingram    
    </div>

<!-- End Populate Slot -->
    
    
    </div>
    </div>
    <!-- End Diary Column -->
    <!-- Start Diary Column -->
    <div class="DiaryColumnContainer ContextOn 63 EmptySlots" style="cursor:pointer;" data-apptid="" data-time="18:00" data-staffid="16" data-staffname="Olivia  Moy" data-status="" data-key="63" data-clientid="" data-clientname="" data-newclient="" data-extended="" data-primaryid="" data-invoiced="" data-caseid="" data-type="">
    
    <div class="DiaryColumn" >

<!-- Start Lunch Time -->
<!-- End Lunch Time -->
	
<!-- Start Populate Slot -->
<!-- End Populate Slot -->
    
    
    </div>
    </div>
    <!-- End Diary Column -->
    <!-- Start Diary Column -->
    <div class="DiaryColumnContainer ContextOn 63 EmptySlots" style="cursor:pointer;" data-apptid="" data-time="18:00" data-staffid="18" data-staffname="Andrew  Rashleigh" data-status="" data-key="63" data-clientid="" data-clientname="" data-newclient="" data-extended="" data-primaryid="" data-invoiced="" data-caseid="" data-type="">
    
    <div class="DiaryColumn" >

<!-- Start Lunch Time -->
<!-- End Lunch Time -->
	
<!-- Start Populate Slot -->
<!-- End Populate Slot -->
    
    
    </div>
    </div>
    <!-- End Diary Column -->
    <!-- Start Diary Column -->
    <div class="DiaryColumnContainer ContextOn 63 EmptySlots" style="cursor:pointer;" data-apptid="" data-time="18:00" data-staffid="14" data-staffname="Emile  Cloete" data-status="" data-key="63" data-clientid="" data-clientname="" data-newclient="" data-extended="" data-primaryid="" data-invoiced="" data-caseid="" data-type="">
    
    <div class="DiaryColumn" >

<!-- Start Lunch Time -->
<!-- End Lunch Time -->
	
<!-- Start Populate Slot -->
<!-- End Populate Slot -->
    
    
    </div>
    </div>
    <!-- End Diary Column -->
    <!-- Start Diary Column -->
    <div class="DiaryColumnContainer ContextOn 63 EmptySlots" style="cursor:pointer;" data-apptid="" data-time="18:00" data-staffid="1" data-staffname="Darren  Rieck" data-status="" data-key="63" data-clientid="" data-clientname="" data-newclient="" data-extended="" data-primaryid="" data-invoiced="" data-caseid="" data-type="">
    
    <div class="DiaryColumn" >

<!-- Start Lunch Time -->
<!-- End Lunch Time -->
	
<!-- Start Populate Slot -->
<!-- End Populate Slot -->
    
    
    </div>
    </div>
    <!-- End Diary Column -->
    <!-- Start Diary Column -->
    <div class="DiaryColumnContainer ContextOn 63 ClassSlots" style="cursor:pointer;" data-apptid="29319" data-time="18:00" data-staffid="6" data-staffname="Karen  Kitchener" data-status="Class" data-key="63" data-clientid="" data-clientname="" data-newclient="0" data-extended="0" data-primaryid="0" data-invoiced="0" data-caseid="" data-type="Classes">
    
    <div class="DiaryColumnSchedule" style="color:#003399; background-color:#FFF1CC;">

<!-- Start Lunch Time -->
<!-- End Lunch Time -->
	
<!-- Start Populate Slot -->
    

    <div class="Patient SlotContent ClassToolTip" 
    title="Yoga - Casual Class<hr />Total Participants : 4<hr /><span>Beverley Pestana</span><br /><span>Christina Watt</span><br /><span>Lizzie Hicks</span><br /><span>Isidra Toldi</span><br />" 
    style="float:left; margin:2px 0px 0px 5px; font-weight:bold; font-size:11px; ">
	Yoga - Casual Class    
    </div>

<!-- End Populate Slot -->
    
    
    </div>
    </div>
    <!-- End Diary Column -->
    <!-- Start Diary Column -->
    <div class="DiaryColumnContainer ContextOn 64 EmptySlots" style="cursor:pointer;" data-apptid="" data-time="18:10" data-staffid="26" data-staffname="Bec Webberley" data-status="" data-key="64" data-clientid="" data-clientname="" data-newclient="" data-extended="" data-primaryid="" data-invoiced="" data-caseid="" data-type="">
    
    <div class="DiaryColumn" >

<!-- Start Lunch Time -->
<!-- End Lunch Time -->
	
<!-- Start Populate Slot -->
<!-- End Populate Slot -->
    
    
    </div>
    </div>
    <!-- End Diary Column -->
    <!-- Start Diary Column -->
    <div class="DiaryColumnContainer ContextOff 64 " style="cursor:not-allowed;" data-apptid="32822" data-time="18:10" data-staffid="7" data-staffname="Tamara Shaw" data-status="StdAppt" data-key="64" data-clientid="829" data-clientname="Jenny Ingram" data-newclient="0" data-extended="0" data-primaryid="32821" data-invoiced="" data-caseid="" data-type="Services">
    
    <div class="DiaryColumnSchedule" style="color:#003399; background-color:#D1D6D6;">

<!-- Start Lunch Time -->
<!-- End Lunch Time -->
	
<!-- Start Populate Slot -->
<!-- End Populate Slot -->
    
    
    </div>
    </div>
    <!-- End Diary Column -->
    <!-- Start Diary Column -->
    <div class="DiaryColumnContainer ContextOn 64 EmptySlots" style="cursor:pointer;" data-apptid="" data-time="18:10" data-staffid="16" data-staffname="Olivia  Moy" data-status="" data-key="64" data-clientid="" data-clientname="" data-newclient="" data-extended="" data-primaryid="" data-invoiced="" data-caseid="" data-type="">
    
    <div class="DiaryColumn" >

<!-- Start Lunch Time -->
<!-- End Lunch Time -->
	
<!-- Start Populate Slot -->
<!-- End Populate Slot -->
    
    
    </div>
    </div>
    <!-- End Diary Column -->
    <!-- Start Diary Column -->
    <div class="DiaryColumnContainer ContextOn 64 EmptySlots" style="cursor:pointer;" data-apptid="" data-time="18:10" data-staffid="18" data-staffname="Andrew  Rashleigh" data-status="" data-key="64" data-clientid="" data-clientname="" data-newclient="" data-extended="" data-primaryid="" data-invoiced="" data-caseid="" data-type="">
    
    <div class="DiaryColumn" >

<!-- Start Lunch Time -->
<!-- End Lunch Time -->
	
<!-- Start Populate Slot -->
<!-- End Populate Slot -->
    
    
    </div>
    </div>
    <!-- End Diary Column -->
    <!-- Start Diary Column -->
    <div class="DiaryColumnContainer ContextOn 64 EmptySlots" style="cursor:pointer;" data-apptid="" data-time="18:10" data-staffid="14" data-staffname="Emile  Cloete" data-status="" data-key="64" data-clientid="" data-clientname="" data-newclient="" data-extended="" data-primaryid="" data-invoiced="" data-caseid="" data-type="">
    
    <div class="DiaryColumn" >

<!-- Start Lunch Time -->
<!-- End Lunch Time -->
	
<!-- Start Populate Slot -->
<!-- End Populate Slot -->
    
    
    </div>
    </div>
    <!-- End Diary Column -->
    <!-- Start Diary Column -->
    <div class="DiaryColumnContainer ContextOn 64 EmptySlots" style="cursor:pointer;" data-apptid="" data-time="18:10" data-staffid="1" data-staffname="Darren  Rieck" data-status="" data-key="64" data-clientid="" data-clientname="" data-newclient="" data-extended="" data-primaryid="" data-invoiced="" data-caseid="" data-type="">
    
    <div class="DiaryColumn" >

<!-- Start Lunch Time -->
<!-- End Lunch Time -->
	
<!-- Start Populate Slot -->
<!-- End Populate Slot -->
    
    
    </div>
    </div>
    <!-- End Diary Column -->
    <!-- Start Diary Column -->
    <div class="DiaryColumnContainer ContextOn 64 EmptySlots" style="cursor:pointer;" data-apptid="" data-time="18:10" data-staffid="6" data-staffname="Karen  Kitchener" data-status="" data-key="64" data-clientid="" data-clientname="" data-newclient="" data-extended="" data-primaryid="" data-invoiced="" data-caseid="" data-type="">
    
    <div class="DiaryColumnSchedule" >

<!-- Start Lunch Time -->
<!-- End Lunch Time -->
	
<!-- Start Populate Slot -->
<!-- End Populate Slot -->
    
    
    </div>
    </div>
    <!-- End Diary Column -->
    <!-- Start Diary Column -->
    <div class="DiaryColumnContainer ContextOn 65 EmptySlots" style="cursor:pointer;" data-apptid="" data-time="18:20" data-staffid="26" data-staffname="Bec Webberley" data-status="" data-key="65" data-clientid="" data-clientname="" data-newclient="" data-extended="" data-primaryid="" data-invoiced="" data-caseid="" data-type="">
    
    <div class="DiaryColumn" >

<!-- Start Lunch Time -->
<!-- End Lunch Time -->
	
<!-- Start Populate Slot -->
<!-- End Populate Slot -->
    
    
    </div>
    </div>
    <!-- End Diary Column -->
    <!-- Start Diary Column -->
    <div class="DiaryColumnContainer ContextOff 65 " style="cursor:not-allowed;" data-apptid="32823" data-time="18:20" data-staffid="7" data-staffname="Tamara Shaw" data-status="StdAppt" data-key="65" data-clientid="829" data-clientname="Jenny Ingram" data-newclient="0" data-extended="0" data-primaryid="32821" data-invoiced="" data-caseid="" data-type="Services">
    
    <div class="DiaryColumnSchedule" style="color:#003399; background-color:#D1D6D6;">

<!-- Start Lunch Time -->
<!-- End Lunch Time -->
	
<!-- Start Populate Slot -->
<!-- End Populate Slot -->
    
    
    </div>
    </div>
    <!-- End Diary Column -->
    <!-- Start Diary Column -->
    <div class="DiaryColumnContainer ContextOn 65 EmptySlots" style="cursor:pointer;" data-apptid="" data-time="18:20" data-staffid="16" data-staffname="Olivia  Moy" data-status="" data-key="65" data-clientid="" data-clientname="" data-newclient="" data-extended="" data-primaryid="" data-invoiced="" data-caseid="" data-type="">
    
    <div class="DiaryColumn" >

<!-- Start Lunch Time -->
<!-- End Lunch Time -->
	
<!-- Start Populate Slot -->
<!-- End Populate Slot -->
    
    
    </div>
    </div>
    <!-- End Diary Column -->
    <!-- Start Diary Column -->
    <div class="DiaryColumnContainer ContextOn 65 EmptySlots" style="cursor:pointer;" data-apptid="" data-time="18:20" data-staffid="18" data-staffname="Andrew  Rashleigh" data-status="" data-key="65" data-clientid="" data-clientname="" data-newclient="" data-extended="" data-primaryid="" data-invoiced="" data-caseid="" data-type="">
    
    <div class="DiaryColumn" >

<!-- Start Lunch Time -->
<!-- End Lunch Time -->
	
<!-- Start Populate Slot -->
<!-- End Populate Slot -->
    
    
    </div>
    </div>
    <!-- End Diary Column -->
    <!-- Start Diary Column -->
    <div class="DiaryColumnContainer ContextOn 65 EmptySlots" style="cursor:pointer;" data-apptid="" data-time="18:20" data-staffid="14" data-staffname="Emile  Cloete" data-status="" data-key="65" data-clientid="" data-clientname="" data-newclient="" data-extended="" data-primaryid="" data-invoiced="" data-caseid="" data-type="">
    
    <div class="DiaryColumn" >

<!-- Start Lunch Time -->
<!-- End Lunch Time -->
	
<!-- Start Populate Slot -->
<!-- End Populate Slot -->
    
    
    </div>
    </div>
    <!-- End Diary Column -->
    <!-- Start Diary Column -->
    <div class="DiaryColumnContainer ContextOn 65 EmptySlots" style="cursor:pointer;" data-apptid="" data-time="18:20" data-staffid="1" data-staffname="Darren  Rieck" data-status="" data-key="65" data-clientid="" data-clientname="" data-newclient="" data-extended="" data-primaryid="" data-invoiced="" data-caseid="" data-type="">
    
    <div class="DiaryColumn" >

<!-- Start Lunch Time -->
<!-- End Lunch Time -->
	
<!-- Start Populate Slot -->
<!-- End Populate Slot -->
    
    
    </div>
    </div>
    <!-- End Diary Column -->
    <!-- Start Diary Column -->
    <div class="DiaryColumnContainer ContextOn 65 EmptySlots" style="cursor:pointer;" data-apptid="" data-time="18:20" data-staffid="6" data-staffname="Karen  Kitchener" data-status="" data-key="65" data-clientid="" data-clientname="" data-newclient="" data-extended="" data-primaryid="" data-invoiced="" data-caseid="" data-type="">
    
    <div class="DiaryColumnSchedule" >

<!-- Start Lunch Time -->
<!-- End Lunch Time -->
	
<!-- Start Populate Slot -->
<!-- End Populate Slot -->
    
    
    </div>
    </div>
    <!-- End Diary Column -->
    <!-- Start Diary Column -->
    <div class="DiaryColumnContainer ContextOn 66 EmptySlots" style="cursor:pointer;" data-apptid="" data-time="18:30" data-staffid="26" data-staffname="Bec Webberley" data-status="" data-key="66" data-clientid="" data-clientname="" data-newclient="" data-extended="" data-primaryid="" data-invoiced="" data-caseid="" data-type="">
    
    <div class="DiaryColumn" >

<!-- Start Lunch Time -->
<!-- End Lunch Time -->
	
<!-- Start Populate Slot -->
<!-- End Populate Slot -->
    
    
    </div>
    </div>
    <!-- End Diary Column -->
    <!-- Start Diary Column -->
    <div class="DiaryColumnContainer ContextOn 66 EmptySlots" style="cursor:pointer;" data-apptid="" data-time="18:30" data-staffid="7" data-staffname="Tamara Shaw" data-status="" data-key="66" data-clientid="" data-clientname="" data-newclient="" data-extended="" data-primaryid="" data-invoiced="" data-caseid="" data-type="">
    
    <div class="DiaryColumn" >

<!-- Start Lunch Time -->
<!-- End Lunch Time -->
	
<!-- Start Populate Slot -->
<!-- End Populate Slot -->
    
    
    </div>
    </div>
    <!-- End Diary Column -->
    <!-- Start Diary Column -->
    <div class="DiaryColumnContainer ContextOn 66 EmptySlots" style="cursor:pointer;" data-apptid="" data-time="18:30" data-staffid="16" data-staffname="Olivia  Moy" data-status="" data-key="66" data-clientid="" data-clientname="" data-newclient="" data-extended="" data-primaryid="" data-invoiced="" data-caseid="" data-type="">
    
    <div class="DiaryColumn" >

<!-- Start Lunch Time -->
<!-- End Lunch Time -->
	
<!-- Start Populate Slot -->
<!-- End Populate Slot -->
    
    
    </div>
    </div>
    <!-- End Diary Column -->
    <!-- Start Diary Column -->
    <div class="DiaryColumnContainer ContextOn 66 EmptySlots" style="cursor:pointer;" data-apptid="" data-time="18:30" data-staffid="18" data-staffname="Andrew  Rashleigh" data-status="" data-key="66" data-clientid="" data-clientname="" data-newclient="" data-extended="" data-primaryid="" data-invoiced="" data-caseid="" data-type="">
    
    <div class="DiaryColumn" >

<!-- Start Lunch Time -->
<!-- End Lunch Time -->
	
<!-- Start Populate Slot -->
<!-- End Populate Slot -->
    
    
    </div>
    </div>
    <!-- End Diary Column -->
    <!-- Start Diary Column -->
    <div class="DiaryColumnContainer ContextOn 66 EmptySlots" style="cursor:pointer;" data-apptid="" data-time="18:30" data-staffid="14" data-staffname="Emile  Cloete" data-status="" data-key="66" data-clientid="" data-clientname="" data-newclient="" data-extended="" data-primaryid="" data-invoiced="" data-caseid="" data-type="">
    
    <div class="DiaryColumn" >

<!-- Start Lunch Time -->
<!-- End Lunch Time -->
	
<!-- Start Populate Slot -->
<!-- End Populate Slot -->
    
    
    </div>
    </div>
    <!-- End Diary Column -->
    <!-- Start Diary Column -->
    <div class="DiaryColumnContainer ContextOn 66 EmptySlots" style="cursor:pointer;" data-apptid="" data-time="18:30" data-staffid="1" data-staffname="Darren  Rieck" data-status="" data-key="66" data-clientid="" data-clientname="" data-newclient="" data-extended="" data-primaryid="" data-invoiced="" data-caseid="" data-type="">
    
    <div class="DiaryColumn" >

<!-- Start Lunch Time -->
<!-- End Lunch Time -->
	
<!-- Start Populate Slot -->
<!-- End Populate Slot -->
    
    
    </div>
    </div>
    <!-- End Diary Column -->
    <!-- Start Diary Column -->
    <div class="DiaryColumnContainer ContextOn 66 EmptySlots" style="cursor:pointer;" data-apptid="" data-time="18:30" data-staffid="6" data-staffname="Karen  Kitchener" data-status="" data-key="66" data-clientid="" data-clientname="" data-newclient="" data-extended="" data-primaryid="" data-invoiced="" data-caseid="" data-type="">
    
    <div class="DiaryColumnSchedule" >

<!-- Start Lunch Time -->
<!-- End Lunch Time -->
	
<!-- Start Populate Slot -->
<!-- End Populate Slot -->
    
    
    </div>
    </div>
    <!-- End Diary Column -->
    <!-- Start Diary Column -->
    <div class="DiaryColumnContainer ContextOn 67 EmptySlots" style="cursor:pointer;" data-apptid="" data-time="18:40" data-staffid="26" data-staffname="Bec Webberley" data-status="" data-key="67" data-clientid="" data-clientname="" data-newclient="" data-extended="" data-primaryid="" data-invoiced="" data-caseid="" data-type="">
    
    <div class="DiaryColumn" >

<!-- Start Lunch Time -->
<!-- End Lunch Time -->
	
<!-- Start Populate Slot -->
<!-- End Populate Slot -->
    
    
    </div>
    </div>
    <!-- End Diary Column -->
    <!-- Start Diary Column -->
    <div class="DiaryColumnContainer ContextOn 67 EmptySlots" style="cursor:pointer;" data-apptid="" data-time="18:40" data-staffid="7" data-staffname="Tamara Shaw" data-status="" data-key="67" data-clientid="" data-clientname="" data-newclient="" data-extended="" data-primaryid="" data-invoiced="" data-caseid="" data-type="">
    
    <div class="DiaryColumn" >

<!-- Start Lunch Time -->
<!-- End Lunch Time -->
	
<!-- Start Populate Slot -->
<!-- End Populate Slot -->
    
    
    </div>
    </div>
    <!-- End Diary Column -->
    <!-- Start Diary Column -->
    <div class="DiaryColumnContainer ContextOn 67 EmptySlots" style="cursor:pointer;" data-apptid="" data-time="18:40" data-staffid="16" data-staffname="Olivia  Moy" data-status="" data-key="67" data-clientid="" data-clientname="" data-newclient="" data-extended="" data-primaryid="" data-invoiced="" data-caseid="" data-type="">
    
    <div class="DiaryColumn" >

<!-- Start Lunch Time -->
<!-- End Lunch Time -->
	
<!-- Start Populate Slot -->
<!-- End Populate Slot -->
    
    
    </div>
    </div>
    <!-- End Diary Column -->
    <!-- Start Diary Column -->
    <div class="DiaryColumnContainer ContextOn 67 EmptySlots" style="cursor:pointer;" data-apptid="" data-time="18:40" data-staffid="18" data-staffname="Andrew  Rashleigh" data-status="" data-key="67" data-clientid="" data-clientname="" data-newclient="" data-extended="" data-primaryid="" data-invoiced="" data-caseid="" data-type="">
    
    <div class="DiaryColumn" >

<!-- Start Lunch Time -->
<!-- End Lunch Time -->
	
<!-- Start Populate Slot -->
<!-- End Populate Slot -->
    
    
    </div>
    </div>
    <!-- End Diary Column -->
    <!-- Start Diary Column -->
    <div class="DiaryColumnContainer ContextOn 67 EmptySlots" style="cursor:pointer;" data-apptid="" data-time="18:40" data-staffid="14" data-staffname="Emile  Cloete" data-status="" data-key="67" data-clientid="" data-clientname="" data-newclient="" data-extended="" data-primaryid="" data-invoiced="" data-caseid="" data-type="">
    
    <div class="DiaryColumn" >

<!-- Start Lunch Time -->
<!-- End Lunch Time -->
	
<!-- Start Populate Slot -->
<!-- End Populate Slot -->
    
    
    </div>
    </div>
    <!-- End Diary Column -->
    <!-- Start Diary Column -->
    <div class="DiaryColumnContainer ContextOn 67 EmptySlots" style="cursor:pointer;" data-apptid="" data-time="18:40" data-staffid="1" data-staffname="Darren  Rieck" data-status="" data-key="67" data-clientid="" data-clientname="" data-newclient="" data-extended="" data-primaryid="" data-invoiced="" data-caseid="" data-type="">
    
    <div class="DiaryColumn" >

<!-- Start Lunch Time -->
<!-- End Lunch Time -->
	
<!-- Start Populate Slot -->
<!-- End Populate Slot -->
    
    
    </div>
    </div>
    <!-- End Diary Column -->
    <!-- Start Diary Column -->
    <div class="DiaryColumnContainer ContextOn 67 EmptySlots" style="cursor:pointer;" data-apptid="" data-time="18:40" data-staffid="6" data-staffname="Karen  Kitchener" data-status="" data-key="67" data-clientid="" data-clientname="" data-newclient="" data-extended="" data-primaryid="" data-invoiced="" data-caseid="" data-type="">
    
    <div class="DiaryColumnSchedule" >

<!-- Start Lunch Time -->
<!-- End Lunch Time -->
	
<!-- Start Populate Slot -->
<!-- End Populate Slot -->
    
    
    </div>
    </div>
    <!-- End Diary Column -->
    <!-- Start Diary Column -->
    <div class="DiaryColumnContainer ContextOn 68 EmptySlots" style="cursor:pointer;" data-apptid="" data-time="18:50" data-staffid="26" data-staffname="Bec Webberley" data-status="" data-key="68" data-clientid="" data-clientname="" data-newclient="" data-extended="" data-primaryid="" data-invoiced="" data-caseid="" data-type="">
    
    <div class="DiaryColumn" >

<!-- Start Lunch Time -->
<!-- End Lunch Time -->
	
<!-- Start Populate Slot -->
<!-- End Populate Slot -->
    
    
    </div>
    </div>
    <!-- End Diary Column -->
    <!-- Start Diary Column -->
    <div class="DiaryColumnContainer ContextOn 68 EmptySlots" style="cursor:pointer;" data-apptid="" data-time="18:50" data-staffid="7" data-staffname="Tamara Shaw" data-status="" data-key="68" data-clientid="" data-clientname="" data-newclient="" data-extended="" data-primaryid="" data-invoiced="" data-caseid="" data-type="">
    
    <div class="DiaryColumn" >

<!-- Start Lunch Time -->
<!-- End Lunch Time -->
	
<!-- Start Populate Slot -->
<!-- End Populate Slot -->
    
    
    </div>
    </div>
    <!-- End Diary Column -->
    <!-- Start Diary Column -->
    <div class="DiaryColumnContainer ContextOn 68 EmptySlots" style="cursor:pointer;" data-apptid="" data-time="18:50" data-staffid="16" data-staffname="Olivia  Moy" data-status="" data-key="68" data-clientid="" data-clientname="" data-newclient="" data-extended="" data-primaryid="" data-invoiced="" data-caseid="" data-type="">
    
    <div class="DiaryColumn" >

<!-- Start Lunch Time -->
<!-- End Lunch Time -->
	
<!-- Start Populate Slot -->
<!-- End Populate Slot -->
    
    
    </div>
    </div>
    <!-- End Diary Column -->
    <!-- Start Diary Column -->
    <div class="DiaryColumnContainer ContextOn 68 EmptySlots" style="cursor:pointer;" data-apptid="" data-time="18:50" data-staffid="18" data-staffname="Andrew  Rashleigh" data-status="" data-key="68" data-clientid="" data-clientname="" data-newclient="" data-extended="" data-primaryid="" data-invoiced="" data-caseid="" data-type="">
    
    <div class="DiaryColumn" >

<!-- Start Lunch Time -->
<!-- End Lunch Time -->
	
<!-- Start Populate Slot -->
<!-- End Populate Slot -->
    
    
    </div>
    </div>
    <!-- End Diary Column -->
    <!-- Start Diary Column -->
    <div class="DiaryColumnContainer ContextOn 68 EmptySlots" style="cursor:pointer;" data-apptid="" data-time="18:50" data-staffid="14" data-staffname="Emile  Cloete" data-status="" data-key="68" data-clientid="" data-clientname="" data-newclient="" data-extended="" data-primaryid="" data-invoiced="" data-caseid="" data-type="">
    
    <div class="DiaryColumn" >

<!-- Start Lunch Time -->
<!-- End Lunch Time -->
	
<!-- Start Populate Slot -->
<!-- End Populate Slot -->
    
    
    </div>
    </div>
    <!-- End Diary Column -->
    <!-- Start Diary Column -->
    <div class="DiaryColumnContainer ContextOn 68 EmptySlots" style="cursor:pointer;" data-apptid="" data-time="18:50" data-staffid="1" data-staffname="Darren  Rieck" data-status="" data-key="68" data-clientid="" data-clientname="" data-newclient="" data-extended="" data-primaryid="" data-invoiced="" data-caseid="" data-type="">
    
    <div class="DiaryColumn" >

<!-- Start Lunch Time -->
<!-- End Lunch Time -->
	
<!-- Start Populate Slot -->
<!-- End Populate Slot -->
    
    
    </div>
    </div>
    <!-- End Diary Column -->
    <!-- Start Diary Column -->
    <div class="DiaryColumnContainer ContextOn 68 EmptySlots" style="cursor:pointer;" data-apptid="" data-time="18:50" data-staffid="6" data-staffname="Karen  Kitchener" data-status="" data-key="68" data-clientid="" data-clientname="" data-newclient="" data-extended="" data-primaryid="" data-invoiced="" data-caseid="" data-type="">
    
    <div class="DiaryColumnSchedule" >

<!-- Start Lunch Time -->
<!-- End Lunch Time -->
	
<!-- Start Populate Slot -->
<!-- End Populate Slot -->
    
    
    </div>
    </div>
    <!-- End Diary Column -->
    <!-- Start Diary Column -->
    <div class="DiaryColumnContainer ContextOn 69 EmptySlots" style="cursor:pointer;" data-apptid="" data-time="19:00" data-staffid="26" data-staffname="Bec Webberley" data-status="" data-key="69" data-clientid="" data-clientname="" data-newclient="" data-extended="" data-primaryid="" data-invoiced="" data-caseid="" data-type="">
    
    <div class="DiaryColumn" >

<!-- Start Lunch Time -->
<!-- End Lunch Time -->
	
<!-- Start Populate Slot -->
<!-- End Populate Slot -->
    
    
    </div>
    </div>
    <!-- End Diary Column -->
    <!-- Start Diary Column -->
    <div class="DiaryColumnContainer ContextOn 69 EmptySlots" style="cursor:pointer;" data-apptid="" data-time="19:00" data-staffid="7" data-staffname="Tamara Shaw" data-status="" data-key="69" data-clientid="" data-clientname="" data-newclient="" data-extended="" data-primaryid="" data-invoiced="" data-caseid="" data-type="">
    
    <div class="DiaryColumn" >

<!-- Start Lunch Time -->
<!-- End Lunch Time -->
	
<!-- Start Populate Slot -->
<!-- End Populate Slot -->
    
    
    </div>
    </div>
    <!-- End Diary Column -->
    <!-- Start Diary Column -->
    <div class="DiaryColumnContainer ContextOn 69 EmptySlots" style="cursor:pointer;" data-apptid="" data-time="19:00" data-staffid="16" data-staffname="Olivia  Moy" data-status="" data-key="69" data-clientid="" data-clientname="" data-newclient="" data-extended="" data-primaryid="" data-invoiced="" data-caseid="" data-type="">
    
    <div class="DiaryColumn" >

<!-- Start Lunch Time -->
<!-- End Lunch Time -->
	
<!-- Start Populate Slot -->
<!-- End Populate Slot -->
    
    
    </div>
    </div>
    <!-- End Diary Column -->
    <!-- Start Diary Column -->
    <div class="DiaryColumnContainer ContextOn 69 EmptySlots" style="cursor:pointer;" data-apptid="" data-time="19:00" data-staffid="18" data-staffname="Andrew  Rashleigh" data-status="" data-key="69" data-clientid="" data-clientname="" data-newclient="" data-extended="" data-primaryid="" data-invoiced="" data-caseid="" data-type="">
    
    <div class="DiaryColumn" >

<!-- Start Lunch Time -->
<!-- End Lunch Time -->
	
<!-- Start Populate Slot -->
<!-- End Populate Slot -->
    
    
    </div>
    </div>
    <!-- End Diary Column -->
    <!-- Start Diary Column -->
    <div class="DiaryColumnContainer ContextOn 69 EmptySlots" style="cursor:pointer;" data-apptid="" data-time="19:00" data-staffid="14" data-staffname="Emile  Cloete" data-status="" data-key="69" data-clientid="" data-clientname="" data-newclient="" data-extended="" data-primaryid="" data-invoiced="" data-caseid="" data-type="">
    
    <div class="DiaryColumn" >

<!-- Start Lunch Time -->
<!-- End Lunch Time -->
	
<!-- Start Populate Slot -->
<!-- End Populate Slot -->
    
    
    </div>
    </div>
    <!-- End Diary Column -->
    <!-- Start Diary Column -->
    <div class="DiaryColumnContainer ContextOn 69 EmptySlots" style="cursor:pointer;" data-apptid="" data-time="19:00" data-staffid="1" data-staffname="Darren  Rieck" data-status="" data-key="69" data-clientid="" data-clientname="" data-newclient="" data-extended="" data-primaryid="" data-invoiced="" data-caseid="" data-type="">
    
    <div class="DiaryColumn" >

<!-- Start Lunch Time -->
<!-- End Lunch Time -->
	
<!-- Start Populate Slot -->
<!-- End Populate Slot -->
    
    
    </div>
    </div>
    <!-- End Diary Column -->
    <!-- Start Diary Column -->
    <div class="DiaryColumnContainer ContextOn 69 EmptySlots" style="cursor:pointer;" data-apptid="" data-time="19:00" data-staffid="6" data-staffname="Karen  Kitchener" data-status="" data-key="69" data-clientid="" data-clientname="" data-newclient="" data-extended="" data-primaryid="" data-invoiced="" data-caseid="" data-type="">
    
    <div class="DiaryColumn" >

<!-- Start Lunch Time -->
<!-- End Lunch Time -->
	
<!-- Start Populate Slot -->
<!-- End Populate Slot -->
    
    
    </div>
    </div>
    <!-- End Diary Column -->
    <!-- Start Diary Column -->
    <div class="DiaryColumnContainer ContextOn 70 EmptySlots" style="cursor:pointer;" data-apptid="" data-time="19:10" data-staffid="26" data-staffname="Bec Webberley" data-status="" data-key="70" data-clientid="" data-clientname="" data-newclient="" data-extended="" data-primaryid="" data-invoiced="" data-caseid="" data-type="">
    
    <div class="DiaryColumn" >

<!-- Start Lunch Time -->
<!-- End Lunch Time -->
	
<!-- Start Populate Slot -->
<!-- End Populate Slot -->
    
    
    </div>
    </div>
    <!-- End Diary Column -->
    <!-- Start Diary Column -->
    <div class="DiaryColumnContainer ContextOn 70 EmptySlots" style="cursor:pointer;" data-apptid="" data-time="19:10" data-staffid="7" data-staffname="Tamara Shaw" data-status="" data-key="70" data-clientid="" data-clientname="" data-newclient="" data-extended="" data-primaryid="" data-invoiced="" data-caseid="" data-type="">
    
    <div class="DiaryColumn" >

<!-- Start Lunch Time -->
<!-- End Lunch Time -->
	
<!-- Start Populate Slot -->
<!-- End Populate Slot -->
    
    
    </div>
    </div>
    <!-- End Diary Column -->
    <!-- Start Diary Column -->
    <div class="DiaryColumnContainer ContextOn 70 EmptySlots" style="cursor:pointer;" data-apptid="" data-time="19:10" data-staffid="16" data-staffname="Olivia  Moy" data-status="" data-key="70" data-clientid="" data-clientname="" data-newclient="" data-extended="" data-primaryid="" data-invoiced="" data-caseid="" data-type="">
    
    <div class="DiaryColumn" >

<!-- Start Lunch Time -->
<!-- End Lunch Time -->
	
<!-- Start Populate Slot -->
<!-- End Populate Slot -->
    
    
    </div>
    </div>
    <!-- End Diary Column -->
    <!-- Start Diary Column -->
    <div class="DiaryColumnContainer ContextOn 70 EmptySlots" style="cursor:pointer;" data-apptid="" data-time="19:10" data-staffid="18" data-staffname="Andrew  Rashleigh" data-status="" data-key="70" data-clientid="" data-clientname="" data-newclient="" data-extended="" data-primaryid="" data-invoiced="" data-caseid="" data-type="">
    
    <div class="DiaryColumn" >

<!-- Start Lunch Time -->
<!-- End Lunch Time -->
	
<!-- Start Populate Slot -->
<!-- End Populate Slot -->
    
    
    </div>
    </div>
    <!-- End Diary Column -->
    <!-- Start Diary Column -->
    <div class="DiaryColumnContainer ContextOn 70 EmptySlots" style="cursor:pointer;" data-apptid="" data-time="19:10" data-staffid="14" data-staffname="Emile  Cloete" data-status="" data-key="70" data-clientid="" data-clientname="" data-newclient="" data-extended="" data-primaryid="" data-invoiced="" data-caseid="" data-type="">
    
    <div class="DiaryColumn" >

<!-- Start Lunch Time -->
<!-- End Lunch Time -->
	
<!-- Start Populate Slot -->
<!-- End Populate Slot -->
    
    
    </div>
    </div>
    <!-- End Diary Column -->
    <!-- Start Diary Column -->
    <div class="DiaryColumnContainer ContextOn 70 EmptySlots" style="cursor:pointer;" data-apptid="" data-time="19:10" data-staffid="1" data-staffname="Darren  Rieck" data-status="" data-key="70" data-clientid="" data-clientname="" data-newclient="" data-extended="" data-primaryid="" data-invoiced="" data-caseid="" data-type="">
    
    <div class="DiaryColumn" >

<!-- Start Lunch Time -->
<!-- End Lunch Time -->
	
<!-- Start Populate Slot -->
<!-- End Populate Slot -->
    
    
    </div>
    </div>
    <!-- End Diary Column -->
    <!-- Start Diary Column -->
    <div class="DiaryColumnContainer ContextOn 70 EmptySlots" style="cursor:pointer;" data-apptid="" data-time="19:10" data-staffid="6" data-staffname="Karen  Kitchener" data-status="" data-key="70" data-clientid="" data-clientname="" data-newclient="" data-extended="" data-primaryid="" data-invoiced="" data-caseid="" data-type="">
    
    <div class="DiaryColumn" >

<!-- Start Lunch Time -->
<!-- End Lunch Time -->
	
<!-- Start Populate Slot -->
<!-- End Populate Slot -->
    
    
    </div>
    </div>
    <!-- End Diary Column -->
    <!-- Start Diary Column -->
    <div class="DiaryColumnContainer ContextOn 71 EmptySlots" style="cursor:pointer;" data-apptid="" data-time="19:20" data-staffid="26" data-staffname="Bec Webberley" data-status="" data-key="71" data-clientid="" data-clientname="" data-newclient="" data-extended="" data-primaryid="" data-invoiced="" data-caseid="" data-type="">
    
    <div class="DiaryColumn" >

<!-- Start Lunch Time -->
<!-- End Lunch Time -->
	
<!-- Start Populate Slot -->
<!-- End Populate Slot -->
    
    
    </div>
    </div>
    <!-- End Diary Column -->
    <!-- Start Diary Column -->
    <div class="DiaryColumnContainer ContextOn 71 EmptySlots" style="cursor:pointer;" data-apptid="" data-time="19:20" data-staffid="7" data-staffname="Tamara Shaw" data-status="" data-key="71" data-clientid="" data-clientname="" data-newclient="" data-extended="" data-primaryid="" data-invoiced="" data-caseid="" data-type="">
    
    <div class="DiaryColumn" >

<!-- Start Lunch Time -->
<!-- End Lunch Time -->
	
<!-- Start Populate Slot -->
<!-- End Populate Slot -->
    
    
    </div>
    </div>
    <!-- End Diary Column -->
    <!-- Start Diary Column -->
    <div class="DiaryColumnContainer ContextOn 71 EmptySlots" style="cursor:pointer;" data-apptid="" data-time="19:20" data-staffid="16" data-staffname="Olivia  Moy" data-status="" data-key="71" data-clientid="" data-clientname="" data-newclient="" data-extended="" data-primaryid="" data-invoiced="" data-caseid="" data-type="">
    
    <div class="DiaryColumn" >

<!-- Start Lunch Time -->
<!-- End Lunch Time -->
	
<!-- Start Populate Slot -->
<!-- End Populate Slot -->
    
    
    </div>
    </div>
    <!-- End Diary Column -->
    <!-- Start Diary Column -->
    <div class="DiaryColumnContainer ContextOn 71 EmptySlots" style="cursor:pointer;" data-apptid="" data-time="19:20" data-staffid="18" data-staffname="Andrew  Rashleigh" data-status="" data-key="71" data-clientid="" data-clientname="" data-newclient="" data-extended="" data-primaryid="" data-invoiced="" data-caseid="" data-type="">
    
    <div class="DiaryColumn" >

<!-- Start Lunch Time -->
<!-- End Lunch Time -->
	
<!-- Start Populate Slot -->
<!-- End Populate Slot -->
    
    
    </div>
    </div>
    <!-- End Diary Column -->
    <!-- Start Diary Column -->
    <div class="DiaryColumnContainer ContextOn 71 EmptySlots" style="cursor:pointer;" data-apptid="" data-time="19:20" data-staffid="14" data-staffname="Emile  Cloete" data-status="" data-key="71" data-clientid="" data-clientname="" data-newclient="" data-extended="" data-primaryid="" data-invoiced="" data-caseid="" data-type="">
    
    <div class="DiaryColumn" >

<!-- Start Lunch Time -->
<!-- End Lunch Time -->
	
<!-- Start Populate Slot -->
<!-- End Populate Slot -->
    
    
    </div>
    </div>
    <!-- End Diary Column -->
    <!-- Start Diary Column -->
    <div class="DiaryColumnContainer ContextOn 71 EmptySlots" style="cursor:pointer;" data-apptid="" data-time="19:20" data-staffid="1" data-staffname="Darren  Rieck" data-status="" data-key="71" data-clientid="" data-clientname="" data-newclient="" data-extended="" data-primaryid="" data-invoiced="" data-caseid="" data-type="">
    
    <div class="DiaryColumn" >

<!-- Start Lunch Time -->
<!-- End Lunch Time -->
	
<!-- Start Populate Slot -->
<!-- End Populate Slot -->
    
    
    </div>
    </div>
    <!-- End Diary Column -->
    <!-- Start Diary Column -->
    <div class="DiaryColumnContainer ContextOn 71 EmptySlots" style="cursor:pointer;" data-apptid="" data-time="19:20" data-staffid="6" data-staffname="Karen  Kitchener" data-status="" data-key="71" data-clientid="" data-clientname="" data-newclient="" data-extended="" data-primaryid="" data-invoiced="" data-caseid="" data-type="">
    
    <div class="DiaryColumn" >

<!-- Start Lunch Time -->
<!-- End Lunch Time -->
	
<!-- Start Populate Slot -->
<!-- End Populate Slot -->
    
    
    </div>
    </div>
    <!-- End Diary Column -->
    <!-- Start Diary Column -->
    <div class="DiaryColumnContainer ContextOff 72 " style="cursor:not-allowed;" data-apptid="" data-time="19:30" data-staffid="26" data-staffname="Bec Webberley" data-status="" data-key="72" data-clientid="" data-clientname="" data-newclient="" data-extended="" data-primaryid="" data-invoiced="" data-caseid="" data-type="">
    
    <div class="DiaryColumnClose" >

<!-- Start Lunch Time -->
<!-- End Lunch Time -->
	
<!-- Start Populate Slot -->
<!-- End Populate Slot -->
    
    
    </div>
    </div>
    <!-- End Diary Column -->
    <!-- Start Diary Column -->
    <div class="DiaryColumnContainer ContextOff 72 " style="cursor:not-allowed;" data-apptid="" data-time="19:30" data-staffid="7" data-staffname="Tamara Shaw" data-status="" data-key="72" data-clientid="" data-clientname="" data-newclient="" data-extended="" data-primaryid="" data-invoiced="" data-caseid="" data-type="">
    
    <div class="DiaryColumnClose" >

<!-- Start Lunch Time -->
<!-- End Lunch Time -->
	
<!-- Start Populate Slot -->
<!-- End Populate Slot -->
    
    
    </div>
    </div>
    <!-- End Diary Column -->
    <!-- Start Diary Column -->
    <div class="DiaryColumnContainer ContextOff 72 " style="cursor:not-allowed;" data-apptid="" data-time="19:30" data-staffid="16" data-staffname="Olivia  Moy" data-status="" data-key="72" data-clientid="" data-clientname="" data-newclient="" data-extended="" data-primaryid="" data-invoiced="" data-caseid="" data-type="">
    
    <div class="DiaryColumnClose" >

<!-- Start Lunch Time -->
<!-- End Lunch Time -->
	
<!-- Start Populate Slot -->
<!-- End Populate Slot -->
    
    
    </div>
    </div>
    <!-- End Diary Column -->
    <!-- Start Diary Column -->
    <div class="DiaryColumnContainer ContextOff 72 " style="cursor:not-allowed;" data-apptid="" data-time="19:30" data-staffid="18" data-staffname="Andrew  Rashleigh" data-status="" data-key="72" data-clientid="" data-clientname="" data-newclient="" data-extended="" data-primaryid="" data-invoiced="" data-caseid="" data-type="">
    
    <div class="DiaryColumnClose" >

<!-- Start Lunch Time -->
<!-- End Lunch Time -->
	
<!-- Start Populate Slot -->
<!-- End Populate Slot -->
    
    
    </div>
    </div>
    <!-- End Diary Column -->
    <!-- Start Diary Column -->
    <div class="DiaryColumnContainer ContextOff 72 " style="cursor:not-allowed;" data-apptid="" data-time="19:30" data-staffid="14" data-staffname="Emile  Cloete" data-status="" data-key="72" data-clientid="" data-clientname="" data-newclient="" data-extended="" data-primaryid="" data-invoiced="" data-caseid="" data-type="">
    
    <div class="DiaryColumnClose" >

<!-- Start Lunch Time -->
<!-- End Lunch Time -->
	
<!-- Start Populate Slot -->
<!-- End Populate Slot -->
    
    
    </div>
    </div>
    <!-- End Diary Column -->
    <!-- Start Diary Column -->
    <div class="DiaryColumnContainer ContextOff 72 " style="cursor:not-allowed;" data-apptid="" data-time="19:30" data-staffid="1" data-staffname="Darren  Rieck" data-status="" data-key="72" data-clientid="" data-clientname="" data-newclient="" data-extended="" data-primaryid="" data-invoiced="" data-caseid="" data-type="">
    
    <div class="DiaryColumnClose" >

<!-- Start Lunch Time -->
<!-- End Lunch Time -->
	
<!-- Start Populate Slot -->
<!-- End Populate Slot -->
    
    
    </div>
    </div>
    <!-- End Diary Column -->
    <!-- Start Diary Column -->
    <div class="DiaryColumnContainer ContextOff 72 " style="cursor:not-allowed;" data-apptid="" data-time="19:30" data-staffid="6" data-staffname="Karen  Kitchener" data-status="" data-key="72" data-clientid="" data-clientname="" data-newclient="" data-extended="" data-primaryid="" data-invoiced="" data-caseid="" data-type="">
    
    <div class="DiaryColumnClose" >

<!-- Start Lunch Time -->
<!-- End Lunch Time -->
	
<!-- Start Populate Slot -->
<!-- End Populate Slot -->
    
    
    </div>
    </div>
    <!-- End Diary Column -->
<script type="text/javascript">
	var columnCount = 7;
</script>
<br style="clear:both; font-size:1px;" />
</div>
<!-- End Main Diary Content -->