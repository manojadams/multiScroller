/************************************************
* Global Variables								*
************************************************/


/************************************************
* Initiate Draggable Events						*
************************************************/
function InitDraggable()
{
	window.console.log('custom.js - InitDraggable() triggered');
	$(".ApptContainer").draggable({
		snap: ".timeslot",
		snapMode: "inner",
		containment: "#ScheduleTable",
		cursor: "move",
		grid: [ $('.timeslot').children().width(), $('.timeslot').children().height() ],
		stop: function(event, ui) {
			$("#Notice").html('Drag event complete');
		}
	});	
	
	return true;
}
// End InitDraggable()

/************************************************
* Load/Call Required Functions					*
************************************************/
$().ready(function() {
	window.console.log('custom.js loaded.');
	
	InitDraggable();

});