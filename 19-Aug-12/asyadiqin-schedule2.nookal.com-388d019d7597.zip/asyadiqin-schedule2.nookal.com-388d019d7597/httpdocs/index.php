<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>JQuery Scheduler Plugin</title>

<!-- Core JQuery, JQuery UI and JQuery UI CSS -->
<script type="text/javascript" src="jquery/jquery-1.7.2.min.js"></script>
<script type="text/javascript" src="jquery/jquery-ui-1.8.21.custom.min.js"></script>
<link href="jquery/redmond/jquery-ui-1.8.21.custom.css" rel="stylesheet" type="text/css" />

<!-- Custom JS File -->
<script type="text/javascript" src="js/custom.js"></script>

<!-- Global CSS Files -->
<link href="css/style.css" rel="stylesheet" type="text/css" />
</head>
<body>
<!-- Start Schedule Container -->
<?php
// Define variables
$StartTime		= '08:00';
$EndTime		= '17:00';
$TotalHours		= 10;
$ScheduleDate	= date('Y-m-d'); 
$SlotDuration	= 15; // minutes per row
$RowsPerHour	= 4;
$ScheduleType	= 'Provider';
$TotalProvider	= 4;
$TotalRows		= $TotalHours * $RowsPerHour;
$BgColor		= array('#2C2593','#258C93','#C43B31');
$FirstNames		= array('Mary','John','Michael','Peter','Julie','Jane');
$LastNames		= array('Smith','Helm','Chalmers','Rieck','Roberts','King');
?>
<input id="ScheduleDate" type="hidden" value="<?php echo $ScheduleDate; ?>" />
<input id="TimeStart" type="hidden" value="<?php echo $StartTime; ?>" />
<input id="TimeEnd" type="hidden" value="<?php echo $EndTime; ?>" />
<input id="SlotDuration" type="hidden" value="<?php echo $SlotDuration; ?>" />
<input id="ScheduleType" type="hidden" value="<?php echo $SlotType; ?>" />
<input id="TotalProvider" type="hidden" value="<?php echo $TotalProvider; ?>" />
<div id="LeftContainer">

<div class="LeftDivs ColumnTitle">ClipBoard</div>
<div id="Clipboard" class="LeftDivs"></div>

<div class="LeftDivs ColumnTitle">Notice</div>
<div id="Notice" class="LeftDivs"></div>

</div>
<div id="RightContainer">
<table id="ScheduleTable">
<?php
$key = 0;
for($Time = 10; $Time <= 15; $Time++)
{
	$ClientName	= $FirstNames[rand(0, 5)].' '.$LastNames[rand(0, 5)];
?>
  <tr>
  	<td class="timecolumn" data-hour="<?php echo $Time; ?>" rowspan="4"><?php echo $Time.':00'; ?></td>
    <td class="timeslot" data-starttime="<?php echo $Time; ?>:00" data-endtime="<?php echo $Time; ?>:15" data-providerid="1" data-occupied="1" >
	<div class="ApptContainer">
    <div id="<?php echo rand(1000, 9999); ?>" class="ApptDiv" data-clientid="<?php echo rand(10, 99); ?>" data-clientname="<?php echo $ClientName; ?>" data-starttime="<?php echo $Time; ?>:00" data-endtime="<?php echo $Time; ?>:15" style="height:25px; background-color:<?php echo $BgColor[$key]; ?>; color:#FFF; text-align:left; padding-left:5px; line-height:2.0em;"><?php echo $ClientName; ?> (<span id="start-time"><?php echo $Time; ?>:00</span> - <span id="end-time"><?php echo $Time; ?>:15</span>)</div>
    <div class="ApptResizeHandle" style="background-color:<?php echo $BgColor[$key]; ?>;"></div>
    </div>    
    </td>
    <td class="timeslot" data-starttime="<?php echo $Time; ?>:00" data-endtime="<?php echo $Time; ?>:15" data-providerid="2" data-occupied="0" ></td>
    <td class="timeslot" data-starttime="<?php echo $Time; ?>:00" data-endtime="<?php echo $Time; ?>:15" data-providerid="3" data-occupied="0" ></td>
  </tr>
  <tr>
    <td class="timeslot" data-starttime="<?php echo $Time; ?>:15" data-endtime="<?php echo $Time; ?>:30" data-providerid="1" data-occupied="0" ></td>
    <td class="timeslot" data-starttime="<?php echo $Time; ?>:15" data-endtime="<?php echo $Time; ?>:30" data-providerid="2" data-occupied="0" ></td>
    <td class="timeslot" data-starttime="<?php echo $Time; ?>:15" data-endtime="<?php echo $Time; ?>:30" data-providerid="3" data-occupied="0" ></td>
  </tr>
  <tr>
    <td class="timeslot" data-starttime="<?php echo $Time; ?>:30" data-endtime="<?php echo $Time; ?>:45" data-providerid="1" data-occupied="0" ></td>
    <td class="timeslot" data-starttime="<?php echo $Time; ?>:30" data-endtime="<?php echo $Time; ?>:45" data-providerid="2" data-occupied="0" ></td>
    <td class="timeslot" data-starttime="<?php echo $Time; ?>:30" data-endtime="<?php echo $Time; ?>:45" data-providerid="3" data-occupied="0" ></td>
  </tr>
  <tr>
    <td class="timeslot" data-starttime="<?php echo $Time; ?>:45" data-endtime="<?php echo $Time+1; ?>:00" data-providerid="1" data-occupied="0" ></td>
    <td class="timeslot" data-starttime="<?php echo $Time; ?>:45" data-endtime="<?php echo $Time+1; ?>:00" data-providerid="2" data-occupied="0" ></td>
    <td class="timeslot" data-starttime="<?php echo $Time; ?>:45" data-endtime="<?php echo $Time+1; ?>:00" data-providerid="3" data-occupied="0" ></td>
  </tr>
<?php
	$key++;
	$key = ($key == 3) ? 0 : $key; 
}
?>
</table>
</div>
<!-- End Schedule Container -->
</body>
</html>