<div id="StatisticContainer">
<!-- Start Statistic Contents -->
<div data-providerid="1" class="StatisticBG">
	<div class="StatisticRow">10</div>
    <div class="StatisticRow-Middle">2</div>
    <div class="StatisticRow">50%</div>
</div>
<div data-providerid="2" class="StatisticBG">
	<div class="StatisticRow">15</div>
    <div class="StatisticRow-Middle">4</div>
    <div class="StatisticRow">70%</div>
</div>
<div data-providerid="3" class="StatisticBG">
	<div class="StatisticRow">20</div>
    <div class="StatisticRow-Middle">6</div>
    <div class="StatisticRow">40%</div>
</div>
<div data-providerid="4" class="StatisticBG">
	<div class="StatisticRow">25</div>
    <div class="StatisticRow-Middle">5</div>
    <div class="StatisticRow">35%</div>
</div>
<div data-providerid="5" class="StatisticBG">
	<div class="StatisticRow">8</div>
    <div class="StatisticRow-Middle">1</div>
    <div class="StatisticRow">30%</div>
</div>
<div data-providerid="6" class="StatisticBG">
	<div class="StatisticRow">18</div>
    <div class="StatisticRow-Middle">9</div>
    <div class="StatisticRow">80%</div>
</div>
<div data-providerid="7" class="StatisticBG">
	<div class="StatisticRow">3</div>
    <div class="StatisticRow-Middle">0</div>
    <div class="StatisticRow">20%</div>
</div>
<div data-providerid="8" class="StatisticBG">
	<div class="StatisticRow">45</div>
    <div class="StatisticRow-Middle">12</div>
    <div class="StatisticRow">80%</div>
</div>
<!-- End Statistic Contents -->
<br />
</div>